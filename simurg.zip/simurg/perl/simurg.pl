#!/usr/bin/perl

use strict;
use POSIX();
use Cwd qw(); 
use warnings;
#use diagnostics;
#use Math::Matrix;
use Storable qw(dclone);
use Time::HiRes qw(time);
use Term::ANSIColor qw(:constants);

my $is_nit = 1;
my $is_creg = 0;
my $acc_tech = 0;
my $act_fun = "";
my $the_verb = 0;
my $dv_file = "";
my $the_test = 0;
my $the_tech = 1;
my $in_width = 8;
my $the_wout = 0;
my $quan_bit = 8;
my $out_width = 8;
my $exap_cmul = 0;
my $the_rep = "csd";
my $act_fun_cnt = 1;
my @act_fun_arr = ();
my $the_aim = "area";
my $file_weight = "";
my $test_num = 10000;

my $arg_ok = 1;
my $arg_cnt = 0;
while (1){
  if (defined $ARGV[$arg_cnt]){
    if ($ARGV[$arg_cnt] eq "-h" or $ARGV[$arg_cnt] eq "-help"){
      $arg_ok = 0;
      last;
    }
    else{
      if (index($ARGV[$arg_cnt], "-quan=") != -1){
        $quan_bit = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($quan_bit < 0){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-ibw=") != -1){
        $in_width = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5) + 0.0;
        if ($in_width < 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-obw=") != -1){
        $out_width = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5) + 0.0;
        if ($out_width < 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-not=") != -1){
        $test_num = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5) + 0.0;
        if ($test_num < 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-nnit") != -1){
        $is_nit = 0;
      }
      elsif (index($ARGV[$arg_cnt], "-wout") != -1){
        $the_wout = 1;
      }
      elsif (index($ARGV[$arg_cnt], "-verb") != -1){
        $the_verb = 1;
      }
      elsif (index($ARGV[$arg_cnt], "-tech=") != -1){
        $the_tech = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($the_tech < 1 and $the_tech > 7){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-act=") != -1){
        $act_fun = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5);
        #print "act_fun: $act_fun \n";

        my $init_index = 0;
        my $last_index;
        my $the_func;
        while (1){
          $last_index = index($act_fun, "/", $init_index);

          if ($last_index == -1){
            $the_func = substr($act_fun, $init_index, length($act_fun)-$init_index);
            #print "the_func: $the_func \n";
            #sleep 1;

            if ($the_func eq "lin" or $the_func eq "relu" or $the_func eq "hsig" or $the_func eq "htanh" or $the_func eq "satlin"){ 
              $act_fun_cnt++;
              $act_fun_arr[$act_fun_cnt] = $the_func;
              last;
            }
            else{
              $arg_ok = 0;
              last;
            }
          }
          else{
            $the_func = substr($act_fun, $init_index, $last_index-$init_index);
            #print "the_func: $the_func \n";
            #sleep 1;

            if ($the_func eq "lin" or $the_func eq "relu" or $the_func eq "hsig" or $the_func eq "htanh" or $the_func eq "satlin"){ 
              $act_fun_cnt++;
              $act_fun_arr[$act_fun_cnt] = $the_func;

              $init_index = $last_index+1;
            }
            else{
              $arg_ok = 0;
              last;
            }
          }
        }
      }
      elsif (index($ARGV[$arg_cnt], "-test=") != -1){
        $the_test = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0.0;
        if ($the_test != 0 and $the_test != 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-creg") != -1){
        $is_creg = 1;
      }
      elsif (index($ARGV[$arg_cnt], "-dvf=") != -1){
        $dv_file = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5);
        if ($dv_file eq ""){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-rep=") != -1){
        $the_rep = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5);
        if ($the_rep ne "binary" and $the_rep ne "csd"){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-aim=") != -1){
        $the_aim = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5);
        if ($the_aim ne "area" and $the_aim ne "delay"){
          $arg_ok = 0;
        }
      }
      else{
        if (!$arg_cnt){
          $file_weight = $ARGV[0];
        }
        else{
          $arg_ok = 0;
          last;
        }
      }
    }
  }
  else{
    if (!$arg_cnt){
      $arg_ok = 0;
    }
    last;
  }

  $arg_cnt++;
}

if ($arg_ok){
  if ($file_weight ne "" and ($the_test == 0 or $dv_file ne "") and (!$is_creg or ($the_tech >=1 and $the_tech <= 4))){
    main_part();
  }
  else{
    help_part();
  }
}
else{
  help_part();
}

sub help_part{
  print "######################################################################################################################################################################################################################### \n";
  print "# Usage:       perl simurg.pl <File_Name> -ibw=<int> -obw=<int> -quan=<int> -tech=1-7 -act=lin/relu/hsig/htanh/satlin -test=0/1 -not=<int> -dvf=<File_Name> -nnit -creg -rep=binary/csd -aim=area/delay -wout -h        # \n";
  print "# File_Name:   Name of the file including the ANN weigth and bias values                                                                                                                                                # \n";
  print "# -ibw:        Bitwidth of inputs, by default it is 8                                                                                                                                                                   # \n";
  print "# -obw:        Bitwidth of outputs, by default it is 8                                                                                                                                                                  # \n";
  print "# -quan:       Quantization value for weight and bias values, by default it is 8. It can be greater than or equal to 0                                                                                                  # \n";
  print "# -tech:       Technique to design the ANN, by default it is 1                                                                                                                                                          # \n";
  print "#                 1: Realization of ANN under the parallel architecture - constant multiplications are defined in a behavioral fashion (par_beh)                                                                        # \n";
  print "#                 2: Realization of ANN under the parallel architecture - constant multiplications are implemented under the shift-adds architecture using multiple constant multiplciation blocks (par_mcm)            # \n";
  print "#                 3: Realization of ANN under the parallel architecture - constant multiplications are implemented under the shift-adds architecture using constant array vector multiplication blocks (par_cavm)       # \n";
  print "#                 4: Realization of ANN under the parallel architecture - constant multiplications are implemented under the shift-adds architecture using constant matrix vector multiplication blocks (par_cmvm)      # \n";
  print "#                 5: Realization of ANN under the SMAC_NEURON architecture - constant multiplications are defined in a behavioral fashion (smac_neuron_beh)                                                             # \n";
  print "#                 6: Realization of ANN under the SMAC_NEURON architecture - constant multiplications are implemented under the shift-adds architecture using multiple constant multiplication blocks (smac_neuron_mcm) # \n";
  print "#                 7: Realization of ANN under the SMAC_ANN architecture - constant multiplications are defined in a behavioral fashion (smac_ann)                                                                       # \n";
  print "# -act:        Activation function of neurons on each layer separated by a slash, by default it is htanh at the hidden layers and lin at the output layer                                                               # \n";
  print "#                 0: lin  - linear                                                                                                                                                                                      # \n";
  print "#                 1: relu - rectified linear unit                                                                                                                                                                       # \n";
  print "#                 2: hsig - hard sigmoid fuction                                                                                                                                                                        # \n";
  print "#                 3: htanh - hard hyperbolic tangent                                                                                                                                                                    # \n";
  print "#                 4: satlin - saturating linear transfer function                                                                                                                                                       # \n";
  print "# -test:       Technique to verify the ANN design, by default it is 0                                                                                                                                                   # \n";
  print "#                 0: Random                                                                                                                                                                                             # \n";
  print "#                 1: Directed (using the test data)                                                                                                                                                                     # \n";
  print "# -not:        Number of test patterns to be used in the random verification technique, by default it is 10000                                                                                                          # \n";
  print "# -dvf:        Name of the file including the test values to be used in the directed verification technique                                                                                                             # \n";
  print "# -nnit:       Assumes that the inputs are not normalized during training, by default the normalization of inputs is assumed                                                                                            # \n";
  print "# -creg:       Adds flip-flops to the outputs of a parallel design obtained between techniques 1 and 4, by default it does not                                                                                          # \n";
  print "# -rep:        Number representation used in the CMVM algorithm, by default it is CSD                                                                                                                                   # \n";
  print "# -aim:        Optimization aim in the MCM, CAVM, or CMVM algorithm, by default it is area                                                                                                                              # \n";
  print "# -wout:       Quantized weight and bias values in each layer are written into a file with an \"iw\" extension, by default they are not                                                                                   # \n";
  print "# -h:          Prints this screen                                                                                                                                                                                       # \n";
  print "# Description: Automatically generates the Verilog design and test-bench codes for the ANN implementation                                                                                                               # \n";
  print "# Examples:    perl simurg.pl examples\\ANN_16_16_10_10.w -quan=7 -tech=7 -act=htanh/htanh/hsig                                                                                                                          # \n";
  print "#              perl simurg.pl examples\\ANN_16_10_10.w -quan=7 -tech=5 -act=htanh/hsig                                                                                                                                   # \n";
  print "#              perl simurg.pl examples\\ANN_16_10.w -quan=5 -tech=4 -act=hsig -rep=csd -aim=area                                                                                                                         # \n";
  print "#              perl simurg.pl examples\\ANN_16_10.w -quan=5 -tech=1 -creg -wout -test=0 -dvf=test_data/pen_test_norm2_q8.conv                                                                                            # \n";
  print "######################################################################################################################################################################################################################### \n";
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      last;
    }
  }

  return $the_offset;
}

sub skip_spaces_backward{
  my ($the_string, $the_offset) = @_;

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset--;
    if ($the_offset < 0) {
      last;
    }
  }

  return $the_offset;
}

sub make_number_posodd{
  my ($posodd_con) = @_;

  my $the_sign = 0;
  my $the_shift = 0;

  if ($posodd_con){
    if ($posodd_con < 0){
      $the_sign = 1;
      $posodd_con = (-1) * $posodd_con;
    }

    while (($posodd_con % 2) == 0){
      $the_shift++;
      $posodd_con = $posodd_con/2;
    }
  }

  return ($the_sign, $the_shift, $posodd_con);
}

sub is_inside_numeric_array{
  my ($the_element, $the_cnt, @the_arr) = @_;

  my $the_result = 0;

  foreach my $i (1 .. $the_cnt){
    if ($the_arr[$i] == $the_element){
      $the_result = $i;
      last;
    }
  }

  return $the_result;
}

sub is_array_identical{
  my ($one_cnt, $two_cnt, $one_arr_ref, $two_arr_ref) = @_;
  my @one_arr = @ {$one_arr_ref};
  my @two_arr = @ {$two_arr_ref};

  my $the_val = 1;

  if ($one_cnt == $two_cnt){
    foreach my $i (1 .. $one_cnt){
      if ($one_arr[$i] != $two_arr[$i]){
        $the_val = 0;
        last;
      }
    }
  }
  else{
    $the_val = 0;
  }

  return ($the_val);
}

sub find_maximum_array{
  my (@prod_col_cnt) = @_;

  my $max_val = (-1)*9**9**9;
  foreach my $i (1 .. @prod_col_cnt-1){
    if ($prod_col_cnt[$i] > $max_val){
      $max_val = $prod_col_cnt[$i];
    }
  }

  return ($max_val);
}

sub whereis_inside_triple_arr{
  my ($in_one, $in_two, $in_three, $cmul_cnt, @cmul_mat) = @_;

  my $is_inside = 0;

  foreach my $i (1 .. $cmul_cnt){
    if ($cmul_mat[$i][1] == $in_one and $cmul_mat[$i][2] == $in_two and $in_three == $cmul_mat[$i][3]){
      $is_inside = $i;
      last;
    }
    elsif ($cmul_mat[$i][2] == $in_one and $cmul_mat[$i][1] == $in_two and $in_three == $cmul_mat[$i][3]){
      $is_inside = $i;
      last;
    }
  }

  return ($is_inside);
}

sub whereis_inside_double_arr{
  my ($in_one, $in_two, $cmul_cnt, @cmul_mat) = @_;

  my $is_inside = 0;

  foreach my $i (1 .. $cmul_cnt){
    if ($cmul_mat[$i][1] == $in_one and $cmul_mat[$i][2] == $in_two){
      $is_inside = $i;
      last;
    }
    elsif ($cmul_mat[$i][2] == $in_one and $cmul_mat[$i][1] == $in_two){
      $is_inside = $i;
      last;
    }
  }

  return ($is_inside);
}

sub int2sign{
  my ($the_int, $the_len) = @_;
  #print "the_int: $the_int ";

  my @the_rep = ();

  if ($the_int < 0){
    $the_int = 2**$the_len - abs($the_int);
  }
  #print "act_int: $the_int the_rep: ";

  foreach my $i (1 .. $the_len){
    $the_rep[$i] = 0;
  }

  my $the_index = 0;
  while ($the_int > 1){
    $the_index++;
    my $the_val = $the_int % 2;
    $the_rep[$the_index] = $the_val;
    $the_int = ($the_int - $the_val) / 2;
  }

  $the_index++;
  $the_rep[$the_index] = $the_int;

  #foreach my $i (1 .. $the_len){
  #  print "$the_rep[$i]";
  #}
  #print "\n";
  #sleep 1;

  return (@the_rep);
}

sub int2bin{
  my ($the_int, $the_len) = @_;

  my @the_rep = ();

  foreach my $i (1 .. $the_len){
    $the_rep[$i] = 0;
  }

  my $the_index = 0;
  while ($the_int > 1){
    $the_index++;
    my $the_val = $the_int % 2;
    $the_rep[$the_index] = $the_val;
    $the_int = ($the_int - $the_val) / 2;
  }

  $the_index++;
  $the_rep[$the_index] = $the_int;

  return (@the_rep);
}

sub bin2csd {
  my ($bin_len, @bin_rep) = @_;

  my @csd_rep = ();
  my $csd_len = $bin_len;

  $csd_len++;
  $bin_rep[$csd_len] = 0;
  $csd_len++;
  $bin_rep[$csd_len] = 0;
  $csd_len--;

  my $the_state = 0;
  foreach my $i (1 .. $bin_len+1){
    #print "[INFO]: $the_state, $bin_rep[$i+1], $bin_rep[$i] \n";
    if ($the_state == 0 and $bin_rep[$i+1] == 0 and $bin_rep[$i] == 0){
      $csd_rep[$i] = 0;
      $the_state = 0;
    }
    elsif ($the_state == 0 and $bin_rep[$i+1] == 0 and $bin_rep[$i] == 1){
      $csd_rep[$i] = 1;
      $the_state = 0;
    }
    elsif ($the_state == 0 and $bin_rep[$i+1] == 1 and $bin_rep[$i] == 0){
      $csd_rep[$i] = 0;
      $the_state = 0;
    }
    elsif ($the_state == 0 and $bin_rep[$i+1] == 1 and $bin_rep[$i] == 1){
      $csd_rep[$i] = -1;
      $the_state = 1;
    }
    elsif ($the_state == 1 and $bin_rep[$i+1] == 0 and $bin_rep[$i] == 0){
      $csd_rep[$i] = 1;
      $the_state = 0;
    }
    elsif ($the_state == 1 and $bin_rep[$i+1] == 0 and $bin_rep[$i] == 1){
      $csd_rep[$i] = 0;
      $the_state = 1;
    }
    elsif ($the_state == 1 and $bin_rep[$i+1] == 1 and $bin_rep[$i] == 0){
      $csd_rep[$i] = -1;
      $the_state = 1;
    }
    elsif ($the_state == 1 and $bin_rep[$i+1] == 1 and $bin_rep[$i] == 1){
      $csd_rep[$i] = 0;
      $the_state = 1;
    }
  }

  return ($csd_len, @csd_rep);
}

sub find_nonzero_digits_csd{
  my ($the_num) = @_;

  my $nzd_cnt = 0;
  my @nzd_arr = ();
  
  if ($the_num){
    my $the_sign = 0;
    if ($the_num < 0){
      $the_sign = 1;
      $the_num = (-1)*$the_num;
    }

    my $the_width = int(log($the_num)/log(2))+1;
    my (@bin_rep) = int2bin($the_num, $the_width);
    my ($csd_len, @csd_rep) = bin2csd($the_width, @bin_rep);
    foreach my $i (1 .. $csd_len){
      if ($csd_rep[$i]){
        $nzd_cnt++;
        $nzd_arr[$nzd_cnt] = (-1)**$the_sign * $csd_rep[$i] * 2**($i-1);
      }
    }
  }

  return ($nzd_cnt, @nzd_arr);
}

sub extract_paths{
  my ($paths_file) = @_;

  my $paths_ok = 1;
  my $path_algo = " ";
  my $path_high2low = " ";

  if (-e $paths_file){
    my $the_index = 0;
    my $init_index = 0;
    my $last_index = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $paths_file)){
      while (my $the_line = <$file_header>){
        chomp $the_line;
        #print "$the_line \n";

        $the_index = index ($the_line, "=");

        if ($the_index >= 0){
          $init_index = skip_spaces_forward($the_line, 0);
          $last_index = skip_spaces_backward($the_line, $the_index-1);
          my $the_solver = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_solver: $the_solver \n";

          $init_index = skip_spaces_forward($the_line, $the_index+1);
          $last_index = skip_spaces_backward($the_line, length($the_line));
          my $the_path = substr($the_line, $init_index, $last_index-$init_index+1);
          #print "the_path: $the_path \n";

          if ($the_path =~ /[0-9a-zA-Z_]/ ){
            if (($the_tech == 2 or $the_tech == 8) and $the_solver eq "mcm_algo"){
              $path_algo = $the_path;
            }
            elsif (($the_tech == 2 or $the_tech == 8) and $the_solver eq "mcm_high2low"){
              $path_high2low = $the_path;
            }
            elsif ($the_tech == 3 and  $the_solver eq "cavm_algo"){
              $path_algo = $the_path;
            }
            elsif ($the_tech == 3 and $the_solver eq "cavm_high2low"){
              $path_high2low = $the_path;
            }
            elsif ($the_tech == 4 and $the_aim eq "area" and $the_solver eq "cmvm_algo"){
              $path_algo = $the_path;
            }
            elsif ($the_tech == 4 and $the_aim eq "delay" and $the_solver eq "cmvm_dc_algo"){
              $path_algo = $the_path;
            }
            elsif ($the_tech == 4 and $the_solver eq "cmvm_high2low"){
              $path_high2low = $the_path;
            }
            elsif (($the_tech == 5 or $the_tech == 9 or $the_tech == 11)and $the_solver eq "cmul_high2low"){
              $path_algo = $the_path;
              $path_high2low = $the_path;
            }
          }
          else{
            $paths_ok = 0;
          }
        }
      }

      if ($path_algo eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the shift-adds algorithm could not be extracted from the $paths_file file! \n", RESET;
      }
      if ($path_high2low eq " "){
        $paths_ok = 0;
        print RED, "[ERROR] The path to the high2low algorithm could not be extracted from the $paths_file file! \n", RESET;
      }

      close ($file_header);
    }
    else{
      print RED, "[ERROR] Could not open the $paths_file file! \n", RESET;
    }
  }
  else{
    print RED, "[ERROR] Could not find the $paths_file file including paths to solvers! \n", RESET;
  }

  return ($paths_ok, $path_algo, $path_high2low);
}

sub file_read_weights{
  my $is_err = 0;
  my $layer_cnt = 0;
  my @layer_arr = ();
  my @weight_flt_mat = ();

  my $init_index = 0;
  my $last_index = 0;

  if (open (my $fid_weight, '<:encoding(UTF-8)', $file_weight)){
    my $the_line = <$fid_weight>;
    my $length_line = length($the_line);
    chomp $the_line;
    #print "[INFO] The line: $the_line \n";
    #sleep 1;

    $init_index = index($the_line, "[");
    if ($init_index != -1){
      $init_index++;

      my $the_end = 0;
      while (!$the_end){
        $last_index = $init_index;
        while (substr($the_line, $last_index, 1) ne " " and substr($the_line, $last_index, 1) ne "]"){
          $last_index++;

          if ($last_index > $length_line){
            $the_end = 1;
            last;
          }
        }

        my $the_val = substr($the_line, $init_index, $last_index-$init_index) + 0.0;
        #print "the_val: $the_val \n";
        #sleep 1;

        $layer_cnt++;
        $layer_arr[$layer_cnt] = $the_val;

        if (substr($the_line, $last_index, 1) eq "]"){
          $the_end = 1;
        }
        else{
          $init_index = skip_spaces_forward($the_line, $last_index);
        }
      }

      my $in_cnt = 0;
      my $out_cnt = 0;
      my $layer_num = 0;
      while ($the_line = <$fid_weight>){
        chomp ($the_line);
        my $length_line = length($the_line);
        #print "the_line: $the_line \n";
        #sleep 1;

        if (index($the_line, "Layer ") != -1){
          if ($layer_num){
            if ($out_cnt != $layer_arr[$layer_num+1]){
              $is_err = 1;
              print "[ERROR] The number of output entries at $layer_num layer does not match with the specified one! \n";
              last;
            }
          }

          $layer_num++;
          $out_cnt = 0;
          $in_cnt = 0;
        }
        else{
          $out_cnt++;
          $in_cnt = 0;

          $init_index = skip_spaces_forward($the_line, 0);
          if ($init_index < $length_line){
            $the_end = 0;
            while (!$the_end){
              $last_index = $init_index;

              while (substr($the_line, $last_index, 1) ne " "){
                $last_index++;

                if ($last_index > $length_line){
                  $the_end = 1;
                  last;
                }
              }

              my $the_val = substr ($the_line, $init_index, $last_index-$init_index) + 0.0;
              #print "the_val: $the_val \n";
              #sleep 1;

              $in_cnt++;
              $weight_flt_mat[$layer_num][$out_cnt][$in_cnt] = $the_val;

              if (!$the_end){
                $init_index = skip_spaces_forward($the_line, $last_index);

                if ($init_index >= $length_line){
                  $the_end = 1;
                }
              }
            }
            if ($in_cnt != $layer_arr[$layer_num]+1){
              $is_err = 1;
              print "[ERROR] The number of input entries on the $out_cnt neuron at $layer_num layer does not match with the specified one! \n";
              last;
            }
          }
        }
        if ($is_err){
          last;
        }
      }
    }
    else{
      print "[ERROR] The layer definitions should have started with left square bracket on the first line\n";
    }

    close ($fid_weight);
  }
  else{
    print "[ERROR] Could not open the $file_weight file \n";
  }

  return ($is_err, $layer_cnt, \@layer_arr, \@weight_flt_mat);
}

sub write_module_io_wei{
  my ($fid_ver, $module_name, $pi_cnt, $po_cnt, $pi_size, $po_size, $layer_cnt, $layer_arr_ref, $wo_size_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @wo_size = @ {$wo_size_ref};
  
  printf $fid_ver "module %0s (", $module_name;
  foreach my $i (1 .. $pi_cnt){
    printf $fid_ver "in%0d, ", $i;
  }
  foreach my $i (2 .. $layer_cnt){
    foreach my $j (1 .. $layer_arr[$i]){
      printf $fid_ver "w%0d_%0d, ", $i, $j;
    }
  }
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "out%0d); \n", $po_cnt;

  printf $fid_ver "\n";
  
  printf $fid_ver "input signed [%0d:0] ", $pi_size-1; 
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_ver "in%0d, ", $i;
  }
  printf $fid_ver "in%0d; \n", $pi_cnt;
  foreach my $i (2 .. $layer_cnt){
    foreach my $j (1 .. $layer_arr[$i]){
      if ($wo_size[$i-1][$j]){
        printf $fid_ver "input [%0d:0] w%0d_%0d; \n", $wo_size[$i-1][$j]-1, $i, $j; 
      }
    }
  }
  printf $fid_ver "output signed [%0d:0] ", $po_size-1; 
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "out%0d; \n", $po_cnt;

  printf $fid_ver "\n";
}

sub write_layer_module_io_wei{
  my ($fid_ver, $module_name, $layer_index, $pi_cnt, $po_cnt, $pi_size, $po_size, @wo_size) = @_;
  
  printf $fid_ver "module %0s (", $module_name;
  foreach my $i (1 .. $pi_cnt){
    printf $fid_ver "in%0d, ", $i;
  }
  foreach my $i (1 .. $po_cnt){
    printf $fid_ver "w%0d, ", $i;
  }
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "out%0d); \n", $po_cnt;

  printf $fid_ver "\n";
  
  printf $fid_ver "input signed [%0d:0] ", $pi_size-1; 
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_ver "in%0d, ", $i;
  }
  printf $fid_ver "in%0d; \n", $pi_cnt;
  foreach my $i (1 .. $po_cnt){
    printf $fid_ver "input [%0d:0] w%0d; \n", $wo_size[$layer_index-1][$i]-1, $i; 
  }
  printf $fid_ver "output signed [%0d:0] ", $po_size-1; 
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "out%0d; \n", $po_cnt;

  printf $fid_ver "\n";
}

sub write_module_io{
  my ($fid_ver, $module_name, $layer_index, $pi_cnt, $po_cnt, $pi_size, $po_size) = @_;
  
  if (!$is_creg or $layer_index){
    printf $fid_ver "module %0s (", $module_name;
  }
  elsif ($is_creg and !$layer_index){
    printf $fid_ver "module %0s (rst_n, clk, ", $module_name;
  }
  foreach my $i (1 .. $pi_cnt){
    printf $fid_ver "in%0d, ", $i;
  }
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "out%0d); \n", $po_cnt;

  printf $fid_ver "\n";
  
  if ($is_creg and !$layer_index){
    printf $fid_ver "input rst_n, clk; \n";
  }
  printf $fid_ver "input signed [%0d:0] ", $pi_size-1;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_ver "in%0d, ", $i;
  }
  printf $fid_ver "in%0d; \n", $pi_cnt;

  printf $fid_ver "output signed [%0d:0] ", $po_size-1; 
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "out%0d; \n", $po_cnt;

  printf $fid_ver "\n";
}

sub write_module_io_mac{
  my ($fid_ver, $module_name, $layer_index, $pi_cnt, $po_cnt, $pi_size, $po_size) = @_;
  
  printf $fid_ver "module %0s (rst_n, clk, ", $module_name;
  if ($layer_index > 2){
    printf $fid_ver "en_in, ";
  }
  foreach my $i (1 .. $pi_cnt){
    printf $fid_ver "in%0d, ", $i;
  }
  foreach my $i (1 .. $po_cnt){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "en_out); \n";

  printf $fid_ver "\n";
  
  printf $fid_ver "input rst_n, clk; \n";
  if ($layer_index > 2){
    printf $fid_ver "input en_in; \n";
  }
  printf $fid_ver "input signed [%0d:0] ", $pi_size-1;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_ver "in%0d, ", $i;
  }
  printf $fid_ver "in%0d; \n", $pi_cnt;

  printf $fid_ver "output signed [%0d:0] ", $po_size-1; 
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_ver "out%0d, ", $i;
  }
  printf $fid_ver "out%0d; \n", $po_cnt;
  printf $fid_ver "output en_out; \n";

  printf $fid_ver "\n";
}

sub write_verilog_activation_function{
  my ($fid_ver, $layer_index, $po_cnt, $po_size, $po_width_arr_ref, $act_fun_arr_ref) = @_;
  my @act_fun_arr = @ {$act_fun_arr_ref};
  my @po_width_arr = @ {$po_width_arr_ref};

  if ($act_fun_arr[$layer_index] eq "relu"){
    foreach my $i (1 .. $po_cnt){
      if ($po_width_arr[$i] >= $po_size){
        printf $fid_ver "assign out%0d = (neuron%0d < 0) ? %0d'd0 : neuron%0d[%0d:%0d]; \n", $i, $i, $po_size, $i, $po_width_arr[$i]-1, $po_width_arr[$i]-$po_size; 
      }
      else{
        printf $fid_ver "assign out%0d = (neuron%0d < 0) ? %0d'd0 : neuron%0d; \n", $i, $i, $po_size, $i; 
      }
    }
  }
  elsif ($act_fun_arr[$layer_index] eq "lin"){
    foreach my $i (1 .. $po_cnt){
      if ($po_width_arr[$i] >= $po_size){
        printf $fid_ver "assign out%0d = neuron%0d[%0d:%0d]; \n", $i, $i, $po_width_arr[$i]-1, $po_width_arr[$i]-$po_size; 
      }
      else{
        printf $fid_ver "assign out%0d = neuron%0d; \n", $i, $i; 
      }
    }
  }
  elsif ($act_fun_arr[$layer_index] eq "htanh"){
    foreach my $i (1 .. $po_cnt){
      printf $fid_ver "assign out%0d = (neuron%0d <= \$signed(-%0d'd%0d)) ? -%0d'd%0d : (neuron%0d >= \$signed(%0d'd%0d)) ? %0d'd%0d : neuron%0d[%0d:0]; \n", $i, $i, $po_size, 2**($po_size-1), $po_size, 2**($po_size-1), $i, $po_size, 2**($po_size-1)-1, $po_size, 2**($po_size-1)-1, $i, $po_size-1; 
    }
  }
  elsif ($act_fun_arr[$layer_index] eq "hsig"){
    foreach my $i (1 .. $po_cnt){
      printf $fid_ver "assign out%0d = (neuron%0d <= \$signed(-%0d'd%0d)) ? %0d'd0 : (neuron%0d >= \$signed(%0d'd%0d)) ? %0d'd%0d : {1'b0, !neuron%0d[%0d], neuron%0d[%0d:1]}; \n", $i, $i, $po_size, 2**($po_size-1), $po_size, $i, $po_size, 2**($po_size-1)-1, $po_size, 2**($po_size-1)-1, $i, $po_width_arr[$i]-1, $i, $po_size-2; 
    }
  }
  elsif ($act_fun_arr[$layer_index] eq "satlin"){
    foreach my $i (1 .. $po_cnt){
      printf $fid_ver "assign out%0d = (neuron%0d < 0) ? %d'd0 : (neuron%0d >= \$signed(%0d'd%0d)) ? %0d'd%0d : neuron%0d[%0d:0]; \n", $i, $i, $po_size, $i, $po_size, 2**($po_size-1)-1, $po_size, 2**($po_size-1)-1, $i, $po_size-1; 
    }
  }
}

sub write_layer_verilog_mac_mcmmux{
  my ($file_path, $file_name, $fid_ver, $path_algo, $path_high2low, $layer_index, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};

  my $pi_size = ($layer_index == 2) ? $in_width : $out_width;
  my $pi_cnt = $layer_arr[$layer_index-1];
  my $po_cnt = $layer_arr[$layer_index];
  my $po_size = $out_width;
 
  my $max_po_width = 0;
  my @po_width_arr = ();
  my @bias_shift_arr = ();
  my @muladd_width_arr = ();
  my @muladd_shift_arr = ();
  my @max_weight_width_arr = ();
  foreach my $i (1 .. $po_cnt){
    #Add the weights
    my $weight_sum = 0;
    my $signed_width = 0;
    my $min_shift = 9**9**9;
    $max_weight_width_arr[$i] = 0;
    foreach my $j (1 .. $pi_cnt){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$j]);

      if ($weight_mat[$layer_index-1][$i][$j] > 0){
        $signed_width = POSIX::floor(log($weight_mat[$layer_index-1][$i][$j])/log(2))+2;

        #compute the minimum left shift on weights
        my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($weight_mat[$layer_index-1][$i][$j]);
        if ($the_shift < $min_shift){
          $min_shift = $the_shift;
        }
      }
      elsif ($weight_mat[$layer_index-1][$i][$j] < 0){
        $signed_width = POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$j]))/log(2))+1;

        #compute the minimum left shift on weights
        my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($weight_mat[$layer_index-1][$i][$j]);
        if ($the_shift < $min_shift){
          $min_shift = $the_shift;
        }
      }
      if ($signed_width > $max_weight_width_arr[$i]){
        $max_weight_width_arr[$i] = $signed_width;
      }
    }
    $muladd_shift_arr[$i] = $min_shift;
    if ($weight_sum){
      $muladd_width_arr[$i] = POSIX::ceil(log(2**$pi_size*$weight_sum)/log(2));
    }
    else{
      $muladd_width_arr[$i] = 0;
    }

    #Add the bias
    if ($is_nit){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::floor(log($weight_sum)/log(2))+2; 
    }
    else{
      my $the_neuron = 2**$pi_size*$weight_sum + abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::ceil(log($the_neuron)/log(2)); 
    }

    if ($po_width_arr[$i] > $max_po_width){
      $max_po_width = $po_width_arr[$i];
    }
  }

  #Setting the bit-width of each neuron to the maximum bit-width in case of linear and RELU 
  if (${$act_fun_arr_ref}[$layer_index] eq "lin" or ${$act_fun_arr_ref}[$layer_index] eq "relu"){
    if ($max_po_width < $po_size) {$max_po_width = $po_size;}
    foreach my $i (1 .. $po_cnt){
      $po_width_arr[$i] = $max_po_width;
    }
  }

  #Write the module, inputs, and outputs
  my $layer_name = "ann_layer" . $layer_index;
  write_module_io_mac($fid_ver, $layer_name, $layer_index, $pi_cnt, $po_cnt, $pi_size, $po_size);

  foreach my $i (1 .. $po_cnt){
    if ($weight_mat[$layer_index-1][$i][$pi_cnt+1] > 0){
      my $signed_width = POSIX::floor(log($weight_mat[$layer_index-1][$i][$pi_cnt+1])/log(2))+2;
      printf $fid_ver "wire signed [%0d:0] b%0d; assign b%0d = %0d'd%0d; \n", $signed_width-1, $i, $i, $signed_width, $weight_mat[$layer_index-1][$i][$pi_cnt+1];
    }
    elsif ($weight_mat[$layer_index-1][$i][$pi_cnt+1] < 0){
      my $signed_width = POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]))/log(2))+1;
      printf $fid_ver "wire signed [%0d:0] b%0d; assign b%0d = -%0d'd%0d; \n", $signed_width-1, $i, $i, $signed_width, abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
    }
    if ($muladd_width_arr[$i]){
      printf $fid_ver "wire signed [%0d:0] mac_out%0d; \n", $muladd_width_arr[$i]-1, $i;
    }
    if ($po_width_arr[$i] >= $po_size){
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_width_arr[$i]-1, $i;
    }
    else{
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_size-1, $i;
    }
  } 
  printf $fid_ver "\n";

  #Write the MAC instance for all the neurons in the layer
  printf $fid_ver "%0s_layer%0d layer%0d_mac_ins(.rst_n(rst_n), .clk(clk), ", $file_name, $layer_index, $layer_index;
  if ($layer_index > 2){
    printf $fid_ver ".en_in(en_in), ";
  }
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_ver ".x%0d(in%0d), ", $i, $i;
  }
  printf $fid_ver ".x%0d(in%0d)", $pi_cnt, $pi_cnt;
  my $out_cnt = 0;
  foreach my $i (1 .. $po_cnt){
    if ($muladd_width_arr[$i]){
      $out_cnt++;
      printf $fid_ver ", .y%0d(mac_out%0d)", $out_cnt, $i;
    }
  }
  printf $fid_ver ", .en_out(en_out)); \n";
  printf $fid_ver "\n";
  
  #Generate the neuron and add the bias value
  foreach my $i (1 .. $po_cnt){
    if ($weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (mac_out%0d>>>%0d) + b%0d; \n", $i, $i, $pi_size-1, $i;
      }
      else{
        printf $fid_ver "assign neuron%0d = mac_out%0d + b%0d; \n", $i, $i, $i;
      }
    }
    elsif(!$weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (mac_out%0d>>>%0d); \n", $i, $i, $pi_size-1;
      }
      else{
        printf $fid_ver "assign neuron%0d = mac_out%0d; \n", $i, $i;
      }
    }
    elsif($weight_mat[$layer_index-1][$i][$pi_cnt+1] and !$muladd_width_arr[$i]){
      printf $fid_ver "assign neuron%0d = b%0d; \n", $i, $i;
    }
  }
  printf $fid_ver "\n";

  #Write the activation function and the outputs
  write_verilog_activation_function($fid_ver, $layer_index, $po_cnt, $po_size, \@po_width_arr, $act_fun_arr_ref);

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";

  my ($say_add) = generate_verilog_code_layer_mac_mcmmux($file_path, $file_name, $path_algo, $path_high2low, $layer_index, $layer_arr_ref, \@weight_mat, \@muladd_width_arr, \@muladd_shift_arr, \@max_weight_width_arr);

  return ($say_add, \@muladd_width_arr, \@po_width_arr);
}

sub write_layer_verilog_mac{
  my ($file_path, $file_name, $fid_ver, $layer_index, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};

  my $pi_size = ($layer_index == 2) ? $in_width : $out_width;
  my $pi_cnt = $layer_arr[$layer_index-1];
  my $po_cnt = $layer_arr[$layer_index];
  my $po_size = $out_width;

  my $max_po_width = 0;
  my @po_width_arr = ();
  my @bias_shift_arr = ();
  my @muladd_width_arr = ();
  my @muladd_shift_arr = ();
  my @max_weight_width_arr = ();
  foreach my $i (1 .. $po_cnt){
    #Add the weights
    my $weight_sum = 0;
    my $signed_width = 0;
    my $min_shift = 9**9**9;
    $max_weight_width_arr[$i] = 0;
    foreach my $j (1 .. $pi_cnt){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$j]);

      if ($weight_mat[$layer_index-1][$i][$j] > 0){
        $signed_width = POSIX::floor(log($weight_mat[$layer_index-1][$i][$j])/log(2))+2;

        #compute the minimum left shift on weights
        my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($weight_mat[$layer_index-1][$i][$j]);
        if ($the_shift < $min_shift){
          $min_shift = $the_shift;
        }
      }
      elsif ($weight_mat[$layer_index-1][$i][$j] < 0){
        $signed_width = POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$j]))/log(2))+1;

        #compute the minimum left shift on weights
        my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($weight_mat[$layer_index-1][$i][$j]);
        if ($the_shift < $min_shift){
          $min_shift = $the_shift;
        }
      }
      if ($signed_width > $max_weight_width_arr[$i]){
        $max_weight_width_arr[$i] = $signed_width;
      }
    }
    $muladd_shift_arr[$i] = $min_shift;
    if ($weight_sum){
      $muladd_width_arr[$i] = POSIX::ceil(log(2**$pi_size*$weight_sum)/log(2));
    }
    else{
      $muladd_width_arr[$i] = 0;
    }

    #Add the bias
    if ($is_nit){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::floor(log($weight_sum)/log(2))+2; 
    }
    else{
      my $the_neuron = 2**$pi_size*$weight_sum + abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::ceil(log($the_neuron)/log(2)); 
    }

    if ($po_width_arr[$i] > $max_po_width){
      $max_po_width = $po_width_arr[$i];
    }
  }

  #Setting the bit-width of each neuron to the maximum bit-width in case of linear and RELU 
  if (${$act_fun_arr_ref}[$layer_index] eq "lin" or ${$act_fun_arr_ref}[$layer_index] eq "relu"){
    if ($max_po_width < $po_size) {$max_po_width = $po_size;}
    foreach my $i (1 .. $po_cnt){
      $po_width_arr[$i] = $max_po_width;
    }
  }

  #Write the module, inputs, and outputs
  my $layer_name = "ann_layer" . $layer_index;
  write_module_io_mac($fid_ver, $layer_name, $layer_index, $pi_cnt, $po_cnt, $pi_size, $po_size);

  foreach my $i (1 .. $po_cnt){
    if ($weight_mat[$layer_index-1][$i][$pi_cnt+1] > 0){
      my $signed_width = POSIX::floor(log($weight_mat[$layer_index-1][$i][$pi_cnt+1])/log(2))+2;
      printf $fid_ver "wire signed [%0d:0] b%0d; assign b%0d = %0d'd%0d; \n", $signed_width-1, $i, $i, $signed_width, $weight_mat[$layer_index-1][$i][$pi_cnt+1];
    }
    elsif ($weight_mat[$layer_index-1][$i][$pi_cnt+1] < 0){
      my $signed_width = POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]))/log(2))+1;
      printf $fid_ver "wire signed [%0d:0] b%0d; assign b%0d = -%0d'd%0d; \n", $signed_width-1, $i, $i, $signed_width, abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
    }
    if ($muladd_width_arr[$i]){
      printf $fid_ver "wire signed [%0d:0] mac_out%0d; \n", $muladd_width_arr[$i]-1, $i;
    }
    if ($po_width_arr[$i] >= $po_size){
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_width_arr[$i]-1, $i;
    }
    else{
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_size-1, $i;
    }
  } 
  printf $fid_ver "\n";

  #Write the MAC instance for all the neurons in the layer
  printf $fid_ver "%0s_layer%0d layer%0d_mac_ins(.rst_n(rst_n), .clk(clk), ", $file_name, $layer_index, $layer_index;
  if ($layer_index > 2){
    printf $fid_ver ".en_in(en_in), ";
  }
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_ver ".x%0d(in%0d), ", $i, $i;
  }
  printf $fid_ver ".x%0d(in%0d)", $pi_cnt, $pi_cnt;
  my $out_cnt = 0;
  foreach my $i (1 .. $po_cnt){
    if ($muladd_width_arr[$i]){
      $out_cnt++;
      printf $fid_ver ", .y%0d(mac_out%0d)", $out_cnt, $i;
    }
  }
  printf $fid_ver ", .en_out(en_out)); \n";
  printf $fid_ver "\n";
  
  #Generate the neuron and add the bias value
  foreach my $i (1 .. $po_cnt){
    if ($weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (mac_out%0d>>>%0d) + b%0d; \n", $i, $i, $pi_size-1, $i;
      }
      else{
        printf $fid_ver "assign neuron%0d = mac_out%0d + b%0d; \n", $i, $i, $i;
      }
    }
    elsif(!$weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (mac_out%0d>>>%0d); \n", $i, $i, $pi_size-1;
      }
      else{
        printf $fid_ver "assign neuron%0d = mac_out%0d>>>%0d; \n", $i, $i;
      }
    }
    elsif($weight_mat[$layer_index-1][$i][$pi_cnt+1] and !$muladd_width_arr[$i]){
      printf $fid_ver "assign neuron%0d = b%0d; \n", $i, $i;
    }
  }
  printf $fid_ver "\n";

  #Write the activation function and the outputs
  write_verilog_activation_function($fid_ver, $layer_index, $po_cnt, $po_size, \@po_width_arr, $act_fun_arr_ref);

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";

  generate_verilog_code_layer_mac($file_path, $file_name, $layer_index, $layer_arr_ref, \@weight_mat, \@muladd_width_arr, \@muladd_shift_arr, \@max_weight_width_arr);

  return (\@muladd_width_arr, \@po_width_arr);
}

sub write_layer_verilog_shift_adds{
  my ($file_path, $file_name, $fid_ver, $layer_index, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};

  my $pi_size = ($layer_index == 2) ? $in_width : $out_width;
  my $pi_cnt = $layer_arr[$layer_index-1];
  my $po_cnt = $layer_arr[$layer_index];
  my $po_size = $out_width;

  #print "pi_cnt: $pi_cnt \n";
  #print "po_cnt: $po_cnt \n";
  #print "layer_index: $layer_index \n";

  my $max_po_width = 0;
  my @po_width_arr = ();
  my @muladd_width_arr = ();
  foreach my $i (1 .. $po_cnt){
    #Add the weights
    my $weight_sum = 0;
    foreach my $j (1 .. $pi_cnt){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$j]);
    }
    if ($weight_sum){
      $muladd_width_arr[$i] = POSIX::ceil(log(2**$pi_size*$weight_sum)/log(2));
    }
    else{
      $muladd_width_arr[$i] = 0;
    }

    #Add the bias
    if ($is_nit){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::floor(log($weight_sum)/log(2))+2;
    }
    else{
      my $the_neuron = 2**$pi_size*$weight_sum + abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::ceil(log($the_neuron)/log(2));
    }

    if ($po_width_arr[$i] > $max_po_width){
      $max_po_width = $po_width_arr[$i];
    }
  }

  #Setting the bit-width of each neuron to the maximum bit-width in case of linear and RELU 
  if (${$act_fun_arr_ref}[$layer_index] eq "lin" or ${$act_fun_arr_ref}[$layer_index] eq "relu"){
    foreach my $i (1 .. $po_cnt){
      $po_width_arr[$i] = $max_po_width;
    }
  }

  #Write the module, inputs, and outputs
  my $layer_name = "ann_layer" . $layer_index;
  write_module_io($fid_ver, $layer_name, $layer_index, $pi_cnt, $po_cnt, $pi_size, $po_size);

  foreach my $i (1 .. $po_cnt){
    if ($weight_mat[$layer_index-1][$i][$pi_cnt+1] > 0){
      my $signed_width = POSIX::floor(log($weight_mat[$layer_index-1][$i][$pi_cnt+1])/log(2))+2;
      printf $fid_ver "wire signed [%0d:0] b%0d; assign b%0d = %0d'd%0d; \n", $signed_width-1, $i, $i, $signed_width, $weight_mat[$layer_index-1][$i][$pi_cnt+1];
    }
    elsif ($weight_mat[$layer_index-1][$i][$pi_cnt+1] < 0){
      my $signed_width = POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]))/log(2))+1;
      printf $fid_ver "wire signed [%0d:0] b%0d; assign b%0d = -%0d'd%0d; \n", $signed_width-1, $i, $i, $signed_width, abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
    }
    if ($muladd_width_arr[$i]){
      printf $fid_ver "wire signed [%0d:0] sa_out%0d; \n", $muladd_width_arr[$i]-1, $i;
    }
    if ($po_width_arr[$i] >= $po_size){
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_width_arr[$i]-1, $i;
    }
    else{
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_size-1, $i;
    }
  } 
  printf $fid_ver "\n";

  printf $fid_ver "%0s_layer%0d layer%0d_sa_ins(", $file_name, $layer_index, $layer_index;
  
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_ver ".x%0d(in%0d), ", $i, $i;
  }
  printf $fid_ver ".x%0d(in%0d) ", $pi_cnt, $pi_cnt;
  my $out_cnt = 0;
  foreach my $i (1 .. $po_cnt){
    if ($muladd_width_arr[$i]){
      $out_cnt++;
      printf $fid_ver ", .y%0d(sa_out%0d)", $out_cnt, $i;
    }
  }
  printf $fid_ver "); \n";
  printf $fid_ver "\n";
  
  #Generate the neuron and add the bias value
  foreach my $i (1 .. $po_cnt){
    if ($weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (sa_out%0d>>>%0d) + b%0d; \n", $i, $i, $pi_size-1, $i;
      }
      else{
        printf $fid_ver "assign neuron%0d = sa_out%0d + b%0d; \n", $i, $i, $i;
      }
    }
    elsif(!$weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (sa_out%0d>>>%0d); \n", $i, $i, $pi_size-1;
      }
      else{
        printf $fid_ver "assign neuron%0d = sa_out%0d; \n", $i, $i;
      }
    }
    elsif($weight_mat[$layer_index-1][$i][$pi_cnt+1] and !$muladd_width_arr[$i]){
      printf $fid_ver "assign neuron%0d = b%0d; \n", $i, $i;
    }
  }
  printf $fid_ver "\n";

  #Write the activation function and the outputs
  write_verilog_activation_function($fid_ver, $layer_index, $po_cnt, $po_size, \@po_width_arr, $act_fun_arr_ref);

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";

  return (\@muladd_width_arr, \@po_width_arr);
}

sub write_layer_verilog_weight_constant{
  my ($file_path, $file_name, $fid_ver, $layer_index, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};

  my $po_cnt = $layer_arr[$layer_index];
  my $pi_cnt = $layer_arr[$layer_index-1];
  my $pi_size = $in_width;
  my $po_size = $out_width;

  #print "pi_cnt: $pi_cnt \n";
  #print "po_cnt: $po_cnt \n";
  #print "layer_index: $layer_index \n";

  my $max_po_width = 0;
  my @po_width_arr = ();
  my @muladd_width_arr = ();
  foreach my $i (1 .. $po_cnt){
    #Add the weights
    my $weight_sum = 0;
    foreach my $j (1 .. $pi_cnt){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$j]);
    }
    if ($weight_sum){
      $muladd_width_arr[$i] = POSIX::ceil(log(2**$pi_size*$weight_sum)/log(2));
    }
    else{
      $muladd_width_arr[$i] = 0;
    }

    #Add the bias
    if ($is_nit){
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::floor(log($weight_sum)/log(2))+2;
    }
    else{
      my $the_neuron = 2**$pi_size*$weight_sum + abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $po_width_arr[$i] = POSIX::ceil(log($the_neuron)/log(2));
    }


    if ($po_width_arr[$i] > $max_po_width){
      $max_po_width = $po_width_arr[$i];
    }
  }

  #Setting the bit-width of each neuron to the maximum bit-width in case of linear and RELU 
  if (${$act_fun_arr_ref}[$layer_index] eq "lin" or ${$act_fun_arr_ref}[$layer_index] eq "relu"){
    foreach my $i (1 .. $po_cnt){
      $po_width_arr[$i] = $max_po_width;
    }
  }

  #Write the module, inputs, and outputs
  my $layer_name = "ann_layer" . $layer_index;
  write_module_io($fid_ver, $layer_name, $layer_index, $pi_cnt, $po_cnt, $pi_size, $po_size);

  #Write the variables
  foreach my $i (1 .. $po_cnt){
    foreach my $j (1 .. $pi_cnt+1){
      if ($weight_mat[$layer_index-1][$i][$j]){
        if ($weight_mat[$layer_index-1][$i][$j] > 0){
          my $signed_width = POSIX::floor(log($weight_mat[$layer_index-1][$i][$j])/log(2))+2;
          printf $fid_ver "wire signed [%0d:0] w%0d_%0d; assign w%0d_%0d = %0d'd%0d; \n", $signed_width-1, $i, $j, $i, $j, $signed_width, $weight_mat[$layer_index-1][$i][$j];
        }
        elsif ($weight_mat[$layer_index-1][$i][$j] < 0){
          my $signed_width = POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$j]))/log(2))+1;
          printf $fid_ver "wire signed [%0d:0] w%0d_%0d; assign w%0d_%0d = -%0d'd%0d; \n", $signed_width-1, $i, $j, $i, $j, $signed_width, abs($weight_mat[$layer_index-1][$i][$j]);
        }
      }
    }
    if ($muladd_width_arr[$i]){
      printf $fid_ver "wire signed [%0d:0] muladd%0d; \n", $muladd_width_arr[$i]-1, $i;
    }
    if ($po_width_arr[$i] >= $po_size){
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_width_arr[$i]-1, $i;
    }
    else{
      printf $fid_ver "wire signed [%0d:0] neuron%0d; \n", $po_size-1, $i;
    }
    printf $fid_ver "\n";
  }
  
  #Compute the muladd output
  foreach my $i (1 .. $po_cnt){
    #Muladd
    if ($muladd_width_arr[$i]){
      my $first_nonzero = 0;
      printf $fid_ver "assign muladd%0d =", $i;
      foreach my $j (1 .. $pi_cnt){
        if ($weight_mat[$layer_index-1][$i][$j]){
          if (!$first_nonzero){
            $first_nonzero = 1;
            printf $fid_ver " in%0d*w%0d_%0d", $j, $i, $j;
          }
          else{
            printf $fid_ver " + in%0d*w%0d_%0d", $j, $i, $j;
          }
        }
      }
      printf $fid_ver "; \n";
    }

    #Neuron
    if ($weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (muladd%0d>>>%0d) + w%0d_%0d; \n", $i, $i, $pi_size-1, $i, $pi_cnt+1;
      }
      else{
        printf $fid_ver "assign neuron%0d = muladd%0d + w%0d_%0d; \n", $i, $i, $i, $pi_cnt+1;
      }
    }
    elsif (!$weight_mat[$layer_index-1][$i][$pi_cnt+1] and $muladd_width_arr[$i]){
      if ($is_nit){
        printf $fid_ver "assign neuron%0d = (muladd%0d>>>%0d); \n", $i, $i, $pi_size-1;
      }
      else{
        printf $fid_ver "assign neuron%0d = muladd%0d; \n", $i, $i;
      }
    }
    elsif ($weight_mat[$layer_index-1][$i][$pi_cnt+1] and !$muladd_width_arr[$i]){
      printf $fid_ver "assign neuron%0d = w%d_%d; \n", $i, $i, $pi_cnt+1;
    }
  }
  printf $fid_ver "\n";

  #Write the activation function and the outputs
  write_verilog_activation_function($fid_ver, $layer_index, $po_cnt, $po_size, \@po_width_arr, $act_fun_arr_ref);

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";

  return (\@po_width_arr);
}

sub generate_verilog_code_shift_adds{
  my ($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @ver_file_arr = @ {$ver_file_arr_ref};
 
  my @muladd_width_mat = ();
  my @neuron_width_mat = ();
  
  my $pi_size = $in_width;
  my $po_size = $out_width;
  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];

  print "[INFO] Generating the Verilog file... \n";

  open (my $fid_ver, '>', $file_verilog);

  foreach (my $i=2; $i<=$layer_cnt; $i++){
    my $ver_file = $file_name . "_layer" . $i . ".v";
    printf $fid_ver "`include \"%0s\" \n", $ver_file;
    
    $ver_file_cnt++;
    $ver_file_arr[$ver_file_cnt] = $ver_file;
  }
  printf $fid_ver "\n";

  #Write the module, inputs, and outputs
  write_module_io($fid_ver, $file_name, 0, $pi_cnt, $po_cnt, $pi_size, $po_size);

  #Write the variables  
  if ($layer_cnt > 2){
    for (my $i=3; $i<=$layer_cnt; $i++){
      printf $fid_ver "wire signed [%0d:0] ", $po_size-1;
      foreach my $j (1 .. $layer_arr[$i-1]-1){
        printf $fid_ver "l%0do%0d, ", $i-1, $j;
      }
      printf $fid_ver "l%0do%0d; \n", $i-1, $layer_arr[$i-1];
    }
    printf $fid_ver "\n";
  }
  
  if ($is_creg){
    my $out_cur = "";
    my $out_next = "";
    foreach my $out_index (1 .. $po_cnt){
      if ($out_index != $po_cnt){
        $out_cur .= "out" . $out_index . "_cur, ";
        $out_next .= "out" . $out_index . "_next, ";
      }
      else{
        $out_cur .= "out" . $out_index . "_cur;";
        $out_next .= "out" . $out_index . "_next;";
      }
    }
    printf $fid_ver "reg [%0d:0] %0s \n", $po_size-1, $out_next;
    printf $fid_ver "wire [%0d:0] %0s \n", $po_size-1, $out_cur;
    printf $fid_ver "\n";
  }
  
  #Instantiate the layers
  for (my $i=2; $i<=$layer_cnt; $i++){
    printf $fid_ver "ann_layer%0d layer%0d_ins (", $i, $i;
    foreach my $j (1 .. $layer_arr[$i-1]){
      if ($i == 2){
        printf $fid_ver ".in%0d(in%0d), ", $j, $j;
      }
      else{
        printf $fid_ver ".in%0d(l%0do%0d), ", $j, $i-1, $j;
      }
    }

    foreach my $j (1 .. $layer_arr[$i]-1){
      if ($i == $layer_cnt){
        if (!$is_creg){
          printf $fid_ver ".out%0d(out%0d), ", $j, $j;
        }
        else{
          printf $fid_ver ".out%0d(out%0d_cur), ", $j, $j;
        }
      }
      else{
        printf $fid_ver ".out%0d(l%0do%0d), ", $j, $i, $j;
      }
    }
    if ($i == $layer_cnt){
      if (!$is_creg){
        printf $fid_ver ".out%0d(out%0d)); \n", $layer_arr[$i], $layer_arr[$i];
      }
      else{
        printf $fid_ver ".out%0d(out%0d_cur)); \n", $layer_arr[$i], $layer_arr[$i];
      }
    }
    else{
      printf $fid_ver ".out%0d(l%0do%0d)); \n", $layer_arr[$i], $i, $layer_arr[$i];
    }
  }

  if ($is_creg){
    printf $fid_ver "\n";
    printf $fid_ver "always @ (negedge rst_n, posedge clk) begin \n";
    printf $fid_ver "  if (rst_n == 1'b0) begin \n";
    foreach my $out_index (1 .. $po_cnt){
      printf $fid_ver "    out%0d_next <= %0d'b0; \n", $out_index, $po_size;
    }
    printf $fid_ver "  end \n";
    printf $fid_ver "  else begin \n";
    foreach my $out_index (1 .. $po_cnt){
      printf $fid_ver "    out%0d_next <= out%0d_cur; \n", $out_index, $out_index;
    }
    printf $fid_ver "  end \n";
    printf $fid_ver "end \n";
    printf $fid_ver "\n";
    foreach my $out_index (1 .. $po_cnt){
      printf $fid_ver "assign out%0d = out%0d_next; \n", $out_index, $out_index;
    }
  }

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";
  
  #Write the modules for layers
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my ($muladd_width_arr_ref, $neuron_width_arr_ref) = write_layer_verilog_shift_adds($file_path, $file_name, $fid_ver, $layer_index, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref);
    @{${\@muladd_width_mat}[$layer_index]} = @{$muladd_width_arr_ref};
    @{${\@neuron_width_mat}[$layer_index]} = @{$neuron_width_arr_ref};
  }

  close ($fid_ver);
  
  return ($ver_file_cnt, \@ver_file_arr, \@muladd_width_mat, \@neuron_width_mat);
}

sub generate_verilog_code_mac_mcmmux{
  my ($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $path_algo, $path_high2low, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @ver_file_arr = @ {$ver_file_arr_ref};
 
  my $add_cnt = 0;
  my @muladd_width_mat = ();
  my @neuron_width_mat = ();

  my $weight_size = 0;
  my $pi_size = $in_width;
  my $po_size = $out_width;
  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];

  print "[INFO] Generating the Verilog file... \n";
  open (my $fid_ver, '>', $file_verilog);

  #Write the Verilog files to be included
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my $mac_file = $file_name . "_layer" . $layer_index . ".v";
    printf $fid_ver "`include \"%0s\" \n", $mac_file;
    $ver_file_cnt++;
    $ver_file_arr[$ver_file_cnt] = $mac_file;
    
    my $mcm_file = $file_name . "_mcm_layer" . $layer_index . ".v";
    printf $fid_ver "`include \"%0s\" \n", $mcm_file;
    $ver_file_cnt++;
    $ver_file_arr[$ver_file_cnt] = $mcm_file;
  }
  printf $fid_ver "\n";

  #Write the module, inputs, and outputs
  write_module_io_mac($fid_ver, $file_name, 0, $pi_cnt, $po_cnt, $pi_size, $po_size);

  #Write the variables  
  if ($layer_cnt > 2){
    for (my $i=3; $i<=$layer_cnt; $i++){
      printf $fid_ver "wire signed [%0d:0] ", $po_size-1;
      foreach my $j (1 .. $layer_arr[$i-1]-1){
        printf $fid_ver "l%0do%0d, ", $i-1, $j;
      }
      printf $fid_ver "l%0do%0d; \n", $i-1, $layer_arr[$i-1];
    }
    printf $fid_ver "\n";
  }
  
  #Instantiate the layers
  for (my $i=2; $i<=$layer_cnt; $i++){
    printf $fid_ver "ann_layer%0d layer%0d_ins (.rst_n(rst_n), .clk(clk), ", $i, $i;
    if ($i != 2){
      printf $fid_ver ".en_in(en_out%d), ", $i-1;
    }
    foreach my $j (1 .. $layer_arr[$i-1]){
      if ($i == 2){
        printf $fid_ver ".in%0d(in%0d), ", $j, $j;
      }
      else{
        printf $fid_ver ".in%0d(l%0do%0d), ", $j, $i-1, $j;
      }
    }
    foreach my $j (1 .. $layer_arr[$i]){
      if ($i == $layer_cnt){
        printf $fid_ver ".out%0d(out%0d), ", $j, $j;
      }
      else{
        printf $fid_ver ".out%0d(l%0do%0d), ", $j, $i, $j;
      }
    }
    if ($i == $layer_cnt){
      printf $fid_ver ".en_out(en_out)); \n";
    }
    else{
      printf $fid_ver ".en_out(en_out%d)); \n", $i;
    }
  }

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";

  #Write the modules for layers
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my ($say_add, $muladd_width_arr_ref, $neuron_width_arr_ref) = write_layer_verilog_mac_mcmmux($file_path, $file_name, $fid_ver, $path_algo, $path_high2low, $layer_index, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref);
    $add_cnt += $say_add;
    @{${\@muladd_width_mat}[$layer_index]} = @{$muladd_width_arr_ref};
    @{${\@neuron_width_mat}[$layer_index]} = @{$neuron_width_arr_ref};
  }
  
  close ($fid_ver);
  
  return ($add_cnt, $ver_file_cnt, \@ver_file_arr, \@muladd_width_mat, \@neuron_width_mat);
}

sub generate_verilog_code_mac{
  my ($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @ver_file_arr = @ {$ver_file_arr_ref};
 
  my @muladd_width_mat = ();
  my @neuron_width_mat = ();

  my $weight_size = 0;
  my $pi_size = $in_width;
  my $po_size = $out_width;
  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];

  print "[INFO] Generating the Verilog file... \n";

  open (my $fid_ver, '>', $file_verilog);

  #Write the Verilog files to be included
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my $mac_file = $file_name . "_layer" . $layer_index . ".v";
    printf $fid_ver "`include \"%0s\" \n", $mac_file;
    $ver_file_cnt++;
    $ver_file_arr[$ver_file_cnt] = $mac_file;
  }
  printf $fid_ver "\n";

  #Write the module, inputs, and outputs
  write_module_io_mac($fid_ver, $file_name, 0, $pi_cnt, $po_cnt, $pi_size, $po_size);

  #Write the variables  
  if ($layer_cnt > 2){
    for (my $i=3; $i<=$layer_cnt; $i++){
      printf $fid_ver "wire signed [%0d:0] ", $po_size-1;
      foreach my $j (1 .. $layer_arr[$i-1]-1){
        printf $fid_ver "l%0do%0d, ", $i-1, $j;
      }
      printf $fid_ver "l%0do%0d; \n", $i-1, $layer_arr[$i-1];
    }
    printf $fid_ver "\n";
  }
  
  #Instantiate the layers
  for (my $i=2; $i<=$layer_cnt; $i++){
    printf $fid_ver "ann_layer%0d layer%0d_ins (.rst_n(rst_n), .clk(clk), ", $i, $i;
    if ($i != 2){
      printf $fid_ver ".en_in(en_out%d), ", $i-1;
    }
    foreach my $j (1 .. $layer_arr[$i-1]){
      if ($i == 2){
        printf $fid_ver ".in%0d(in%0d), ", $j, $j;
      }
      else{
        printf $fid_ver ".in%0d(l%0do%0d), ", $j, $i-1, $j;
      }
    }
    foreach my $j (1 .. $layer_arr[$i]){
      if ($i == $layer_cnt){
        printf $fid_ver ".out%0d(out%0d), ", $j, $j;
      }
      else{
        printf $fid_ver ".out%0d(l%0do%0d), ", $j, $i, $j;
      }
    }
    if ($i == $layer_cnt){
      printf $fid_ver ".en_out(en_out)); \n";
    }
    else{
      printf $fid_ver ".en_out(en_out%d)); \n", $i;
    }
  }

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";
  
  #Write the modules for layers
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my ($muladd_width_arr_ref, $neuron_width_arr_ref) = write_layer_verilog_mac($file_path, $file_name, $fid_ver, $layer_index, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref);
    @{${\@muladd_width_mat}[$layer_index]} = @{$muladd_width_arr_ref};
    @{${\@neuron_width_mat}[$layer_index]} = @{$neuron_width_arr_ref};
  }
  
  close ($fid_ver);
  
  return ($ver_file_cnt, \@ver_file_arr, \@muladd_width_mat, \@neuron_width_mat);
}

sub generate_verilog_code_smac{
  my ($file_path, $file_name, $file_verilog, $path_high2low, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref, $exap_map_mat_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @exap_map_mat = @ {$exap_map_mat_ref};
  my @ver_file_arr = @ {$ver_file_arr_ref};
 
  my $pi_size = $in_width;
  my $po_size = $out_width;
  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];
  my $input_width = ($pi_size > $po_size) ? $pi_size : $po_size;
 
  my $the_message;
  my $size_match = 1;
  my @muladd_width_mat = ();
  my @neuron_width_mat = ();

  #Number of layers excluding the input layer
  my $layer_num = $layer_cnt - 1;
  
  #Maximum number of inputs and neurons
  my $max_input = 0;
  my $max_neuron = 0;
  foreach my $layer_index (1 .. $layer_cnt){
    if ($layer_index < $layer_cnt){
      if ($layer_arr[$layer_index] > $max_input){
        $max_input = $layer_arr[$layer_index];
      }
    }
    if ($layer_index > 1){
      if ($layer_arr[$layer_index] > $max_neuron){
        $max_neuron = $layer_arr[$layer_index];
      }
    }
  }

  #Bitwidths of maximum number of neurons and inputs
  my $nn_width = POSIX::floor(log($max_neuron)/log(2))+1;
  my $ni_width = POSIX::floor(log($max_input+1)/log(2))+1; #Think always plus 1 of the maximum input 

  #Bitwidths of layer neuron and input counters
  my $lc_width = POSIX::floor(log($layer_cnt)/log(2))+1;
  my $nc_width = POSIX::floor(log($max_neuron)/log(2))+1;
  my $ic_width = POSIX::floor(log($max_input+1)/log(2))+1; #Think always plus 1 of the maximum input 

  #Maximum bitwidth of weight, bias, mac_mul_sum, and mac_bias_sum
  my $mms_width = 0;
  my $mbs_width = 0;
  my $bias_width = 0;
  my $weight_width = 0;
  my $weight_shift = 9**9**9;
  foreach (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my $layer_in_size = ($layer_index == 2) ? $in_width : $out_width;

    foreach my $out_index (1 .. $layer_arr[$layer_index]){
      my $weight_sum = 0;

      foreach my $in_index (1 .. $layer_arr[$layer_index-1]){
        my $the_weight = $weight_mat[$layer_index-1][$out_index][$in_index];
        if ($the_weight){
          my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($the_weight);
          if ($the_shift < $weight_shift){
            $weight_shift = $the_shift;
          }
        }
        
        $weight_sum += abs($the_weight);

        if ($the_weight){
          my $weight_size;
          if ($the_weight > 0){
            $weight_size = POSIX::floor(log($the_weight)/log(2))+2;
          }
          elsif ($the_weight < 0){
            $weight_size = POSIX::ceil(log(abs($the_weight))/log(2))+1;
          }
          if ($weight_size > $weight_width){
            $weight_width = $weight_size;
          }
        }
      }

      if ($weight_sum){
        $muladd_width_mat[$layer_index][$out_index] = POSIX::ceil(log(2**$layer_in_size*$weight_sum)/log(2));

        if ($muladd_width_mat[$layer_index][$out_index] > $mms_width){
          $mms_width = $muladd_width_mat[$layer_index][$out_index];
        }
      }
      else{
        $muladd_width_mat[$layer_index][$out_index] = 0;
      }

      my $the_bias = $weight_mat[$layer_index-1][$out_index][$layer_arr[$layer_index-1]+1];
      if ($the_bias){
        my $bias_size;
        if ($the_bias > 0){
          $bias_size = POSIX::floor(log($the_bias)/log(2))+2;
        }
        elsif ($the_bias < 0){
          $bias_size = POSIX::ceil(log(abs($the_bias))/log(2))+1;
        }

        if ($bias_size > $bias_width){
          $bias_width = $bias_size;
        }
      }

      #Add the bias
      if ($is_nit){
        $weight_sum += abs($the_bias);
        $neuron_width_mat[$layer_index][$out_index] = POSIX::floor(log($weight_sum)/log(2))+2; 
      }
      else{
        my $the_neuron = 2**$layer_in_size*$weight_sum + abs($the_bias);
        $neuron_width_mat[$layer_index][$out_index] = POSIX::ceil(log($the_neuron)/log(2)); 
      }

      if ($neuron_width_mat[$layer_index][$out_index] > $mbs_width){
        $mbs_width = $neuron_width_mat[$layer_index][$out_index];
      }
    }
  }

  #Update the necessary width values according to weight_shift 
  $weight_width -= $weight_shift;
  $mms_width -= $weight_shift;

  #Setting the bit-width of each neuron to the maximum bit-width in case of linear and RELU 
  if ($mbs_width < $out_width){$mbs_width = $out_width;}
  foreach my $layer_index (2 .. $layer_cnt){
    if (${$act_fun_arr_ref}[$layer_index] eq "lin" or ${$act_fun_arr_ref}[$layer_index] eq "relu"){
      foreach my $out_index (1 .. $layer_arr[$layer_index]){
        $neuron_width_mat[$layer_index][$out_index] = $mbs_width;
      }
    }
  }

  print "[INFO] Generating the Verilog file... \n";
  open (my $fid_ver, '>', $file_verilog);

  if ($size_match){
    #Write the module name
    printf $fid_ver "module %0s (rst_n, clk, ", $file_name;
    foreach my $i (1 .. $pi_cnt){
      printf $fid_ver "in%0d, ", $i;
    }
    foreach my $i (1 .. $po_cnt){
      printf $fid_ver "out%0d, ", $i;
    }
    printf $fid_ver "en_out); \n";

    #Write the parameters
    $the_message = <<END_OF_MESSAGE;

parameter iw = $pi_size;         //Bitwidth of ANN inputs  
parameter ow = $po_size;         //Bitwidth of ANN outputs  
parameter bw = $bias_width;         //Maximum bitwidth of bias
parameter ww = $weight_width;         //Maximum bitwidth of weights
parameter icw = $ic_width;        //Bitwidth of the input counter (Think always plus 1 of the maximum)
parameter lcw = $lc_width;        //Bitwidth of the layer counter
parameter ncw = $nc_width;        //Bitwidth of the neuron counter
parameter nnw = $nn_width;        //Maximum bitwidth of the number of neurons in neuron_arr
parameter niw = $ni_width;        //Maximum bitwidth of the number of inputs in input_arr (Think always plus 1 of the maximum input)
parameter mmsw = $mms_width;      //Maximum bitwidth of mac_mul_sum signal
parameter mbsw = $mbs_width;      //Maximum bitwidth of mac_bias_sum signal
parameter layer_num = $layer_num;  //Number of layers excluding the input layer
parameter max_neuron = $max_neuron; //Maximum number of neurons in each layer
parameter max_input = $max_input;  //Maximum number of inputs in each layer

END_OF_MESSAGE
    printf $fid_ver "$the_message";
    
    #write the inputs and outputs
    printf $fid_ver "input rst_n, clk; \n";
    printf $fid_ver "input signed [iw-1:0] ";
    foreach my $i (1 .. $pi_cnt-1){
      printf $fid_ver "in%0d, ", $i;
    }
    printf $fid_ver "in%0d; \n", $pi_cnt;
    printf $fid_ver "output signed [ow-1:0] "; 
    foreach my $i (1 .. $po_cnt-1){
      printf $fid_ver "out%0d, ", $i;
    }
    printf $fid_ver "out%0d; \n", $po_cnt;
    printf $fid_ver "output en_out; \n";

    $the_message = <<END_OF_MESSAGE;

// Layer output register and the one in parallel
reg [ow-1:0] layer_out_par [1:max_neuron];
reg [ow-1:0] layer_out [1:max_neuron];

// Variables for matrices
wire signed [ww-1:0] weight_mat [1:layer_num][1:max_neuron][1:max_input]; //Weight matrix indicates the integer weight values in each layer (first) in each neuron (second), and in each input (third)
wire signed [bw-1:0] bias_mat [1:layer_num][1:max_neuron]; //Bias matrix indicates the integer bias values in each layer (first) and in each neuron (second)
wire [nnw-1:0] neuron_arr [1:layer_num]; //indicates the number of neurons in each layer
wire [niw-1:0] input_arr [1:layer_num]; //indicates the number of inputs in each layer

END_OF_MESSAGE
    printf $fid_ver "$the_message";
    
    printf $fid_ver "// Assignments to the ANN parameters \n";
    foreach my $layer_index (2 .. $layer_cnt){
      printf $fid_ver "assign input_arr[%0d] = %0d'd%0d; \n", $layer_index-1, $ni_width, $layer_arr[$layer_index-1];
    }
    printf $fid_ver "\n";
    foreach my $layer_index (2 .. $layer_cnt){
      printf $fid_ver "assign neuron_arr[%0d] = %0d'd%0d; \n", $layer_index-1, $nn_width, $layer_arr[$layer_index];
    }
    printf $fid_ver "\n";
    foreach my $layer_index (2 ..  $layer_cnt){
      foreach my $out_index (1 .. $layer_arr[$layer_index]){
        my $the_bias = $weight_mat[$layer_index-1][$out_index][$layer_arr[$layer_index-1]+1];
        if ($the_bias > 0){
          printf $fid_ver "assign bias_mat[%0d][%0d] = %0d'd%0d; \n", $layer_index-1, $out_index, $bias_width, $the_bias;
        }
        else{
          printf $fid_ver "assign bias_mat[%0d][%0d] = -%0d'd%0d; \n", $layer_index-1, $out_index, $bias_width, abs($the_bias);
        }
      }
    }
    printf $fid_ver "\n";
    foreach my $layer_index (2 ..  $layer_cnt){
      foreach my $out_index (1 .. $layer_arr[$layer_index]){
        foreach my $in_index (1 .. $layer_arr[$layer_index-1]){
          my $the_weight = $weight_mat[$layer_index-1][$out_index][$in_index];
          if ($the_weight > 0){
            printf $fid_ver "assign weight_mat[%0d][%0d][%0d] = %0d'd%0d; \n", $layer_index-1, $out_index, $in_index, $weight_width, $the_weight/(2**$weight_shift);
          }
          else{
            printf $fid_ver "assign weight_mat[%0d][%0d][%0d] = -%0d'd%0d; \n", $layer_index-1, $out_index, $in_index, $weight_width, abs($the_weight/(2**$weight_shift));
          }
        }
      }
    }

    $the_message = <<END_OF_MESSAGE;

// Variables for counters
reg [lcw-1:0] layer_counter;
reg [ncw-1:0] neuron_counter;
reg [icw-1:0] input_counter;

// Control logic for the input counter
always @ (posedge clk) begin
  if (rst_n == 1'b0) begin
    input_counter <= $ic_width\'d0;
  end
  else begin
    if (input_counter <= input_arr[layer_counter]) begin
      input_counter <= input_counter + 1;
    end
    else begin
      input_counter <= $ic_width\'d0;
    end
  end
end

// Control logic for the neuron counter
always @ (posedge clk) begin
  if (rst_n == 1'b0) begin
    neuron_counter <= $nc_width\'d0;
  end
  else begin
    if (input_counter == $ic_width\'d0) begin
      if (neuron_counter < neuron_arr[layer_counter]) begin
        neuron_counter <= neuron_counter + 1;
      end
      else begin
        neuron_counter <= $nc_width\'d1;
      end
    end
  end
end

// Control logic for the layer counter
always @ (posedge clk) begin
  if (rst_n == 1'b0) begin
    layer_counter <= $lc_width\'d1;
  end
  else begin
    if (neuron_counter == neuron_arr[layer_counter] && input_counter == $ic_width\'d0) begin
      if (layer_counter <= layer_num) begin
        layer_counter <= layer_counter + 1;
      end
      else begin
        layer_counter <= layer_counter;
      end
    end
  end
end

// en_out signal behaviour
assign en_out = (layer_counter > layer_num) ? 1'b1 : 1'b0;

//Declaring the MAC parameters
reg signed [iw-1:0] mac_input;
reg signed [ww-1:0] mac_weight;
reg signed [bw-1:0] neuron_bias;
reg signed [ow-1:0] neuron_output;
wire signed [mbsw-1:0] mac_bias_sum;
reg signed [mmsw-1:0] mac_mul_sum_next;
wire signed [mmsw-1:0] mac_mul_sum_cur;

END_OF_MESSAGE
    printf $fid_ver "$the_message";

    printf $fid_ver "// MAC input assignment \n";
    printf $fid_ver "always @ (*) begin \n";
    printf $fid_ver "  if (layer_counter == %0d'd1) begin \n", $lc_width;
    printf $fid_ver "    case (input_counter) \n";
    foreach my $in_index (1 .. $pi_cnt){
      printf $fid_ver "      %0d'd%0d : begin mac_input = in%0d; end \n", $ic_width, $in_index, $in_index;
    }
    printf $fid_ver "      default : begin mac_input = %0d'd0; end \n", $pi_size;
    printf $fid_ver "    endcase \n";
    printf $fid_ver "  end \n";
    $the_message = <<END_OF_MESSAGE;
  else begin
    if (input_counter >= $ic_width\'d1 && input_counter <= input_arr[layer_counter]) begin
      mac_input = layer_out_par[input_counter];
    end
    else begin
      mac_input = $pi_size\'d0;
    end
  end
end

// MAC weight assignment
always @ (*) begin
  if (layer_counter >= $lc_width\'d1 && layer_counter <= layer_num && neuron_counter >= $nc_width\'d1 && neuron_counter <= neuron_arr[layer_counter] && input_counter >= $ic_width\'d1 && input_counter <= input_arr[layer_counter]) begin
    mac_weight = weight_mat[layer_counter][neuron_counter][input_counter];
  end
  else begin
    mac_weight = $weight_width\'d0;
  end
end

// Multiply and accumulate
END_OF_MESSAGE
    printf $fid_ver "$the_message";

    printf $fid_ver "assign mac_mul_sum_cur = mac_input * mac_weight + mac_mul_sum_next; \n";

    $the_message = <<END_OF_MESSAGE;

// Register in the MAC
always @ (posedge clk) begin
  if (rst_n == 1'b0) begin
    mac_mul_sum_next <= $mms_width\'d0;
  end
  else begin
    if (input_counter == 'd0) begin
      mac_mul_sum_next <= $mms_width\'d0;
    end
    else begin
      mac_mul_sum_next <= mac_mul_sum_cur;
    end
  end
end

// Bias value in the neuron
always @ (*) begin
  if (layer_counter >= $lc_width\'d1 && layer_counter <= layer_num && neuron_counter >= $nc_width\'d1 && neuron_counter <= neuron_arr[layer_counter]) begin
    neuron_bias = bias_mat[layer_counter][neuron_counter];
  end
end

END_OF_MESSAGE
    printf $fid_ver "$the_message";

    printf $fid_ver "// Add bias \n";
    if ($is_nit){
      if ($weight_shift){
        printf $fid_ver "wire signed [%d:0] mms_output; \n", $mms_width+$weight_shift-1;
        printf $fid_ver "assign mms_output = (mac_mul_sum_next<<<%0d); \n", $weight_shift;
        printf $fid_ver "assign mac_bias_sum = (mms_output>>>%0d) + neuron_bias; \n", $pi_size-1;
      }
      else{
        printf $fid_ver "assign mac_bias_sum = (mac_mul_sum_next>>>%0d) + neuron_bias; \n", $pi_size-1;
      }
    }
    else{
      if ($weight_shift){
        printf $fid_ver "assign mac_bias_sum = (mac_mul_sum_next<<<%0d) + neuron_bias; \n", $weight_shift;
      }
      else{
        printf $fid_ver "assign mac_bias_sum = mac_mul_sum_next + neuron_bias; \n";
      }
    }
    printf $fid_ver "\n";
    printf $fid_ver "// Apply the activation function \n";
    printf $fid_ver "always @ (*) begin \n";
    printf $fid_ver "  case (layer_counter) \n";
    foreach my $layer_index (2 .. $layer_cnt){
      if (${$act_fun_arr_ref}[$layer_index] eq "lin"){
        printf $fid_ver "    %0d'd%0d : begin neuron_output = mac_bias_sum[%0d:%0d]; end \n", $lc_width, $layer_index-1, $mbs_width-1, $mbs_width-$po_size;
      }
      elsif (${$act_fun_arr_ref}[$layer_index] eq "hsig"){
        printf $fid_ver "    %0d'd%0d : begin neuron_output = (mac_bias_sum <= \$signed(-%0d'd%0d)) ? %0d'd0 : (mac_bias_sum >= \$signed(%0d'd%0d)) ? %0d'd%0d : {1'b0, !mac_bias_sum[%0d], mac_bias_sum[%0d:1]}; end \n", $lc_width, $layer_index-1, $mbs_width, 2**($po_size-1), $po_size, $mbs_width, 2**($po_size-1)-1, $po_size, 2**($po_size-1)-1, $mbs_width-1, $po_size-2;
      }
      elsif (${$act_fun_arr_ref}[$layer_index] eq "htanh"){
        printf $fid_ver "    %0d'd%0d : begin neuron_output = (mac_bias_sum <= \$signed(-%0d'd%0d)) ? -%0d'd%0d : (mac_bias_sum >= \$signed(%0d'd%0d)) ? %0d'd%0d : mac_bias_sum[%0d:0]; end \n", $lc_width, $layer_index-1, $mbs_width, 2**($po_size-1), $po_size, 2**($po_size-1), $mbs_width, 2**($po_size-1)-1, $po_size, 2**($po_size-1)-1, $po_size-1;
      }
      elsif (${$act_fun_arr_ref}[$layer_index] eq "relu"){
        if ($neuron_width_mat[$layer_index][1] >= $out_width){
          printf $fid_ver "    %0d'd%0d : begin neuron_output = (mac_bias_sum < 0) ? %0d'd0 : mac_bias_sum[%0d:%0d]; end \n", $lc_width, $layer_index-1, $po_size, $mbs_width-1, $mbs_width-$po_size;
        }
        else{
          printf $fid_ver "    %0d'd%00d : begin neuron_output = (mac_bias_sum < 0) ? %0d'd0 : mac_bias_sum[%0d:0]; end \n", $lc_width, $layer_index-1, $po_size, $po_size-1;
        }
      }
      elsif (${$act_fun_arr_ref}[$layer_index] eq "satlin"){
        printf $fid_ver "    %0d'd%0d : begin neuron_output = (mac_bias_sum < 0) ? %0d'0 : (mac_bias_sum >= \$signed(%0d'd%0d)) ? %0d'd%0d : mac_bias_sum[%0d:0]; end \n", $lc_width, $layer_index-1, $po_size, $mbs_width, 2**($po_size-1)-1, $po_size, 2**($po_size-1)-1, $po_size-1;
      }
    }
    printf $fid_ver "    default : begin neuron_output = %0d'd0; end \n", $po_size;
    printf $fid_ver "  endcase \n";
    printf $fid_ver "end \n";
     
    $the_message = <<END_OF_MESSAGE;

// Index of the for loop
integer i;

// Store the neuron output into layer output registers
always @ (posedge clk) begin
  if (rst_n == 1'b0) begin 
    for (i = 1; i <= max_neuron; i = i+1) begin
      layer_out[i] <= $po_size\'d0;
    end
  end
  else begin
    if (input_counter > input_arr[layer_counter]) begin
      layer_out[neuron_counter] <= neuron_output;
    end
  end
end

always @ (posedge clk) begin
  if (rst_n == 1'b0) begin
    for (i = 1; i <= max_neuron; i = i+1) begin
      layer_out_par[i] <= $po_size\'d0;
    end
  end
  else begin
    if (input_counter == $ic_width\'d0 && neuron_counter == neuron_arr[layer_counter]) begin
      for (i = 1; i <= max_neuron; i = i+1) begin
        layer_out_par[i] <= layer_out[i];
      end
    end
  end
end

END_OF_MESSAGE
    printf $fid_ver "$the_message";

    foreach my $out_index (1 .. $po_cnt){
      printf $fid_ver "assign out%0d = (en_out == 1'b1) ? layer_out_par[%0d] : %0d'd0; \n", $out_index, $out_index, $po_size;
    }
    printf $fid_ver "\n";
    printf $fid_ver "endmodule \n";
    printf $fid_ver "\n";
  }
   
  close ($fid_ver);
  
  return ($ver_file_cnt, \@ver_file_arr, \@muladd_width_mat, \@neuron_width_mat);
}

sub generate_verilog_code_weight_constant{
  my ($file_path, $file_name, $file_verilog, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
 
  my @neuron_width_mat = ();

  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];
  my $pi_size = $in_width;
  my $po_size = $out_width;

  print "[INFO] Generating the Verilog file... \n";

  open (my $fid_ver, '>', $file_verilog);

  #Write the module, inputs, and outputs
  write_module_io($fid_ver, $file_name, 0, $pi_cnt, $po_cnt, $pi_size, $po_size);

  #Write the variables
  if ($layer_cnt > 2){
    for (my $i=3; $i<=$layer_cnt; $i++){
      printf $fid_ver "wire signed [%0d:0] ", $po_size-1;
      foreach my $j (1 .. $layer_arr[$i-1]-1){
        printf $fid_ver "l%0do%0d, ", $i-1, $j;
      }
      printf $fid_ver "l%0do%0d; \n", $i-1, $layer_arr[$i-1];
    }
    printf $fid_ver "\n";
  }

  if ($is_creg){
    my $out_cur = "";
    my $out_next = "";
    foreach my $out_index (1 .. $po_cnt){
      if ($out_index != $po_cnt){
        $out_cur .= "out" . $out_index . "_cur, ";
        $out_next .= "out" . $out_index . "_next, ";
      }
      else{
        $out_cur .= "out" . $out_index . "_cur;";
        $out_next .= "out" . $out_index . "_next;";
      }
    }
    printf $fid_ver "reg [%0d:0] %0s \n", $po_size-1, $out_next;
    printf $fid_ver "wire [%0d:0] %0s \n", $po_size-1, $out_cur;
    printf $fid_ver "\n";
  }
  
  #Instantiate the layers
  for (my $i=2; $i<=$layer_cnt; $i++){
    printf $fid_ver "ann_layer%0d layer%0d_ins (", $i, $i;
    foreach my $j (1 .. $layer_arr[$i-1]){
      if ($i == 2){
        printf $fid_ver ".in%0d(in%0d), ", $j, $j;
      }
      else{
        printf $fid_ver ".in%0d(l%0do%0d), ", $j, $i-1, $j;
      }
    }

    foreach my $j (1 .. $layer_arr[$i]-1){
      if ($i == $layer_cnt){
        if (!$is_creg){
          printf $fid_ver ".out%0d(out%0d), ", $j, $j;
        }
        else{
          printf $fid_ver ".out%0d(out%0d_cur), ", $j, $j;
        }
      }
      else{
        printf $fid_ver ".out%0d(l%0do%0d), ", $j, $i, $j;
      }
    }
    if ($i == $layer_cnt){
      if (!$is_creg){
        printf $fid_ver ".out%0d(out%0d)); \n", $layer_arr[$i], $layer_arr[$i];
      }
      else{
        printf $fid_ver ".out%0d(out%0d_cur)); \n", $layer_arr[$i], $layer_arr[$i];
      }
    }
    else{
      printf $fid_ver ".out%0d(l%0do%0d)); \n", $layer_arr[$i], $i, $layer_arr[$i];
    }
  }

  if ($is_creg){
    printf $fid_ver "\n";
    printf $fid_ver "always @ (negedge rst_n, posedge clk) begin \n";
    printf $fid_ver "  if (rst_n == 1'b0) begin \n";
    foreach my $out_index (1 .. $po_cnt){
      printf $fid_ver "    out%0d_next <= %0d'b0; \n", $out_index, $po_size;
    }
    printf $fid_ver "  end \n";
    printf $fid_ver "  else begin \n";
    foreach my $out_index (1 .. $po_cnt){
      printf $fid_ver "    out%0d_next <= out%0d_cur; \n", $out_index, $out_index;
    }
    printf $fid_ver "  end \n";
    printf $fid_ver "end \n";
    printf $fid_ver "\n";
    foreach my $out_index (1 .. $po_cnt){
      printf $fid_ver "assign out%0d = out%0d_next; \n", $out_index, $out_index;
    }
  }

  printf $fid_ver "\n";
  printf $fid_ver "endmodule \n";
  printf $fid_ver "\n";
  
  #Write the modules for layers
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my ($neuron_width_arr_ref) = write_layer_verilog_weight_constant($file_path, $file_name, $fid_ver, $layer_index, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref);
    @{${\@neuron_width_mat}[$layer_index]} = @{$neuron_width_arr_ref};
  }

  return (\@neuron_width_mat);
}

sub compute_output{
  my ($layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref, $test_in_arr_ref, $is_permit) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @act_fun_arr = @ {$act_fun_arr_ref};
  my @neuron_width_mat = @ {$neuron_width_mat_ref};

  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];
  my $po_size = $out_width;

  my @out_arr = ();
  my @in_arr = @ {dclone($test_in_arr_ref)};
 
  my @neuron_arr = ();

  for (my $layer_index=1; $layer_index<$layer_cnt; $layer_index++){
    my $in_cnt = $layer_arr[$layer_index];
    my $out_cnt = $layer_arr[$layer_index+1];
    my $muladd_rs = ($layer_index == 1) ? $in_width : $out_width;
    #print "muladd_rs: $muladd_rs \n";

    @neuron_arr = ();
    foreach my $out_index (1 .. $out_cnt){
      my $the_neuron = 0;
      #print "the_muladd: ";
      foreach my $in_index (1 .. $in_cnt){
        $the_neuron += $in_arr[$in_index]*$weight_mat[$layer_index][$out_index][$in_index];
      }
      if ($is_nit){
        $the_neuron = POSIX::floor($the_neuron/2**($muladd_rs-1));
      }
      $the_neuron += $weight_mat[$layer_index][$out_index][$in_cnt+1];
      $neuron_arr[$out_index] = $the_neuron;

      my $neuron_width = $neuron_width_mat[$layer_index+1][$out_index];

      if ($act_fun_arr[$layer_index+1] eq "lin"){
        if ($neuron_width > $po_size){
          $out_arr[$out_index] = POSIX::floor($the_neuron/2**($neuron_width-$po_size));
        }
        else{
          $out_arr[$out_index] = $the_neuron;
        }
      }
      elsif ($act_fun_arr[$layer_index+1] eq "relu"){
        if ($the_neuron < 0){
          $out_arr[$out_index] = 0;
        }
        else{
          if ($neuron_width > $po_size){
            $out_arr[$out_index] = POSIX::floor($the_neuron/2**($neuron_width-$po_size));
          }
          else{
            $out_arr[$out_index] = $the_neuron;
          }
        }
      }
      elsif ($act_fun_arr[$layer_index+1] eq "hsig"){
        if ($the_neuron <= (-1)*2**($po_size-1)){
          $out_arr[$out_index] = 0;
        }
        elsif ($the_neuron >= 2**($po_size-1)-1){
          $out_arr[$out_index] = 2**($po_size-1)-1;
        }
        else{
          $out_arr[$out_index] = POSIX::floor($the_neuron/2) + 2**($po_size-2);
        }
      }
      elsif ($act_fun_arr[$layer_index+1] eq "htanh"){
        if ($the_neuron <= (-1)*2**($po_size-1)){
          $out_arr[$out_index] = (-1)*2**($po_size-1);
        }
        elsif ($the_neuron >= 2**($po_size-1)-1){
          $out_arr[$out_index] = 2**($po_size-1)-1;
        }
        else{
          $out_arr[$out_index] = $the_neuron;
        }
      }
      elsif ($act_fun_arr[$layer_index+1] eq "satlin"){
        if ($the_neuron < 0){
          $out_arr[$out_index] = 0;
        }
        elsif ($the_neuron >= 2**($po_size-1)-1){
          $out_arr[$out_index] = 2**($po_size-1)-1;
        }
        else{
          $out_arr[$out_index] = $the_neuron;
        }
      }
    }
    if ($is_permit){print_array_contents("neuron_arr", $out_cnt, @neuron_arr);}
    @in_arr = @ {dclone(\@out_arr)};
    @out_arr = ();
  }
  
  return (@in_arr);
}

sub classification_compare_actual_expected_outputs{
  my ($test_cnt, $po_cnt, $act_out_arr_ref, $test_out_arr_ref) = @_;
  my @act_out_arr = @ {$act_out_arr_ref};
  my @test_out_arr = @ {$test_out_arr_ref};

  my $test_out = 0;
  my $test_label = 1;

  #Classification 
  if ($acc_tech == 1){
    my $acc_index = 0;
    my $max_index_cnt = 0;
    my @max_index_arr = ();
    my $max_val = (-1)*9**9**9;
    foreach my $i (1 .. $po_cnt){
      if ($test_out_arr[$i] > $max_val){
        $max_index_cnt = 0;
        @max_index_arr = ();
        $max_val = $test_out_arr[$i];

        $max_index_cnt++;
        $max_index_arr[$max_index_cnt] = $i;
      }
      elsif ($test_out_arr[$i] == $max_val){
        $max_index_cnt++;
        $max_index_arr[$max_index_cnt] = $i;
      }

      if ($act_out_arr[$i] == 1){
        $acc_index = $i;
      }
    }

    #print "max_index_cnt: $max_index_cnt \n";
    #print "acc_index: $acc_index \n";

    if ($max_index_cnt == 1){
      if ($acc_index == $max_index_arr[1]){
        $test_label = 1;
        #print "[INFO] For the $test_cnt test, the actual output is the same as the expected value! \n";
      }
      else{
        $test_label = 0;
        #print "[INFO] For the $test_cnt test, the actual output is not the same as the expected value! \n";
      }
    }
    else{
      $test_label = -1;
      #print "[INFO] For the $test_cnt test, multiple outputs have the same maximum value! \n";
    }

    $test_out = $max_index_arr[1];
  }

  return ($test_out, $test_label);
}

sub generate_test_patterns{
  my ($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref) = @_;

  my $the_acc = 0;
  my $tie_cnt = 0;
  my $test_cnt = 0;
  my @test_out_arr = ();
  my $pi_cnt = ${$layer_arr_ref}[1];
  my $po_cnt = ${$layer_arr_ref}[$layer_cnt];

  my $file_test_in = $file_path . $file_name . ".inputs";
  open (my $fid_in, '>', $file_test_in);
  my $file_test_out = $file_path . $file_name . ".outputs";
  open (my $fid_out, '>', $file_test_out);

  my $fid_label;
  my $file_label_out;
  if ($acc_tech){
    $file_label_out = $file_path . $file_name . ".results";
    open ($fid_label, '>', $file_label_out);
  }
  
  if ($the_test == 0){
    $test_cnt = $test_num;
    foreach my $i (1 .. $test_num){
      my @test_in_arr = ();
      foreach my $j (1 .. $pi_cnt){
        my $the_num = (rand() > 0.5) ? int(2**($in_width-1)*rand()) : (-1)*int((2**($in_width-1)-1)*rand());
        $test_in_arr[$j] = $the_num;
        
        if ($the_num < 0){
          $the_num += 2**$in_width;
        }

        my (@the_rep) = int2bin($the_num, $in_width);
        foreach (my $k=$in_width; $k>0; $k--){
          printf $fid_in "%0d", $the_rep[$k];
        }
      }
      printf $fid_in "\n";

      (@test_out_arr) = compute_output($layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref, \@test_in_arr, 0);
      foreach my $i (1 .. $po_cnt){
        my (@the_rep) = int2sign($test_out_arr[$i], $out_width);
        foreach my $j (1 .. $out_width){
          printf $fid_out "%0d", $the_rep[$out_width-$j+1];
        }
      }
      printf $fid_out "\n";
    }
  }
  elsif ($the_test == 1){
    my $cls_acc_cnt = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $dv_file)){
      while (my $the_line = <$file_header>){
        chomp $the_line;
        #print "the_line: $the_line \n";
        #sleep 1;

        my $is_err = 0;
        my $in_cnt = 0;
        my $last_index = 0;
        my $init_index = -1;
        my @test_in_arr = ();
        my $lline = length($the_line);

        #Extract the actual inputs from the dv_file
        while ($in_cnt != $pi_cnt){
          $init_index = skip_spaces_forward($the_line, $init_index+1);
          $last_index= $init_index;
          while (substr($the_line, $last_index, 1) ne "," and substr($the_line, $last_index, 1) ne ";"){
            $last_index++;

            if ($last_index >= $lline){
              $is_err = 1;
              last;
            }
          }

          if ($is_err){
            last;
          }
          else{
            my $the_num = substr($the_line, $init_index, $last_index-$init_index) + 0.0;

            $in_cnt++;
            $test_in_arr[$in_cnt] = $the_num;
            
            if ($the_num < 0){
              $the_num += 2**$in_width;
            }

            my (@the_rep) = int2bin($the_num, $in_width);
            foreach (my $k=$in_width; $k>0; $k--){
              printf $fid_in "%0d", $the_rep[$k];
            }

            $init_index = $last_index;
          }
        }
        printf $fid_in "\n";

        if (!$is_err){
          $test_cnt++;
          #Extract the actual outputs from the dv_file 
          if ($acc_tech){
            my $out_cnt = 0;
            my @act_out_arr = ();
            $init_index = index($the_line, ";");

            while ($out_cnt != $po_cnt){
              $init_index = skip_spaces_forward($the_line, $init_index+1);
              $last_index= $init_index;
              while (substr($the_line, $last_index, 1) ne "," and substr($the_line, $last_index, 1) ne " "){
                $last_index++;

                if ($last_index >= $lline){
                  $is_err = 1;
                  last;
                }
              }

              if ($is_err){
                last;
              }
              else{
                my $the_num = substr($the_line, $init_index, $last_index-$init_index) + 0.0;

                $out_cnt++;
                $init_index = $last_index;
                $act_out_arr[$out_cnt] = $the_num;
              }
            }

            if (!$is_err){
              (@test_out_arr) = compute_output($layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref, \@test_in_arr, 0);
              foreach my $i (1 .. $po_cnt){
                my (@the_rep) = int2sign($test_out_arr[$i], $out_width);
                foreach my $j (1 .. $out_width){
                  printf $fid_out "%0d", $the_rep[$out_width-$j+1];
                }
              }
              printf $fid_out "\n";

              #Compare the actual and expected outputs
              my ($test_out, $test_label) = classification_compare_actual_expected_outputs($test_cnt, $po_cnt, \@act_out_arr, \@test_out_arr);
              printf $fid_label "%0d ", $test_out;
              if ($test_label == 1){
                $cls_acc_cnt++;
                printf $fid_label "TRUE \n";
              }
              elsif ($test_label == 0){
                printf $fid_label "FALSE \n";
              }
              else{
                printf $fid_label "TIE \n";
                $tie_cnt++;
              }
            }
            else{
              print "[ERROR] Number of test outputs in the $dv_file is less than the number of outputs in the ANN design! \n";
            }
          }
        }
        else{
          print "[ERROR] Number of test inputs in the $dv_file is less than the number of inputs in the ANN design! \n";
        }
      }

      close ($file_header);
    }
    else{
      print "[ERROR] Could not open the $dv_file! \n";
    }

    if ($acc_tech){
      #Classification
      if ($acc_tech == 1){
        $the_acc = $cls_acc_cnt/$test_cnt;
        print "[INFO] $cls_acc_cnt test points out of $test_cnt give the right results with an accuracy of $the_acc where there are $tie_cnt ties! \n";
      }
      close ($fid_label);
    }
  }

  close ($fid_in);
  close ($fid_out);

  return ($test_cnt, $the_acc);
}

sub generate_testbench_mac{
  my ($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @neuron_width_mat = @ {$neuron_width_mat_ref};

  print "[INFO] Generating the test-bench... \n";

  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];
  
  my $file_in = $file_name . ".inputs";
  my $file_out = $file_name . ".outputs";
  my ($test_cnt, $the_acc) = generate_test_patterns($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref);
 
  my $module_tb = $file_name . "_tb";
  my $file_tb = $file_path . $module_tb . ".v";
  open (my $fid_tb, '>', $file_tb);

  #writing the module
  printf $fid_tb "module %0s (); \n", $module_tb;

  #writing the procedure
  printf $fid_tb "\n";
  printf $fid_tb "reg clk = 1'b0; \n";
  printf $fid_tb "reg rst_n = 1'b0; \n";
  printf $fid_tb "integer fid_out, test_index; \n";
  printf $fid_tb "reg [%0d:0] test_in_reg [0:%0d]; \n", $pi_cnt*$in_width-1, $test_cnt-1;
  printf $fid_tb "reg [%0d:0] test_out_reg [0:%0d]; \n", $po_cnt*$out_width-1, $test_cnt-1;
  printf $fid_tb "reg signed [%0d:0] ", $in_width-1;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_tb "in%0d, ", $i;
  }
  printf $fid_tb "in%0d;\n", $pi_cnt;
  printf $fid_tb "reg signed [%0d:0] ", $out_width-1;
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_tb "test_out%0d, ", $i;
  }
  printf $fid_tb "test_out%0d; \n", $po_cnt;
  printf $fid_tb "wire signed [%0d:0] ", $out_width-1;
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_tb "out%0d, ", $i;
  }
  printf $fid_tb "out%0d;\n", $po_cnt;
  printf $fid_tb "wire en_out; \n";
  printf $fid_tb "\n";

  printf $fid_tb "always #10 clk = !clk; \n";
  printf $fid_tb "\n";

  printf $fid_tb "initial begin \n";
  printf $fid_tb "  fid_out = \$fopen(\"sim.out\", \"w\"); \n";
  printf $fid_tb "  \$readmemb(\"%0s\", test_in_reg); \n", $file_in;
  printf $fid_tb "  \$readmemb(\"%0s\", test_out_reg); \n", $file_out;
  printf $fid_tb "\n";
  printf $fid_tb "  for (test_index=0; test_index<%0d; test_index=test_index+1) begin \n", $test_cnt;
  printf $fid_tb "    #15; rst_n = 1'b1; \n";
  printf $fid_tb "\n";
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_tb "    in%0d = test_in_reg[test_index][%0d:%0d]; \n", $i, $in_width*($pi_cnt-$i+1)-1, $in_width*($pi_cnt-$i);
    printf $fid_tb "    \$fwrite(fid_out, \"%%d, \", in%0d); \n", $i;
  }
  printf $fid_tb "    in%0d = test_in_reg[test_index][%0d:0]; \n", $pi_cnt, $in_width-1;
  printf $fid_tb "    \$fwrite(fid_out, \"%%d; \", in%d); \n", $pi_cnt;
  printf $fid_tb "\n";
  printf $fid_tb "    wait (en_out); \n";
  printf $fid_tb "\n";
  foreach my $i (1 .. $po_cnt){
    printf $fid_tb "    test_out%0d = test_out_reg[test_index][%0d:%0d]; \n", $i, $out_width*($po_cnt-$i+1)-1, $out_width*($po_cnt-$i);
  }
  printf $fid_tb "\n";
  printf $fid_tb "    #1; \n";
  printf $fid_tb "\n";
  if (!$exap_cmul){
    foreach my $i (1 .. $po_cnt){
      printf $fid_tb "    \$fwrite(fid_out, \"%%d, \", test_out%0d); \n", $i;
      printf $fid_tb "    if (test_out%0d !== out%0d) begin \n", $i, $i;
      printf $fid_tb "      \$display(\"[ERROR] %0d. output is not the same as the expected on the %%d test pattern!\", test_index); \$stop; \n", $i;
      printf $fid_tb "    end \n";
    }
    printf $fid_tb "\n";
    printf $fid_tb "    #10; rst_n = 1'b0;\n";
    printf $fid_tb "  end \n";
    printf $fid_tb "\n";
    printf $fid_tb "  \$fclose(fid_out); \n";
    printf $fid_tb "  \$display(\"[INFO] ANN design has just been verified!\"); \n";
  }
  else{
    foreach my $i (1 .. $po_cnt-1){
      printf $fid_tb "    \$fwrite(fid_out, \"%%d, \", out%0d); \n", $i;
    }
    printf $fid_tb "    \$fwrite(fid_out, \"%%d \\n \", out%0d); \n", $po_cnt;
    printf $fid_tb "\n";
    printf $fid_tb "    #10; rst_n = 1'b0;\n";
    printf $fid_tb "  end \n";
  }
  printf $fid_tb "  \$stop; \n";
  printf $fid_tb "end \n";
  printf $fid_tb "\n";

  #writing the dut
  printf $fid_tb "%0s %0s ( \n", $file_name, $file_name;
  printf $fid_tb "    .rst_n(rst_n), \n";
  printf $fid_tb "    .clk(clk), \n";
  foreach my $i (1 .. $pi_cnt){
    printf $fid_tb "    .in%0d(in%0d), \n", $i, $i;
  }
  foreach my $i (1 .. $po_cnt){
    printf $fid_tb "    .out%0d(out%0d), \n", $i, $i;
  }
  printf $fid_tb "    .en_out(en_out)); \n";
  printf $fid_tb "\n";

  printf $fid_tb "endmodule \n";

  close ($fid_tb);

  return ($the_acc);
}

sub generate_testbench{
  my ($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @neuron_width_mat = @ {$neuron_width_mat_ref};

  print "[INFO] Generating the test-bench... \n";

  my $pi_cnt = $layer_arr[1];
  my $po_cnt = $layer_arr[$layer_cnt];

  my $file_in = $file_name . ".inputs";
  my $file_out = $file_name . ".outputs";
  my ($test_cnt, $the_acc) = generate_test_patterns($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, $act_fun_arr_ref);
 
  my $module_tb = $file_name . "_tb";
  my $file_tb = $file_path . $module_tb . ".v";
  open (my $fid_tb, '>', $file_tb);

  #writing the module
  printf $fid_tb "module %0s (); \n", $module_tb;
 
  #writing the procedure
  printf $fid_tb "\n";
  if ($is_creg){
    printf $fid_tb "reg clk = 1'b0; \n";
    printf $fid_tb "reg rst_n = 1'b0; \n";
  }
  printf $fid_tb "integer fid_out, test_index; \n";
  printf $fid_tb "reg [%0d:0] test_in_reg [0:%0d]; \n", $pi_cnt*$in_width-1, $test_cnt-1;
  printf $fid_tb "reg [%0d:0] test_out_reg [0:%0d]; \n", $po_cnt*$out_width-1, $test_cnt-1;
  printf $fid_tb "reg signed [%0d:0] ", $in_width-1;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_tb "in%0d, ", $i;
  }
  printf $fid_tb "in%0d;\n", $pi_cnt;
  printf $fid_tb "reg signed [%0d:0] ", $out_width-1;
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_tb "test_out%0d, ", $i;
  }
  printf $fid_tb "test_out%0d;\n", $po_cnt;
  printf $fid_tb "wire signed [%0d:0] ", $out_width-1;
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_tb "out%0d, ", $i;
  }
  printf $fid_tb "out%0d;\n", $po_cnt;
  printf $fid_tb "\n";

  if ($is_creg){
    printf $fid_tb "always #10 clk = !clk; \n";
    printf $fid_tb "\n";
  }

  printf $fid_tb "initial begin \n";
  if ($is_creg){
    printf $fid_tb "  #5; rst_n = 1'b1; \n";
  }
  printf $fid_tb "  fid_out = \$fopen(\"sim.out\", \"w\"); \n";
  printf $fid_tb "  \$readmemb(\"%0s\", test_in_reg); \n", $file_in;
  printf $fid_tb "  \$readmemb(\"%0s\", test_out_reg); \n", $file_out;
  printf $fid_tb "\n";
  printf $fid_tb "  for (test_index=0; test_index<%0d; test_index=test_index+1) begin \n", $test_cnt;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_tb "    in%0d = test_in_reg[test_index][%0d:%0d]; \n", $i, $in_width*($pi_cnt-$i+1)-1, $in_width*($pi_cnt-$i);
    printf $fid_tb "    \$fwrite(fid_out, \"%%d, \", in%0d); \n", $i;
  }
  printf $fid_tb "    in%0d = test_in_reg[test_index][%0d:0]; \n", $pi_cnt, $in_width-1;
  printf $fid_tb "    \$fwrite(fid_out, \"%%d; \", in%d); \n", $pi_cnt;
  printf $fid_tb "\n";
  if (!$is_creg){
    printf $fid_tb "    \#10; \n";
  }
  else{
    printf $fid_tb "    @ (posedge clk); \n";
    printf $fid_tb "    \#5; \n";
  }
  printf $fid_tb "\n";
  if (!$exap_cmul){
    foreach my $i (1 .. $po_cnt-1){
      printf $fid_tb "    test_out%0d = test_out_reg[test_index][%0d:%0d]; \n", $i, $out_width*($po_cnt-$i+1)-1, $out_width*($po_cnt-$i);
      printf $fid_tb "    \$fwrite(fid_out, \"%%d, \", test_out%0d); \n", $i;
      printf $fid_tb "    if (test_out%0d !== out%0d) begin \n", $i, $i;
      printf $fid_tb "      \$display(\"[ERROR] %0d. output is not the same as the expected on the %%d test pattern!\", test_index); \$stop; \n", $i;
      printf $fid_tb "    end \n";
    }
    printf $fid_tb "    test_out%0d = test_out_reg[test_index][%0d:0]; \n", $po_cnt, $out_width-1;
    printf $fid_tb "    \$fwrite(fid_out, \"%%d \\n \", test_out%0d); \n", $po_cnt;
    printf $fid_tb "    if (test_out%0d !== out%0d) begin \n", $po_cnt, $po_cnt;
    printf $fid_tb "      \$display(\"[ERROR] %0d. output is not the same as the expected on the %%d test pattern!\", test_index); \$stop; \n", $po_cnt;
    printf $fid_tb "    end \n";
    printf $fid_tb "  end \n";
    printf $fid_tb "\n";
    printf $fid_tb "  \$fclose(fid_out); \n";
    printf $fid_tb "  \$display(\"[INFO] ANN design has just been verified!\"); \n";
  }
  else{
    foreach my $i (1 .. $po_cnt-1){
      printf $fid_tb "    \$fwrite(fid_out, \"%%d, \", out%0d); \n", $i;
    }
    printf $fid_tb "    \$fwrite(fid_out, \"%%d \\n \", out%0d); \n", $po_cnt;
    printf $fid_tb "  end \n";
  }
  printf $fid_tb "  \$stop; \n";
  printf $fid_tb "end \n";
  printf $fid_tb "\n";

  #writing the dut
  printf $fid_tb "%0s %0s ( \n", $file_name, $file_name;
  if ($is_creg){
    printf $fid_tb "    .rst_n(rst_n), \n";
    printf $fid_tb "    .clk(clk), \n";
  }
  foreach my $i (1 .. $pi_cnt){
    printf $fid_tb "    .in%0d(in%0d), \n", $i, $i;
  }
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_tb "    .out%0d(out%0d), \n", $i, $i;
  }
  printf $fid_tb "    .out%0d(out%0d)); \n", $po_cnt, $po_cnt;
  printf $fid_tb "\n";

  printf $fid_tb "endmodule \n";

  close ($fid_tb);

  return ($the_acc);
}

sub sort_array{
  my ($the_cnt, @the_arr) = @_;

  my @sorted_arr = ();

  foreach my $i (1 .. $the_cnt){
    $the_arr[$i][0] = 1;
  }

  for (my $i=1; $i<=$the_cnt-1; $i++){
    for (my $j=$i+1; $j<=$the_cnt; $j++){
      if ($the_arr[$i][2] < $the_arr[$j][2]){
        $the_arr[$j][0]++;
      }
      else{
        $the_arr[$i][0]++;
      }
    }
  }

  foreach my $i (1 ..  $the_cnt){
    $sorted_arr[$the_arr[$i][0]][1] = $the_arr[$i][1];
    $sorted_arr[$the_arr[$i][0]][2] = $the_arr[$i][2];
  }

  return (@sorted_arr);
}

sub generate_layer_output_mcm{
  my ($fid_layer, $layer_index, $out_index, $pi_cnt, $weight_mat_ref) = @_;
  my @weight_mat = @ {$weight_mat_ref};

  my $add_cnt = 0;
  my @add_arr = ();

  foreach my $i (1 .. $pi_cnt){
    if ($weight_mat[$layer_index-1][$out_index][$i]){
      $add_cnt++;
      if ($weight_mat[$layer_index-1][$out_index][$i] > 0){
        $add_arr[$add_cnt][1] = "wp" . $weight_mat[$layer_index-1][$out_index][$i] . "_mul_x" . $i;
      }
      else{
        $add_arr[$add_cnt][1] = "wm" . abs($weight_mat[$layer_index-1][$out_index][$i]) . "_mul_x" . $i;
      }
      $add_arr[$add_cnt][2] = abs($weight_mat[$layer_index-1][$out_index][$i]);
    }
  }

  my $say_add = $add_cnt ? $add_cnt - 1 : 0;

  while (1){
    if ($add_cnt > 1){
      my (@sorted_arr) = sort_array($add_cnt, @add_arr);

      my $new_add_cnt = 0;
      my @new_add_arr = ();
      my $last_one = ($add_cnt % 2) ? $add_cnt-1 : $add_cnt;

      for (my $i=1; $i<=$last_one; $i=$i+2){
        $new_add_cnt++;
        $new_add_arr[$new_add_cnt][1] = "(" . $sorted_arr[$i][1] . " + " . $sorted_arr[$i+1][1] . ")";
        $new_add_arr[$new_add_cnt][2] = $sorted_arr[$i][2] + $sorted_arr[$i+1][2];
      }
      if ($add_cnt % 2){
        $new_add_cnt++;
        $new_add_arr[$new_add_cnt][1] = "(" . $sorted_arr[$add_cnt][1] . ")";
        $new_add_arr[$new_add_cnt][2] = $sorted_arr[$add_cnt][2];
      }

      $add_cnt = $new_add_cnt;
      @add_arr = @ {dclone(\@new_add_arr)};
    }
    else{
      last;
    }
  }

  printf $fid_layer "assign y%0d = %0s; \n", $out_index, $add_arr[1][1];

  return ($say_add);
}

sub generate_verilog_code_layer_mcm_blocks{
  my ($fid_layer, $say_add, $layer_mod, $layer_index, $pi_cnt, $po_cnt, $weight_mat_ref, $muladd_width_mat_ref) = @_;
  my @weight_mat = @ {$weight_mat_ref};
  my @muladd_width_mat = @ {$muladd_width_mat_ref};

  #Module name
  printf $fid_layer "\n";
  printf $fid_layer "module %0s (", $layer_mod;
  foreach my $i (1 .. $pi_cnt){
    printf $fid_layer "x%0d, ", $i;
  }
  foreach my $i (1 .. $po_cnt-1){
    printf $fid_layer "y%0d, ", $i;
  }
  printf $fid_layer "y%0d); \n", $po_cnt;
  printf $fid_layer "\n";

  #Inputs
  printf $fid_layer "input signed [%0d:0] ", $in_width-1;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_layer "x%0d, ", $i;
  }
  printf $fid_layer "x%0d; \n", $pi_cnt;
  #Outputs
  foreach my $i (1 .. $po_cnt){
    printf $fid_layer "output signed [%0d:0] y%0d; \n", $muladd_width_mat[$layer_index][$i]-1, $i;
  }
  printf $fid_layer "\n";
  #Wires
  foreach my $i (1 .. $pi_cnt){
    my $uni_cnt = 0;
    my @uni_arr = ();
    foreach my $j (1 .. $po_cnt){
      my $the_cons = $weight_mat[$layer_index-1][$j][$i];
      if ($the_cons){
        if (!is_inside_numeric_array($the_cons, $uni_cnt, @uni_arr)){
          $uni_cnt++;
          $uni_arr[$uni_cnt] = $the_cons;
          my $the_width = POSIX::floor(log(abs($the_cons))/log(2)) + $in_width + 1;

          if ($the_cons > 0){
            printf $fid_layer "wire signed [%0d:0] wp%0d_mul_x%0d; \n", $the_width-1, $the_cons, $i; 
          }
          else{
            printf $fid_layer "wire signed [%0d:0] wm%0d_mul_x%0d; \n", $the_width-1, abs($the_cons), $i; 
          }
        }
      }
    }
  }
  printf $fid_layer "\n";
  #MCM Blocks
  foreach my $i (1 .. $pi_cnt){
    my $mcm_mod = $layer_mod . "_in" . $i;
    printf $fid_layer "%0s mcm_in%d_ins (.x1(x%0d), ", $mcm_mod, $i, $i;

    my $uni_cnt = 0;
    my @uni_arr = ();
    my $first_nonzero = 0;
    foreach my $j (1 .. $po_cnt){
      my $the_cons = $weight_mat[$layer_index-1][$j][$i];

      if ($the_cons){
        if (!is_inside_numeric_array($the_cons, $uni_cnt, @uni_arr)){
          $uni_cnt++;
          $uni_arr[$uni_cnt] = $the_cons;

          if ($first_nonzero){
            if ($the_cons > 0){
              printf $fid_layer ", .p%0dx(wp%0d_mul_x%0d)", $the_cons, $the_cons, $i;
            }
            else{
              printf $fid_layer ", .m%0dx(wm%0d_mul_x%0d)", abs($the_cons), abs($the_cons), $i;
            }
          }
          else{
            $first_nonzero = 1;
            if ($the_cons > 0){
              printf $fid_layer ".p%0dx(wp%0d_mul_x%0d)", $the_cons, $the_cons, $i;
            }
            else{
              printf $fid_layer ".m%0dx(wm%0d_mul_x%0d)", abs($the_cons), abs($the_cons), $i;
            }
          }
        }
      }
    }

    printf $fid_layer "); \n";
  }
  printf $fid_layer "\n";
  #Outputs
  foreach my $out_index (1 .. $po_cnt){
    $say_add += generate_layer_output_mcm($fid_layer, $layer_index, $out_index, $pi_cnt, $weight_mat_ref);
  }

  printf $fid_layer "\n";
  printf $fid_layer "endmodule \n";
  printf $fid_layer "\n";

  return ($say_add);
}

sub generate_verilog_code_layer_cavm_blocks{
  my ($fid_layer, $layer_mod, $layer_index, $pi_cnt, $po_cnt, $weight_mat_ref, $muladd_width_mat_ref, $all_zero_arr_ref) = @_;
  my @weight_mat = @ {$weight_mat_ref};
  my @all_zero_arr = @ {$all_zero_arr_ref};
  my @muladd_width_mat = @ {$muladd_width_mat_ref};
  
  my $out_cnt = 0;

  #Module name
  printf $fid_layer "\n";
  printf $fid_layer "module %0s (", $layer_mod;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_layer "x%0d, ", $i;
  }
  printf $fid_layer "x%0d ", $pi_cnt;
  foreach my $i (1 .. $po_cnt){
    if (!$all_zero_arr[$i]){
      $out_cnt++;
      printf $fid_layer ", y%0d", $out_cnt;
    }
  }
  printf $fid_layer "); \n";
  printf $fid_layer "\n";

  #Inputs
  printf $fid_layer "input signed [%0d:0] ", $in_width-1;
  foreach my $i (1 .. $pi_cnt-1){
    printf $fid_layer "x%0d, ", $i;
  }
  printf $fid_layer "x%0d; \n", $pi_cnt;
  #Outputs
  $out_cnt = 0;
  foreach my $i (1 .. $po_cnt){
    if (!$all_zero_arr[$i]){
      $out_cnt++;
      printf $fid_layer "output signed [%0d:0] y%0d; \n", $muladd_width_mat[$layer_index][$i]-1, $out_cnt;
    }
  }
  printf $fid_layer "\n";
  #CAVM Blocks
  $out_cnt = 0;
  foreach my $i (1 .. $po_cnt){
    if (!$all_zero_arr[$i]){
      $out_cnt++;
      my $cavm_mod = $layer_mod . "_out" . $i;
      printf $fid_layer "%0s cavm_out%d_ins (", $cavm_mod, $i;
      foreach my $j (1 .. $pi_cnt){
        printf $fid_layer ".x%d(x%d), ", $j, $j;
      }
      printf $fid_layer ".y1(y%d)); \n", $out_cnt;
    }
  }
  printf $fid_layer "\n";
  printf $fid_layer "endmodule \n";
  printf $fid_layer "\n";
}

sub file_extract_add_count{
  my ($file_result) = @_;

  my $add_cnt = 0;

  if (open (my $file_header, '<:encoding(UTF-8)', $file_result)){
    my $the_index = 0;

    while (my $the_line = <$file_header>){
      chomp $the_line;

      if (index($the_line, "* Number of operations:") != -1){
        $the_index = index($the_line, ":");
        $the_index = skip_spaces_forward($the_line, $the_index+1);

        $add_cnt = substr($the_line, $the_index, length($the_line)-$the_index) + 0.0;
        #print "add_cnt: $add_cnt \n";
        last;
      }
    }

    close ($file_header);
  }
  else{
    print "[ERROR] Could not open the $file_result file! \n";
  }

  return ($add_cnt);
}

sub generate_verilog_code_layer_mcm{
  my ($file_path, $file_name, $path_mcm, $path_high2low, $say_add, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $muladd_width_mat_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @ver_file_arr = @ {$ver_file_arr_ref};

  my $the_cmd;
  my $fid_bias;
  my $file_bias;
  my $fid_weight;
  my $file_weight;
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my $po_cnt = $layer_arr[$layer_index];
    my $pi_cnt = $layer_arr[$layer_index-1];

    my $layer_mod = $file_name . "_layer" . $layer_index;
    my $layer_ver = $file_path . $layer_mod . ".v";
    open (my $fid_layer, '>', $layer_ver);

    foreach my $in_index (1 .. $pi_cnt){
      my $mcm_name = $file_name . "_layer" . $layer_index . "_in" . $in_index;
      my $mcm_result = $file_path . $mcm_name . ".result";
      my $file_mcm = $file_path . $mcm_name . ".mc";
      my $mcm_ver = $mcm_name . ".v";

      printf $fid_layer "`include \"%0s\"\n", $mcm_ver;
      
      open (my $fid_mcm, '>', $file_mcm);
      foreach my $out_index (1 .. $po_cnt){
        if ($weight_mat[$layer_index-1][$out_index][$in_index]){
          printf $fid_mcm "%0d \n", $weight_mat[$layer_index-1][$out_index][$in_index];
        }
      }
      close ($fid_mcm);

      if ($the_aim eq "area"){
        $the_cmd = $path_mcm . " " . $file_mcm . " 0";
      }
      else{
        $the_cmd = $path_mcm . " " . $file_mcm . " 1";
      }
      #print "mcm_cmd: $the_cmd \n";
      system($the_cmd);
      $say_add += file_extract_add_count($mcm_result);
      
      #Generate the Verilog file
      $the_cmd = $path_high2low . " " . $mcm_result . " " . $in_width;
      #print "high2low_cmd: $the_cmd \n";
      system($the_cmd);

      $ver_file_cnt++;
      $ver_file_arr[$ver_file_cnt] = $mcm_ver;
    }

    ($say_add) = generate_verilog_code_layer_mcm_blocks($fid_layer, $say_add, $layer_mod, $layer_index, $pi_cnt, $po_cnt, $weight_mat_ref, $muladd_width_mat_ref);

    close ($fid_layer);
  }

  return ($say_add, $ver_file_cnt, \@ver_file_arr);
}

sub add_space{
  my ($the_fid, $the_space) = @_;

  foreach my $i (1 .. $the_space){
    printf $the_fid " ";
  }
}

sub generate_verilog_code_layer_mac_mcmmux{
  my ($file_path, $file_name, $path_mcm, $path_high2low, $layer_index, $layer_arr_ref, $weight_mat_ref, $muladd_width_arr_ref, $muladd_shift_arr_ref, $max_weight_width_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @muladd_shift_arr = @ {$muladd_shift_arr_ref};
  my @muladd_width_arr = @ {$muladd_width_arr_ref};
  my @max_weight_width_arr = @ {$max_weight_width_arr_ref};

  my $the_cmd;
  my $say_add = 0;

  my $po_size = $out_width;
  my $po_cnt = $layer_arr[$layer_index];
  my $pi_cnt = $layer_arr[$layer_index-1];
  my $cnt_width = POSIX::floor(log($pi_cnt+1)/log(2))+1;
  my $pi_size = ($layer_index == 2) ? $in_width : $out_width;

  #Module File
  my $module_mac = $file_name . "_layer" . $layer_index;
  my $file_mac = $file_path . $module_mac . ".v";
  open (my $fid_mac, '>', $file_mac);
  
  #MCM File
  my $mcm_name = $file_name . "_mcm_layer" . $layer_index;
  my $mcm_result = $file_path . $mcm_name . ".result";
  my $file_mcm = $file_path . $mcm_name . ".mc";
  my $mcm_ver = $mcm_name . ".v";
  open (my $fid_mcm, '>', $file_mcm);

  my $out_cnt = 0;
  my $cons_cnt = 0;
  my @cons_arr = ();
  my @out_legal_arr = ();
  foreach my $out_index (1 .. $po_cnt){
    if ($muladd_width_arr[$out_index]){
      $out_cnt++;
      $out_legal_arr[$out_cnt] = $out_index;

      foreach my $in_index (1 .. $pi_cnt){
        my $the_cons = $weight_mat[$layer_index-1][$out_index][$in_index]/(2**$muladd_shift_arr[$out_index]);
        if ($the_cons){
          if (!(is_inside_numeric_array($the_cons, $cons_cnt, @cons_arr))){
            $cons_cnt++;
            $cons_arr[$cons_cnt] = $the_cons;
            printf $fid_mcm "%d \n", $the_cons;
          }
        }
      }
    }
  }
  close ($fid_mcm);

  if ($the_aim eq "area"){
    $the_cmd = $path_mcm . " " . $file_mcm . " 0";
  }
  else{
    $the_cmd = $path_mcm . " " . $file_mcm . " 1";
  }
  #print "mcm_cmd: $the_cmd \n";
  system($the_cmd);
  $say_add += file_extract_add_count($mcm_result);
  
  #Generate the Verilog file
  $the_cmd = $path_high2low . " " . $mcm_result . " " . $in_width;
  #print "high2low_cmd: $the_cmd \n";
  system($the_cmd);

  #Write the module
  printf $fid_mac "module %s (rst_n, clk, ", $module_mac;
  if ($layer_index > 2){
    printf $fid_mac "en_in, ";
  }
  foreach my $in_index (1 .. $pi_cnt){
    printf $fid_mac "x%d, ", $in_index;
  }
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "y%d, ", $out_index;
  }
  printf $fid_mac "en_out); \n";

  #Write the inputs and outputs
  printf $fid_mac "input rst_n, clk; \n";
  if ($layer_index > 2){
    printf $fid_mac "input en_in; \n";
  }
  printf $fid_mac "input signed [%0d:0] ", $pi_size-1;
  foreach my $in_index (1 .. $pi_cnt-1){
    printf $fid_mac "x%d, ", $in_index;
  }
  printf $fid_mac "x%d; \n", $pi_cnt;
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "output signed [%0d:0] y%d; \n", $muladd_width_arr[$out_legal_arr[$out_index]]-1, $out_index;
  }
  printf $fid_mac "output en_out; \n";
  printf $fid_mac "\n";

  #write the wires
  printf $fid_mac "reg the_en; \n";
  printf $fid_mac "reg [%d:0] the_counter; \n", $cnt_width-1;
  printf $fid_mac "reg signed [%d:0] the_in; \n", $pi_size-1;
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "reg signed [%d:0] weight%dx; \n", $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]]-1, $out_index;
    printf $fid_mac "reg signed [%d:0] the_neuron%d_sum_cur; \n", $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]]-1, $out_index;
    printf $fid_mac "wire signed [%d:0] the_neuron%d_sum_next; \n", $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]]-1, $out_index;
  }
  foreach my $cons_index (1 .. $cons_cnt){
    my $the_width = POSIX::floor(log(abs($cons_arr[$cons_index]))/log(2)) + $in_width + 1;
    if ($cons_arr[$cons_index] > 0){
      printf $fid_mac "wire signed [%0d:0] wp%0dx; \n", $the_width-1, $cons_arr[$cons_index]; 
    }
    else{
      printf $fid_mac "wire signed [%0d:0] wm%0dx; \n", $the_width-1, abs($cons_arr[$cons_index]); 
    }
  }
  printf $fid_mac "\n";

  #Write the MCM block
  printf $fid_mac "// MCM block \n";
  printf $fid_mac "%s mcm_layer_%d_ins (.x1(the_in), \n", $mcm_name, $layer_index;
  foreach my $cons_index (1 .. $cons_cnt-1){
    if ($cons_arr[$cons_index] > 0){
      printf $fid_mac "  .p%dx(wp%dx), \n", $cons_arr[$cons_index], $cons_arr[$cons_index];
    }
    else{
      printf $fid_mac "  .m%dx(wm%dx), \n", abs($cons_arr[$cons_index]), abs($cons_arr[$cons_index]);
    }
  }
  if ($cons_arr[$cons_cnt] > 0){
    printf $fid_mac "  .p%dx(wp%dx)); \n", $cons_arr[$cons_cnt], $cons_arr[$cons_cnt];
  }
  else{
    printf $fid_mac "  .m%dx(wm%dx)); \n", abs($cons_arr[$cons_cnt]), abs($cons_arr[$cons_cnt]);
  }
  printf $fid_mac "\n";

  #Write the clock and reset conditions
  my $space_cnt = 0;
  add_space($fid_mac, $space_cnt); printf $fid_mac "// Conditions for the reset and clock \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "always @(posedge clk, negedge rst_n) begin \n";
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "if (rst_n == 1'b0) begin \n";
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "the_en <= 1'b0; \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "the_counter <= %d'd0; \n", $cnt_width;
  foreach my $out_index (1 .. $out_cnt){
    add_space($fid_mac, $space_cnt); printf $fid_mac "the_neuron%d_sum_cur <= %d'd0; \n", $out_index, $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]];
  }
  $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "else begin \n";
  if ($layer_index > 2){
    $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "if (en_in) begin \n";
  }
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "if (the_counter <= %d'd%d) begin \n", $cnt_width, $pi_cnt;
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "the_counter <= the_counter + 1; \n";
  foreach my $out_index (1 .. $out_cnt){
    add_space($fid_mac, $space_cnt); printf $fid_mac "the_neuron%d_sum_cur <= the_neuron%d_sum_next; \n", $out_index, $out_index;
  }
  $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "else begin \n";
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "the_en <= 1'b1; \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "the_counter <= the_counter; \n";
  foreach my $out_index (1 .. $out_cnt){
    add_space($fid_mac, $space_cnt); printf $fid_mac "the_neuron%d_sum_cur <= the_neuron%d_sum_cur; \n", $out_index, $out_index;
  }
  $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  if ($layer_index > 2){
    $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  }
  while ($space_cnt){
    $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  }
  printf $fid_mac "\n";

  #Write the conditions for the input and weight selection
  printf $fid_mac "// Conditions for the input and weight selections \n";
  printf $fid_mac "always @(*) begin \n";
  printf $fid_mac "  case (the_counter) \n";
  foreach my $in_index (1 .. $pi_cnt){
    printf $fid_mac "    %d'd%d : begin the_in = x%d; ", $cnt_width, $in_index, $in_index;
    foreach my $out_index (1 .. $out_cnt){
      my $the_cons = $weight_mat[$layer_index-1][$out_legal_arr[$out_index]][$in_index]/(2**$muladd_shift_arr[$out_legal_arr[$out_index]]);
      if ($the_cons < 0){
        printf $fid_mac "weight%dx = \$signed(wm%dx); ", $out_index, abs($the_cons);
      }
      elsif ($the_cons > 0){
        printf $fid_mac "weight%dx = \$signed(wp%dx); ", $out_index, $the_cons;
      }
      else{
        printf $fid_mac "weight%dx = %d'b0; ", $out_index, $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]];
      }
    }
    printf $fid_mac "end \n";
  }
  printf $fid_mac "    default: begin the_in = %d'd0; ", $pi_size;
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "weight%dx = %d'd0; ", $out_index, $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]]-1;
  }
  printf $fid_mac "end \n";
  printf $fid_mac "  endcase \n";
  printf $fid_mac "end \n";
  printf $fid_mac "\n";

  #Write the internal sum and output signals
  printf $fid_mac "//Summation results \n";
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "assign the_neuron%d_sum_next = weight%dx + the_neuron%d_sum_cur; \n", $out_index, $out_index, $out_index;
  }
  printf $fid_mac "\n";

  printf $fid_mac "//Output signals \n";
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "assign y%d = the_en ? (the_neuron%d_sum_cur<<<%d) : %0d'd0; \n", $out_index, $out_index, $muladd_shift_arr[$out_legal_arr[$out_index]], $muladd_width_arr[$out_legal_arr[$out_index]];
  }
  printf $fid_mac "\n";
  printf $fid_mac "assign en_out = the_en; \n";
  printf $fid_mac "\n";
  printf $fid_mac "endmodule \n";
  printf $fid_mac "\n";

  close ($fid_mac);

  return ($say_add);
}

sub generate_verilog_code_layer_mac{
  my ($file_path, $file_name, $layer_index, $layer_arr_ref, $weight_mat_ref, $muladd_width_arr_ref, $muladd_shift_arr_ref, $max_weight_width_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @muladd_shift_arr = @ {$muladd_shift_arr_ref};
  my @muladd_width_arr = @ {$muladd_width_arr_ref};
  my @max_weight_width_arr = @ {$max_weight_width_arr_ref};

  my $po_size = $out_width;
  my $po_cnt = $layer_arr[$layer_index];
  my $pi_cnt = $layer_arr[$layer_index-1];
  my $cnt_width = POSIX::floor(log($pi_cnt+1)/log(2))+1;
  my $pi_size = ($layer_index == 2) ? $in_width : $out_width;

  my $out_cnt = 0;
  my @out_legal_arr = ();
  foreach my $out_index (1 .. $po_cnt){
    if ($muladd_width_arr[$out_index]){
      $out_cnt++;
      $out_legal_arr[$out_cnt] = $out_index;
    }
  }

  #Write the module
  my $module_mac = $file_name . "_layer" . $layer_index;
  my $file_mac = $file_path . $module_mac . ".v";
  open (my $fid_mac, '>', $file_mac);
  printf $fid_mac "module %s (rst_n, clk, ", $module_mac;
  if ($layer_index > 2){
    printf $fid_mac "en_in, ";
  }
  foreach my $in_index (1 .. $pi_cnt){
    printf $fid_mac "x%d, ", $in_index;
  }
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "y%d, ", $out_index;
  }
  printf $fid_mac "en_out); \n";

  #Write the inputs and outputs
  printf $fid_mac "input rst_n, clk; \n";
  if ($layer_index > 2){
    printf $fid_mac "input en_in; \n";
  }
  printf $fid_mac "input signed [%0d:0] ", $pi_size-1;
  foreach my $in_index (1 .. $pi_cnt-1){
    printf $fid_mac "x%d, ", $in_index;
  }
  printf $fid_mac "x%d; \n", $pi_cnt;
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "output signed [%0d:0] y%d; \n", $muladd_width_arr[$out_legal_arr[$out_index]]-1, $out_index;
  }
  printf $fid_mac "output en_out; \n";
  printf $fid_mac "\n";

  #write the wires
  printf $fid_mac "reg the_en; \n";
  printf $fid_mac "reg [%d:0] the_counter; \n", $cnt_width-1;
  printf $fid_mac "reg signed [%d:0] the_in; \n", $pi_size-1;
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "reg signed [%d:0] the_neuron%d_weight; \n", $max_weight_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]]-1, $out_index;
    printf $fid_mac "reg signed [%d:0] the_neuron%d_sum_cur; \n", $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]]-1, $out_index;
    printf $fid_mac "wire signed [%d:0] the_neuron%d_sum_next; \n", $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]]-1, $out_index;
  }
  printf $fid_mac "\n";

  #Write the clock and reset conditions
  my $space_cnt = 0;
  add_space($fid_mac, $space_cnt); printf $fid_mac "// Conditions for the reset and clock \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "always @(posedge clk, negedge rst_n) begin \n";
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "if (rst_n == 1'b0) begin \n";
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "the_en <= 1'b0; \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "the_counter <= %d'd0; \n", $cnt_width;
  foreach my $out_index (1 .. $out_cnt){
    add_space($fid_mac, $space_cnt); printf $fid_mac "the_neuron%d_sum_cur <= %d'd0; \n", $out_index, $muladd_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]];
  }
  $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "else begin \n";
  if ($layer_index > 2){
    $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "if (en_in) begin \n";
  }
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "if (the_counter <= %d'd%d) begin \n", $cnt_width, $pi_cnt;
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "the_counter <= the_counter + 1; \n";
  foreach my $out_index (1 .. $out_cnt){
    add_space($fid_mac, $space_cnt); printf $fid_mac "the_neuron%d_sum_cur <= the_neuron%d_sum_next; \n", $out_index, $out_index;
  }
  $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "else begin \n";
  $space_cnt += 2; add_space($fid_mac, $space_cnt); printf $fid_mac "the_en <= 1'b1; \n";
  add_space($fid_mac, $space_cnt); printf $fid_mac "the_counter <= the_counter; \n";
  foreach my $out_index (1 .. $out_cnt){
    add_space($fid_mac, $space_cnt); printf $fid_mac "the_neuron%d_sum_cur <= the_neuron%d_sum_cur; \n", $out_index, $out_index;
  }
  $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  if ($layer_index > 2){
    $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  }
  while ($space_cnt){
    $space_cnt -= 2; add_space($fid_mac, $space_cnt); printf $fid_mac "end \n";
  }
  printf $fid_mac "\n";

  #Write the conditions for the input and weight selection
  printf $fid_mac "// Conditions for the input and weight selections \n";
  printf $fid_mac "always @(*) begin \n";
  printf $fid_mac "  case (the_counter) \n";
  foreach my $in_index (1 .. $pi_cnt){
    printf $fid_mac "    %d'd%d : begin the_in = x%d; ", $cnt_width, $in_index, $in_index;
    foreach my $out_index (1 .. $out_cnt){
      if ($weight_mat[$layer_index-1][$out_legal_arr[$out_index]][$in_index] < 0){
        printf $fid_mac "the_neuron%d_weight = -%d'd%d; ", $out_index, $max_weight_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]], abs($weight_mat[$layer_index-1][$out_legal_arr[$out_index]][$in_index])/(2**$muladd_shift_arr[$out_legal_arr[$out_index]]);
      }
      else{
        printf $fid_mac "the_neuron%d_weight = %d'd%d; ", $out_index, $max_weight_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]], $weight_mat[$layer_index-1][$out_legal_arr[$out_index]][$in_index]/(2**$muladd_shift_arr[$out_legal_arr[$out_index]]);
      }
    }
    printf $fid_mac "end \n";
  }
  printf $fid_mac "    default: begin the_in = %d'd0; ", $pi_size;
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "the_neuron%d_weight = %d'd0; ", $out_index, $max_weight_width_arr[$out_legal_arr[$out_index]]-$muladd_shift_arr[$out_legal_arr[$out_index]];
  }
  printf $fid_mac "end \n";
  printf $fid_mac "  endcase \n";
  printf $fid_mac "end \n";
  printf $fid_mac "\n";

  #Write the internal sum and output signals
  printf $fid_mac "//Summation results \n";
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "assign the_neuron%d_sum_next = (the_in * the_neuron%d_weight) + the_neuron%d_sum_cur; \n", $out_index, $out_index, $out_index;
  }
  printf $fid_mac "\n";

  printf $fid_mac "//Output signals \n";
  foreach my $out_index (1 .. $out_cnt){
    printf $fid_mac "assign y%d = the_en ? (the_neuron%d_sum_cur<<<%d) : %0d'd0; \n", $out_index, $out_index, $muladd_shift_arr[$out_legal_arr[$out_index]], $muladd_width_arr[$out_legal_arr[$out_index]];
  }
  printf $fid_mac "\n";
  printf $fid_mac "assign en_out = the_en; \n";
  printf $fid_mac "\n";
  printf $fid_mac "endmodule \n";
  printf $fid_mac "\n";

  close ($fid_mac);
}

sub generate_verilog_code_layer_cavm{
  my ($file_path, $file_name, $path_cavm, $path_high2low, $say_add, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $muladd_width_mat_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @ver_file_arr = @ {$ver_file_arr_ref};

  my $the_cmd;
  my $fid_bias;
  my $file_bias;
  my $fid_weight;
  my $file_weight;
  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my $po_cnt = $layer_arr[$layer_index];
    my $pi_cnt = $layer_arr[$layer_index-1];

    my @all_zero_arr = ();

    my $layer_mod = $file_name . "_layer" . $layer_index;
    my $layer_ver = $file_path . $layer_mod . ".v";
    open (my $fid_layer, '>', $layer_ver);

    foreach my $out_index (1 .. $po_cnt){
      my $cavm_name = $file_name . "_layer" . $layer_index . "_out" . $out_index;
      my $cavm_result = $file_path . $cavm_name . ".result";
      my $file_cavm = $file_path . $cavm_name . ".vm";
      my $cavm_ver = $cavm_name . ".v";
 
      my $is_all_zero = 1;
      open (my $fid_cavm, '>', $file_cavm);
      foreach my $in_index (1 .. $pi_cnt){
        if ($weight_mat[$layer_index-1][$out_index][$in_index]){
          $is_all_zero = 0;
        }
        printf $fid_cavm "%0d \n", $weight_mat[$layer_index-1][$out_index][$in_index];
      }
      printf $fid_cavm "\n";
      close ($fid_cavm);

      #print "is_all_zero: $is_all_zero \n";
      $all_zero_arr[$out_index] = $is_all_zero;

      if (!$is_all_zero){
        printf $fid_layer "`include \"%0s\"\n", $cavm_ver;

        #Solve the CAVM problem
        if ($the_aim eq "area"){
          $the_cmd = $path_cavm . " " . $file_cavm . " 0";
        }
        else{
          $the_cmd = $path_cavm . " " . $file_cavm . " 1";
        }
        #print "cavm_cmd: $the_cmd \n";
        system($the_cmd);
        $say_add += file_extract_add_count($cavm_result);
        
        #Generate the Verilog file
        $the_cmd = $path_high2low . " " . $cavm_result . " " . $in_width;
        #print "high2low_cmd: $the_cmd \n";
        system($the_cmd);

        $ver_file_cnt++;
        $ver_file_arr[$ver_file_cnt] = $cavm_ver;
      }
    }

    generate_verilog_code_layer_cavm_blocks($fid_layer, $layer_mod, $layer_index, $pi_cnt, $po_cnt, $weight_mat_ref, $muladd_width_mat_ref, \@all_zero_arr);

    close ($fid_layer);
  }

  return ($say_add, $ver_file_cnt, \@ver_file_arr);
}

sub generate_verilog_code_layer_cmvm{
  my ($file_path, $file_name, $path_hcmvm, $path_high2low, $say_add, $layer_cnt, $layer_arr_ref, $weight_mat_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};

  my $fid_bias;
  my $file_bias;
  my $fid_weight;
  my $file_weight;
  my $the_cmd = "";

  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my $po_cnt = $layer_arr[$layer_index];
    my $pi_cnt = $layer_arr[$layer_index-1];

    $file_bias = $file_path . $file_name . "_layer" . $layer_index . "_bias.cmat";
    open ($fid_bias, '>', $file_bias);
    printf $fid_bias ".r %0d \n", $po_cnt;
    printf $fid_bias ".c %0d \n", 1;
    
    $file_weight = $file_path . $file_name . "_layer" . $layer_index . ".cmat";
    open ($fid_weight, '>', $file_weight);
    printf $fid_weight ".r %0d \n", $po_cnt;
    printf $fid_weight ".c %0d \n", $pi_cnt;

    foreach my $i (1 .. $po_cnt){
      foreach my $j (1 .. $pi_cnt){
        printf $fid_weight "%0d ", $weight_mat[$layer_index-1][$i][$j];
      }
      printf $fid_weight "\n";
      printf $fid_bias "%0d \n", $weight_mat[$layer_index-1][$i][$pi_cnt+1];
    }

    printf $fid_bias ".e \n";
    close ($fid_bias);
    
    printf $fid_weight ".e \n";
    close ($fid_weight);

    #run the cmvm algorithm
    my $cmat_name = $file_name . "_layer" . $layer_index;
    my $cmvm_result = $file_path . $cmat_name . ".result";
    if ($the_rep eq "binary"){
      $the_cmd = $path_hcmvm . " " . $file_weight . " 0";
    }
    else{
      $the_cmd = $path_hcmvm . " " . $file_weight . " 1";
    }
    #print "the_cmd: $the_cmd \n";
    system ($the_cmd);
    $say_add += file_extract_add_count($cmvm_result);

    #Run the high2low code
    $the_cmd = $path_high2low . " " . $cmvm_result . " " . $in_width;
    #print "the_cmd: $the_cmd \n";
    system ($the_cmd);
  }

  return ($say_add);
}

sub compute_neurons_width{
  my ($layer_cnt, $layer_arr_ref, $weight_mat_ref, $act_fun_arr_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};
  my @act_fun_arr = @ {$act_fun_arr_ref};

  my $nzd_cost = 0;
  my $max_bias_width = 0;
  my $max_weight_width = 0;
  my $tot_neuron_shift = 0;
  my $max_neuron_width = 0;
  my @neuron_width_mat = ();
  my @neuron_shift_mat = ();
  my @weight_shift_mat = ();
  my $min_weight_shift = 9**9**9;

  for (my $layer_index=2; $layer_index<=$layer_cnt; $layer_index++){
    my $pi_cnt = $layer_arr[$layer_index-1];
    my $po_cnt = $layer_arr[$layer_index];

    my $min_shift = 9**9**9;
    foreach my $i (1 .. $po_cnt){
      my $weight_sum = 0;
      #Add the weights and bias
      foreach my $j (1 .. $pi_cnt){
        #print "layer_index: $layer_index po_index: $i pi_index: $j \n";
        $weight_sum += abs($weight_mat[$layer_index-1][$i][$j]);
        my $weight_width = ($weight_mat[$layer_index-1][$i][$j] == 0) ? 0 : ($weight_mat[$layer_index-1][$i][$j] > 0) ? POSIX::floor(log($weight_mat[$layer_index-1][$i][$j])/log(2))+2 : POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$j]))/log(2))+1;
        if ($weight_width > $max_weight_width){
          $max_weight_width = $weight_width;
        }

        my ($nzd_cnt, @csd_rep) = find_nonzero_digits_csd($weight_mat[$layer_index-1][$i][$j]);
        $nzd_cost += $nzd_cnt;

        if ($weight_mat[$layer_index-1][$i][$j]){
          my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($weight_mat[$layer_index-1][$i][$j]);
          $weight_shift_mat[$layer_index-1][$i][$j] = $the_shift;
          if ($the_shift < $min_shift){
            $min_shift = $the_shift;
          }
          if ($the_shift < $min_weight_shift){
            $min_weight_shift = $the_shift;
          }
        }
      }
      #Add the bias
      $weight_sum += abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      my $bias_width = ($weight_mat[$layer_index-1][$i][$pi_cnt+1] == 0) ? 0 : ($weight_mat[$layer_index-1][$i][$pi_cnt+1] > 0) ? POSIX::floor(log($weight_mat[$layer_index-1][$i][$pi_cnt+1])/log(2))+2 : POSIX::ceil(log(abs($weight_mat[$layer_index-1][$i][$pi_cnt+1]))/log(2))+1;
      if ($bias_width > $max_bias_width){
        $max_bias_width = $bias_width;
      }

      $neuron_width_mat[$layer_index][$i] = POSIX::floor(log($weight_sum)/log(2))+2;
      if ($neuron_width_mat[$layer_index][$i] > $max_neuron_width){
        $max_neuron_width = $neuron_width_mat[$layer_index][$i];
      }

      my ($nzd_cnt, @csd_rep) = find_nonzero_digits_csd($weight_mat[$layer_index-1][$i][$pi_cnt+1]);
      $nzd_cost += $nzd_cnt;

      $tot_neuron_shift += $min_shift;
      $neuron_shift_mat[$layer_index][$i] = $min_shift;
    }

    if ($act_fun_arr[$layer_index] eq "lin" or $act_fun_arr[$layer_index] eq "relu"){
      for my $i (1 .. $po_cnt){
        $neuron_width_mat[$layer_index][$i] = $max_neuron_width;
      }
    }
  }

  return ($max_weight_width, $max_bias_width, $min_weight_shift, $tot_neuron_shift, $nzd_cost, \@weight_shift_mat, \@neuron_shift_mat, \@neuron_width_mat);
}

sub print_array_contents{
  my ($the_title, $the_cnt, @the_arr) = @_;

  print "$the_title: ";
  foreach my $i (1 .. $the_cnt){
    print "$the_arr[$i] ";
  }
  print "\n";
}

sub print_matrix_contents{
  my ($the_title, $the_row, $the_col, @the_mat) = @_;

  print "$the_title: \n";
  foreach my $i (1 .. $the_row){
    foreach my $j (1 .. $the_col){
      print "$the_mat[$i][$j] ";
    }
    print "\n";
  }
}

sub quantize_weights{
  my ($quan_val, $layer_cnt, $layer_arr_ref, $weight_flt_mat_ref) = @_;
  my @weight_flt_mat = @ {$weight_flt_mat_ref};

  my @weight_mat = ();
  for (my $i=2; $i<=$layer_cnt; $i++){
    my $pi_cnt = ${$layer_arr_ref}[$i-1];
    my $po_cnt = ${$layer_arr_ref}[$i];
    foreach my $j (1 .. $po_cnt){
      foreach my $k (1 .. $pi_cnt+1){
        $weight_mat[$i-1][$j][$k] = POSIX::ceil((2**$quan_val)*$weight_flt_mat[$i-1][$j][$k]);
      }
    }
  }

  return (\@weight_mat);
}

sub analyze_weights{
  my ($info_string, $quan_val, $layer_cnt, $layer_arr_ref, $weight_mat_ref) = @_;
  my @weight_mat = @ {$weight_mat_ref};

  my @qw_arr = ();
  my $nzd_cost = 0;
  my $max_width = 0;
  my $weight_num = 0;
  my $weight_width = 0;

  for (my $i=2; $i<=$layer_cnt; $i++){
    my $pi_cnt = ${$layer_arr_ref}[$i-1];
    my $po_cnt = ${$layer_arr_ref}[$i];
    foreach my $j (1 .. $po_cnt){
      foreach my $k (1 .. $pi_cnt+1){
        my $the_weight = $weight_mat[$i-1][$j][$k];
        #compute hardware cost
        my ($nzd_cnt, @csd_rep) = find_nonzero_digits_csd($the_weight);
        $nzd_cost += $nzd_cnt;

        $weight_num++;
        if ($the_weight){
          if ($the_weight > 0){
            $weight_width = POSIX::floor(log($the_weight)/log(2))+2;
          }
          elsif ($the_weight < 0){
            $weight_width = POSIX::ceil(log(abs($the_weight))/log(2))+1;
          }

          if (defined $qw_arr[$weight_width]){
            $qw_arr[$weight_width]++;
          }
          else{
            $qw_arr[$weight_width] = 1;
          }

          if ($weight_width > $max_width){
            $max_width = $weight_width;
          }
        }
        else{
          if (defined $qw_arr[0]){
            $qw_arr[0]++;
          }
          else{
            $qw_arr[0] = 1;
          }
        }
      }
    }
  }

  my $the_per = 0;
  print "[INFO] Analysis of $weight_num weights when quantization value is $quan_val $info_string \n";
  foreach my $i (0 .. $max_width){
    if (defined $qw_arr[$i]){
      $the_per = int (100*($qw_arr[$i]/$weight_num));
      print "[INFO] Number of weights with $i bits: $qw_arr[$i] ($the_per%) \n";
    }
  }
  print "\n";

  return ($nzd_cost, $max_width);
}

sub print_weights{
  my ($layer_cnt, $layer_arr_ref, $weight_mat_ref) = @_;
  my @weight_mat = @ {$weight_mat_ref};

  print "[INFO] Weight Matrix: \n";
  for (my $i=2; $i<=$layer_cnt; $i++){
    printf "Hidden Layer #%d \n", $i-1;
    my $pi_cnt = ${$layer_arr_ref}[$i-1];
    my $po_cnt = ${$layer_arr_ref}[$i];
    foreach my $j (1 .. $po_cnt){
      foreach my $k (1 .. $pi_cnt+1){
        print "$weight_mat[$i-1][$j][$k] ";
      }
      print "\n";
    }
  }
  print "\n";

  return (\@weight_mat);
}

sub file_write_weights{
  my ($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref) = @_;
  my @weight_mat = @ {$weight_mat_ref};

  my $file_wb = $file_path . $file_name . ".iw";
  open (my $fid_wb, '>', $file_wb);
  print $fid_wb "[";
  foreach my $i (2 .. $layer_cnt){
    printf $fid_wb "%d ", ${$layer_arr_ref}[$i-1];
  }
  printf $fid_wb "%d] \n", ${$layer_arr_ref}[$layer_cnt];

  for (my $i=2; $i<=$layer_cnt; $i++){
    printf $fid_wb "Hidden Layer #%d \n", $i-1;
    my $pi_cnt = ${$layer_arr_ref}[$i-1];
    my $po_cnt = ${$layer_arr_ref}[$i];
    foreach my $j (1 .. $po_cnt){
      foreach my $k (1 .. $pi_cnt+1){
        print $fid_wb "$weight_mat[$i-1][$j][$k] ";
      }
      print $fid_wb "\n";
    }
  }
}

sub update_layer_weight{
  my ($layer_cnt, $layer_arr_ref, $weight_mat_ref) = @_;
  my @layer_arr = @ {$layer_arr_ref};
  my @weight_mat = @ {$weight_mat_ref};

  my @new_layer_arr = ();
  my @new_weight_mat = ();
  $new_layer_arr[1] = $layer_arr[1];

  my @all_zero_mat = ();
  foreach my $i (1 .. $layer_cnt){
    $all_zero_mat[$i][0] = 0;
  }

  for (my $i=2; $i<=$layer_cnt; $i++){
    my $pi_cnt = $layer_arr[$i-1];
    my $po_cnt = $layer_arr[$i];

    $new_layer_arr[$i] = 0;
    foreach my $j (1 .. $po_cnt){
      my $all_zero = 1;
      foreach my $k (1 .. $pi_cnt+1){
        if ($weight_mat[$i-1][$j][$k]){
          $all_zero = 0;
          last;
        }
      }
      if (!$all_zero){
        my $new_input_cnt = 0;
        $new_layer_arr[$i]++;
        foreach my $k (1 .. $pi_cnt+1){
          if (!$all_zero_mat[$i-1][0]){
            $new_input_cnt++;
            $new_weight_mat[$i-1][$new_layer_arr[$i]][$new_input_cnt] = $weight_mat[$i-1][$j][$k];
          }
          else{
            my $is_inside = 0;
            foreach my $m (1 .. $all_zero_mat[$i-1][0]){
              if ($k == $all_zero_mat[$i-1][$m]){
                $is_inside = 1;
                last;
              }
            }

            if (!$is_inside){
              $new_input_cnt++;
              $new_weight_mat[$i-1][$new_layer_arr[$i]][$new_input_cnt] = $weight_mat[$i-1][$j][$k];
            }
          }
        }
      }
      else{
        $all_zero_mat[$i][0]++;
        $all_zero_mat[$i][$all_zero_mat[$i][0]] = $j;
      }
    }
  }

  return (\@new_layer_arr, \@new_weight_mat);
}

sub main_part{
  if (-e $file_weight){
    my $initial_time = time();

    my $say_add = 0;
    my $pre_acc = 0;
    my $pre_cost = 0;
    my $hard_acc = 0;
    my $last_time = 0;
    my $pre_cpu_time = 0;
    my $ver_file_cnt = 0;
    my @ver_file_arr = ();
    
    my $val_cnt;
    my $min_quan_val;
    my $val_in_mat_ref;
    my $val_out_mat_ref;

    my $pre_hard_cost;
    my $pre_max_weight_width;

    #Read the weights
    my ($is_err, $layer_cnt, $layer_arr_ref, $weight_mat_ref) = file_read_weights();

    if (!$is_err){
      #Generate the activation function default values on hidden and output layers
      if ($act_fun_cnt == 1){
        foreach my $i (1 .. $layer_cnt-1){
          $act_fun_cnt++;
          $act_fun_arr[$act_fun_cnt] = "htanh";
        }
        $act_fun_arr[$layer_cnt] = "lin";
      }

      if ($act_fun_cnt == $layer_cnt){
        #Quantize weights
        $min_quan_val = $quan_bit;
        if ($quan_bit){
          ($weight_mat_ref) = quantize_weights($min_quan_val, $layer_cnt, $layer_arr_ref, $weight_mat_ref);
        }

        #Analyze the weights
        my ($hard_cost, $max_weight_width) = analyze_weights("", $min_quan_val, $layer_cnt, $layer_arr_ref, $weight_mat_ref);

        #Remove the neurons with weights and bias equal to 0
        ($layer_arr_ref, $weight_mat_ref) = update_layer_weight($layer_cnt, $layer_arr_ref, $weight_mat_ref);

        #Generate the file names
        my $file_name = '';
        my $file_path = '';
        my $file_summary = '';
        my $file_verilog = '';
        my $path_index = length($file_weight);
        while ($path_index > -1){
          if (substr($file_weight, $path_index, 1) eq "/" or substr($file_weight, $path_index, 1) eq "\\"){
            last;
          }
          $path_index--;
        }

        if ($path_index > -1){
          $file_path = substr($file_weight, 0, $path_index+1);
        }
        $path_index++;

        my $dot_index = index($file_weight, ".", $path_index);
        if ($dot_index != -1){
          $dot_index--;
        }
        else{
          $dot_index = length($file_weight);
        }
        $file_name = substr($file_weight, $path_index, $dot_index-$path_index+1);
        $file_name .= "_i" . $in_width . "_o" . $out_width . "_q" . $min_quan_val;

        if ($the_tech == 1){
          $file_name .= "_par_beh";
        }
        elsif ($the_tech == 2){
          $file_name .= "_par_mcm_" . $the_aim;
        }
        if ($the_tech == 3){
          $file_name .= "_par_cavm_" . $the_aim;
        }
        elsif ($the_tech == 4){
          $file_name .= "_par_cmvm_" . $the_rep . "_" . $the_aim;
        }
        elsif ($the_tech == 5){
          $file_name .= "_smac_neuron_beh";
        }
        elsif ($the_tech == 6){
          $file_name .= "_smac_neuron_mcm_" . $the_aim;
        }
        elsif ($the_tech == 7){
          $file_name .= "_smac_ann";
        }
        if ($is_creg){
          $file_name .= "_creg";
        }
        $file_name .= "_act";
        for (my $i=2; $i<=$act_fun_cnt; $i++){
          if ($act_fun_arr[$i] eq "lin"){
            $file_name .= "0";
          }
          elsif ($act_fun_arr[$i] eq "relu"){
            $file_name .= "1";
          }
          elsif ($act_fun_arr[$i] eq "hsig"){
            $file_name .= "2";
          }
          elsif ($act_fun_arr[$i] eq "htanh"){
            $file_name .= "3";
          }
          elsif ($act_fun_arr[$i] eq "satlin"){
            $file_name .= "4";
          }
        }
        #print "file_name: $file_name \n";
        
        if ($the_wout){
          file_write_weights($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref);
        }

        $file_verilog = $file_path . $file_name . ".v";
        $file_summary = $file_path . $file_name . ".summary";
        
        $ver_file_cnt++;
        $ver_file_arr[$ver_file_cnt] = $file_name . ".v";
        my $ver_file_arr_ref = \@ver_file_arr;

        my $wo_size_ref;
        my $muladd_width_mat_ref;
        my $neuron_width_mat_ref;
        my $weight_width_mat_ref;

        my $path_algo; 
        my $paths_ok = 1; 
        my $path_high2low;
        
        my $map_ok = 1; 
        my $is_ver_gen;
        my @exap_map_mat;

        #Generate the Verilog design files and the test bench
        if ($the_tech == 1){
          ($neuron_width_mat_ref) = generate_verilog_code_weight_constant($file_path, $file_name, $file_verilog, $layer_cnt, $layer_arr_ref, $weight_mat_ref, \@act_fun_arr);
          ($hard_acc) = generate_testbench($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, \@act_fun_arr);
        }
        elsif ($the_tech == 2){
          ($paths_ok, $path_algo, $path_high2low) = extract_paths("paths.pl");
          if ($paths_ok){
            ($ver_file_cnt, $ver_file_arr_ref, $muladd_width_mat_ref, $neuron_width_mat_ref) = generate_verilog_code_shift_adds($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, \@act_fun_arr);
            ($say_add, $ver_file_cnt, $ver_file_arr_ref) = generate_verilog_code_layer_mcm($file_path, $file_name, $path_algo, $path_high2low, $say_add, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $muladd_width_mat_ref);
            ($hard_acc) = generate_testbench($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, \@act_fun_arr);
          }
        }
        elsif ($the_tech == 3){
          ($paths_ok, $path_algo, $path_high2low) = extract_paths("paths.pl");
          if ($paths_ok){
            ($ver_file_cnt, $ver_file_arr_ref, $muladd_width_mat_ref, $neuron_width_mat_ref) = generate_verilog_code_shift_adds($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, \@act_fun_arr);
            ($say_add, $ver_file_cnt, $ver_file_arr_ref) = generate_verilog_code_layer_cavm($file_path, $file_name, $path_algo, $path_high2low, $say_add, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $muladd_width_mat_ref);
            ($hard_acc) = generate_testbench($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, \@act_fun_arr);
          }
        }
        elsif ($the_tech == 4){
          ($paths_ok, $path_algo, $path_high2low) = extract_paths("paths.pl");
          if ($paths_ok){
            ($ver_file_cnt, $ver_file_arr_ref, $muladd_width_mat_ref, $neuron_width_mat_ref) = generate_verilog_code_shift_adds($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, \@act_fun_arr);
            ($say_add) = generate_verilog_code_layer_cmvm($file_path, $file_name, $path_algo, $path_high2low, $say_add, $layer_cnt, $layer_arr_ref, $weight_mat_ref);
            ($hard_acc) = generate_testbench($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, \@act_fun_arr);
          }
        }
        elsif ($the_tech == 5){
          ($ver_file_cnt, $ver_file_arr_ref, $muladd_width_mat_ref, $neuron_width_mat_ref) = generate_verilog_code_mac($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, \@act_fun_arr);
          ($hard_acc) = generate_testbench_mac($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, \@act_fun_arr);
        }
        elsif ($the_tech == 6){
          ($paths_ok, $path_algo, $path_high2low) = extract_paths("paths.pl");
          if ($paths_ok){ 
            ($say_add, $ver_file_cnt, $ver_file_arr_ref, $muladd_width_mat_ref, $neuron_width_mat_ref) = generate_verilog_code_mac_mcmmux($file_path, $file_name, $file_verilog, $ver_file_cnt, $ver_file_arr_ref, $path_algo, $path_high2low, $layer_cnt, $layer_arr_ref, $weight_mat_ref, \@act_fun_arr);
            ($hard_acc) = generate_testbench_mac($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, \@act_fun_arr);
          }
        }
        elsif ($the_tech == 7){
          ($ver_file_cnt, $ver_file_arr_ref, $muladd_width_mat_ref, $neuron_width_mat_ref) = generate_verilog_code_smac($file_path, $file_name, $file_verilog, $path_high2low, $ver_file_cnt, $ver_file_arr_ref, $layer_cnt, $layer_arr_ref, $weight_mat_ref, \@act_fun_arr, \@exap_map_mat);
          ($hard_acc) = generate_testbench_mac($file_path, $file_name, $layer_cnt, $layer_arr_ref, $weight_mat_ref, $neuron_width_mat_ref, \@act_fun_arr);
        }

        $last_time = time() - $initial_time;
        print "\n";
        printf "[INFO] Hardware cost: %0d \n", $hard_cost;
        if (($the_tech > 1 and $the_tech < 5) or $the_tech == 8){
          print "[INFO] Total number of additions: $say_add \n";
        }
        print "[INFO] Total CPU time: $last_time \n";
      }
      else{
        print "[ERROR] Activation function for each hidden layer and the output layer is NOT defined properly! \n";
      }
    }
  }
  else{
    print "[ERROR] The $file_weight file does NOT exist! \n";
  }
}

