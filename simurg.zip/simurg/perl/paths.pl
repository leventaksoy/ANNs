cmvm_algo = C:/Users/ECC-LAB/Levent/codes/mex/cmvm_algo
cmvm_dc_algo = C:/Users/ECC-LAB/Levent/codes/mex/cmvm_dc_algo
cmvm_high2low = C:/Users/ECC-LAB/Levent/codes/mex/cmvm_high2low
mcm_algo = C:/Users/ECC-LAB/Levent/codes/mex/mcm_algo
mcm_high2low = C:/Users/ECC-LAB/Levent/codes/mex/mcm_high2low
cavm_algo = C:/Users/ECC-LAB/Levent/codes/mex/cavm_algo
cavm_high2low = C:/Users/ECC-LAB/Levent/codes/mex/cavm_high2low
cmul_high2low = C:/Users/ECC-LAB/Levent/codes/mex/cmul_high2low

