function cavm_high2low (file_result, bitwidth)

x_bitwidth=str2num(bitwidth);

%x_bitwidth=input('Bitwidth of the input variables: ');
%file_result=input('Filename where the solution of the high-level algorithm exists: ','s');

%The name of the output file and module name is generated.
dot_found=0;
file_name='';
slash_found=0;
module_name='';

for i=1:length(file_result)
    if file_result(1,i)=='.'
        dot_found=i;
        break
    end
    if or(file_result(1,i)== '/', file_result(1,i)== '\')
        slash_found=i;
    end
end

if dot_found
    file_name=file_result(1:1,1:i-1);
else
    dot_found = length(file_result)+1;
    file_name=file_result;
end

if slash_found
    module_name=file_result(1:1,slash_found+1:dot_found-1);
else
    module_name=file_result(1:1,1:dot_found-1);
end

[say_column,say_output,output_list,say_partial,partial_list,partial_imp,max_level]=file_read_result(file_result);
[output_indis,output_width]=write_cmvm_signed_verilog(file_name,module_name,x_bitwidth,say_column,say_output,output_list,say_partial,partial_list,partial_imp);

function [say_column,say_output,output_list,say_partial,partial_list,partial_imp,max_level] = file_read_result(file_result)

say_column=0;
say_output=0;
output_list=[];

max_level=0;
say_partial=0;
partial_imp=[];
partial_list=[];

fid_result=fopen(file_result,'r');

while 1
    the_line=fgetl(fid_result);
    
    if the_line==-1
        break
    else
        if or(strcmp('*** Implementation of Primary Expressions ***',the_line),strcmp('*** Implementation of Primary Expressions *** ',the_line))
            the_line=fgetl(fid_result);
            while 1
                the_line=fgetl(fid_result);
                if isempty(the_line)
                    break
                else
                    say_output=say_output+1;

                    the_cursor=1;
                    while the_line(1,the_cursor)~='('
                        the_cursor=the_cursor+1;
                    end
                    the_cursor=the_cursor+1;

                    while 1
                        if the_line(1,the_cursor)=='+'
                            neg_pos=1;
                        elseif the_line(1,the_cursor)=='-'
                            neg_pos=-1;
                        end

                        the_cursor=the_cursor+1;
                        the_initial=the_cursor;
                        while the_line(1,the_cursor)~='*'
                            the_cursor=the_cursor+1;
                        end
                        the_constant=str2num(char(the_line(1:1,the_initial:the_cursor-1)));

                        the_cursor=the_cursor+2;
                        the_initial=the_cursor;
                        while and(and(the_line(1,the_cursor)~='+',the_line(1,the_cursor)~='-'),the_line(1,the_cursor)~=')')
                            the_cursor=the_cursor+1;
                        end
                        the_indis=str2num(char(the_line(1:1,the_initial:the_cursor-1)));

                        output_list(say_output,the_indis)=neg_pos*the_constant;

                        if the_line(1,the_cursor)==')'
                            break
                        end
                    end
                end
            end
        elseif or(strcmp('*** Implementation of Expressions ***',the_line),strcmp('*** Implementation of Expressions *** ',the_line))
            the_line=fgetl(fid_result);
            
            sol=size(output_list);
            say_column=sol(1,2);
            
            say_partial=say_column;
            partial_list=eye(say_column);
            partial_imp=zeros(say_column,4);
            partial_indis=zeros(say_column,2);
            
            while 1
                the_line=fgetl(fid_result);
                if isempty(the_line)
                    break
                else
                    say_partial=say_partial+1;
                    
                    the_cursor=1;
                    if the_line(1,the_cursor)=='S'
                        partial_indis(say_partial,1)=1;
                    elseif the_line(1,the_cursor)=='O'
                        partial_indis(say_partial,1)=-1;
                    end
                    
                    the_cursor=the_cursor+1;
                    the_initial=the_cursor;
                    while the_line(1,the_cursor)~=':'
                        the_cursor=the_cursor+1;
                    end
                    partial_indis(say_partial,2)=str2num(char(the_line(1:1,the_initial:the_cursor-1)));
                    
                    the_cursor=the_cursor+3;
                    while 1
                        if the_line(1,the_cursor)=='+'
                            neg_pos=1;
                        elseif the_line(1,the_cursor)=='-'
                            neg_pos=-1;
                        end

                        the_cursor=the_cursor+1;
                        the_initial=the_cursor;
                        while the_line(1,the_cursor)~='*'
                            the_cursor=the_cursor+1;
                        end
                        the_constant=str2num(char(the_line(1:1,the_initial:the_cursor-1)));

                        the_cursor=the_cursor+2;
                        the_initial=the_cursor;
                        while and(and(the_line(1,the_cursor)~='+',the_line(1,the_cursor)~='-'),the_line(1,the_cursor)~=')')
                            the_cursor=the_cursor+1;
                        end
                        the_indis=str2num(char(the_line(1:1,the_initial:the_cursor-1)));

                        partial_list(say_partial,the_indis)=neg_pos*the_constant;

                        if the_line(1,the_cursor)==')'
                            break
                        end
                    end
                    
                    the_cursor=the_cursor+4;
                    if the_line(1,the_cursor)=='+'
                        neg_pos=1;
                    elseif the_line(1,the_cursor)=='-'
                        neg_pos=-1;
                    end
                    
                    the_cursor=the_cursor+1;
                    if the_line(1,the_cursor)=='X'
                        the_indis(1,1)=0;
                    elseif the_line(1,the_cursor)=='S'
                        the_indis(1,1)=1;
                    elseif the_line(1,the_cursor)=='O'
                        the_indis(1,1)=-1;
                    end
                    
                    the_cursor=the_cursor+1;
                    the_initial=the_cursor;
                    while the_line(1,the_cursor)~='<'
                        the_cursor=the_cursor+1;
                    end
                    the_indis(1,2)=str2num(char(the_line(1:1,the_initial:the_cursor-1)));
                    
                    the_cursor=the_cursor+2;
                    the_initial=the_cursor;
                    while the_line(1,the_cursor)~=' '
                        the_cursor=the_cursor+1;
                    end
                    the_power=str2num(char(the_line(1:1,the_initial:the_cursor-1)));
                    
                    partial_imp(say_partial,1)=neg_pos*2^(the_power);
                    partial_imp(say_partial,2)=find_true_indis(say_column,the_indis,say_partial,partial_indis);                    
                    
                    if ~partial_imp(say_partial,2)
                        fprintf('There is something wrong in finding the index in %d expression. Returning...\n',say_partial);
                        return
                    end
                    
                    the_cursor=the_cursor+1;
                    if the_line(1,the_cursor)=='+'
                        neg_pos=1;
                    elseif the_line(1,the_cursor)=='-'
                        neg_pos=-1;
                    end
                    
                    the_cursor=the_cursor+1;
                    if the_line(1,the_cursor)=='X'
                        the_indis(1,1)=0;
                    elseif the_line(1,the_cursor)=='S'
                        the_indis(1,1)=1;
                    elseif the_line(1,the_cursor)=='O'
                        the_indis(1,1)=-1;
                    end
                    
                    the_cursor=the_cursor+1;
                    the_initial=the_cursor;
                    while the_line(1,the_cursor)~='<'
                        the_cursor=the_cursor+1;
                    end
                    the_indis(1,2)=str2num(char(the_line(1:1,the_initial:the_cursor-1)));
                    
                    the_cursor=the_cursor+2;
                    the_power=str2num(char(the_line(1:1,the_cursor:length(the_line))));
                    
                    partial_imp(say_partial,3)=neg_pos*2^(the_power);
                    partial_imp(say_partial,4)=find_true_indis(say_column,the_indis,say_partial,partial_indis);
                    
                    if ~partial_imp(say_partial,4)
                        fprintf('There is something wrong in finding the index in %d expression. Returning...\n',say_partial);
                        return
                    end
                    
                end
                
            end 
        end
    end
end

fclose(fid_result);

function [output_indis,output_width] = write_cmvm_signed_verilog(file_name,module_name,input_width,say_column,say_output,output_list,say_partial,partial_list,partial_imp)

output_indis=zeros(say_output,3);
output_width=zeros(say_output,1);
for i=1:say_output
    abs_value=0;
    for j=1:say_column
        abs_value=abs_value+abs(output_list(i,j));
    end
    output_width(i,1)=floor(log2(abs_value))+input_width+1;
    
    [output_indis(i,1),output_indis(i,2),odd_out]=make_array_posodd(say_column,output_list(i,:));
    [output_indis(i,3)]=whereis_inside_array(odd_out,say_column,say_partial,partial_list);
    if output_indis(i,3)==0
        %fprintf ('[ERROR] Output is not in the given list! \n');
        negated_odd_out = (-1).*odd_out;
        [output_indis(i,3)]=whereis_inside_array(negated_odd_out,say_column,say_partial,partial_list);
        if output_indis(i,3)==0
            fprintf ('[ERROR] Output is not in the given list! \n');
        else
            output_indis(i,1) = (-1)*output_indis(i,1);
        end
        
    end
end

exp_bits=zeros(say_partial,1);
for i=say_column+1:say_partial
    abs_value=0;
    for j=1:say_column
        abs_value=abs_value+abs(partial_list(i,j));
    end
    exp_bits(i,1)=floor(log2(abs_value))+input_width+1;
end

file_vhd=[file_name,'.v'];
fid_vhd=fopen(file_vhd,'w');

fprintf(fid_vhd,'// Verilog Description of the Shift-Adds Design of the CMVM Block under the Signed Input\n');
fprintf(fid_vhd,'// Total Number of Additions/Subtractions: %d \n',say_partial-say_column);
fprintf(fid_vhd,'\n');
for i=1:say_column
    ins{1,i}=sprintf('x%d,',i);
end
ins=char(ins);
ins=transpose(ins);

for i=1:say_output-1
    outs{1,i}=sprintf('y%d,',i);
end
outs{1,say_output}=sprintf('y%d',say_output);
outs=char(outs);
outs=transpose(outs);

fprintf(fid_vhd,'module %s (%s%s);\n',module_name,ins,outs);
fprintf(fid_vhd,'\n');
for i=1:say_column
    fprintf(fid_vhd,'input signed [%d:0] x%d;\n',input_width-1,i);
end
for i=1:say_output-1
    fprintf(fid_vhd,'output signed [%d:0] y%d;\n',output_width(i,1)-1,i);
end
fprintf(fid_vhd,'output signed [%d:0] y%d;\n',output_width(say_output,1)-1,say_output);
fprintf(fid_vhd,'\n');

for i=say_column+1:1:say_partial
 fprintf(fid_vhd,'wire signed [%d:0] s%d;\n',exp_bits(i,1)-1,i-say_column);
end
fprintf(fid_vhd,'\n');

for i=say_column+1:1:say_partial
    shift_one=log2(abs(partial_imp(i,1)));
    shift_two=log2(abs(partial_imp(i,3)));
    
    fprintf(fid_vhd,'//s%d = ',i-say_column);
    for j=1:say_column
        if partial_list(i,j)
            if partial_list(i,j)>0
                fprintf(fid_vhd,'+%dx%d ',partial_list(i,j),j);
            else
                fprintf(fid_vhd,'%dx%d ',partial_list(i,j),j);
            end
        end
    end
    fprintf(fid_vhd,'= ');
    if and(partial_imp(i,1)>0,partial_imp(i,3)>0)
        if and(partial_imp(i,2)<=say_column,partial_imp(i,4)<=say_column)
            fprintf(fid_vhd,'x%d<<%d + x%d<<%d\n',partial_imp(i,2),shift_one,partial_imp(i,4),shift_two);
        elseif and(partial_imp(i,2)>say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'s%d<<%d + s%d<<%d\n',partial_imp(i,2)-say_column,shift_one,partial_imp(i,4)-say_column,shift_two);
        elseif and(partial_imp(i,2)<=say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'x%d<<%d + s%d<<%d\n',partial_imp(i,2),shift_one,partial_imp(i,4)-say_column,shift_two);
        else
            fprintf(fid_vhd,'s%d<<%d + x%d<<%d\n',partial_imp(i,2)-say_column,shift_one,partial_imp(i,4),shift_two);
        end
        
        fprintf(fid_vhd,'\n');
        
        fprintf(fid_vhd,'assign s%d=(',i-say_column);

        if partial_imp(i,2)<=say_column
            fprintf(fid_vhd,'(x%d',partial_imp(i,2));
        else
            fprintf(fid_vhd,'(s%d',partial_imp(i,2)-say_column);
        end
        if shift_one
            fprintf(fid_vhd,'<<<%d',shift_one);
        end
        fprintf(fid_vhd,') + (');
        if partial_imp(i,4)<=say_column
            fprintf(fid_vhd,'x%d',partial_imp(i,4));
        else
            fprintf(fid_vhd,'s%d',partial_imp(i,4)-say_column);
        end
        if shift_two
            fprintf(fid_vhd,'<<<%d',shift_two);
        end
        fprintf(fid_vhd,'));\n');
        
    elseif and(partial_imp(i,1)>0,partial_imp(i,3)<0)
        if and(partial_imp(i,2)<=say_column,partial_imp(i,4)<=say_column)
            fprintf(fid_vhd,'x%d<<%d - x%d<<%d\n',partial_imp(i,2),shift_one,partial_imp(i,4),shift_two);
        elseif and(partial_imp(i,2)>say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'s%d<<%d - s%d<<%d\n',partial_imp(i,2)-say_column,shift_one,partial_imp(i,4)-say_column,shift_two);
        elseif and(partial_imp(i,2)<=say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'x%d<<%d - s%d<<%d\n',partial_imp(i,2),shift_one,partial_imp(i,4)-say_column,shift_two);
        else
            fprintf(fid_vhd,'s%d<<%d - x%d<<%d\n',partial_imp(i,2)-say_column,shift_one,partial_imp(i,4),shift_two);
        end
        
        fprintf(fid_vhd,'\n');
        first_size=exp_bits(partial_imp(i,2),1)+shift_one;
        second_size=exp_bits(partial_imp(i,4),1)+shift_two;
        max_size=max(first_size,second_size);
        
        if max_size<=exp_bits(i,1)
            fprintf(fid_vhd,'assign s%d=(',i-say_column);
            if partial_imp(i,2)<=say_column
                 fprintf(fid_vhd,'(x%d',partial_imp(i,2));
            else
                fprintf(fid_vhd,'(s%d',partial_imp(i,2)-say_column);
            end
            if shift_one
                fprintf(fid_vhd,'<<<%d',shift_one);
            end
            fprintf(fid_vhd,') - (');
            if partial_imp(i,4)<=say_column
                fprintf(fid_vhd,'x%d',partial_imp(i,4));
            else
                fprintf(fid_vhd,'s%d',partial_imp(i,4)-say_column);
            end
            if shift_two
                fprintf(fid_vhd,'<<<%d',shift_two);
            end
            fprintf(fid_vhd,'));\n');
        else
            fprintf(fid_vhd,'assign s%d =(',i-say_column);
            if partial_imp(i,2)<=say_column
                fprintf(fid_vhd,'(x%d',partial_imp(i,2));
            else
                fprintf(fid_vhd,'(s%d',partial_imp(i,2)-say_column);
            end
            if shift_one
                fprintf(fid_vhd,'<<<%d',shift_one);
            end
            fprintf(fid_vhd,') - (');
            if partial_imp(i,4)<=say_column
                fprintf(fid_vhd,'x%d',partial_imp(i,4));
            else
                fprintf(fid_vhd,'s%d',partial_imp(i,4)-say_column);
            end
            if shift_two
                fprintf(fid_vhd,'<<<%d',shift_two);
            end
            fprintf(fid_vhd,'));\n');
        end
    elseif and(partial_imp(i,1)<0,partial_imp(i,3)>0)
        if and(partial_imp(i,2)<=say_column,partial_imp(i,4)<=say_column)
            fprintf(fid_vhd,'x%d<<%d - x%d<<%d\n',partial_imp(i,4),shift_two,partial_imp(i,2),shift_one);
        elseif and(partial_imp(i,2)>say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'s%d<<%d - s%d<<%d\n',partial_imp(i,4)-say_column,shift_two,partial_imp(i,2)-say_column,shift_one);
        elseif and(partial_imp(i,2)<=say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'s%d<<%d - x%d<<%d\n',partial_imp(i,4)-say_column,shift_two,partial_imp(i,2),shift_one);
        else
            fprintf(fid_vhd,'x%d<<%d - s%d<<%d\n',partial_imp(i,4),shift_two,partial_imp(i,2)-say_column,shift_one);
        end
        
        fprintf(fid_vhd,'\n');
        first_size=exp_bits(partial_imp(i,4),1)+shift_two;
        second_size=exp_bits(partial_imp(i,2),1)+shift_one;
        max_size=max(first_size,second_size);
        
        if max_size<=exp_bits(i,1)
            fprintf(fid_vhd,'assign s%d =(',i-say_column);
            if partial_imp(i,4)<=say_column
                fprintf(fid_vhd,'(x%d',partial_imp(i,4));
            else
                fprintf(fid_vhd,'(s%d',partial_imp(i,4)-say_column);
            end
            if shift_two
                fprintf(fid_vhd,'<<<%d',shift_two);
            end
            fprintf(fid_vhd,') - (');
            if partial_imp(i,2)<=say_column
                fprintf(fid_vhd,'x%d',partial_imp(i,2));
            else
                fprintf(fid_vhd,'s%d',partial_imp(i,2)-say_column);
            end
            if shift_one
                fprintf(fid_vhd,'<<<%d',shift_one);
            end
            fprintf(fid_vhd,'));\n');
        else
            fprintf(fid_vhd,'assign s%d=(',i-say_column);
            if partial_imp(i,4)<=say_column
                fprintf(fid_vhd,'(x%d',partial_imp(i,4));
            else
                fprintf(fid_vhd,'(s%d',partial_imp(i,4)-say_column);
            end
            if shift_two
                fprintf(fid_vhd,'<<<%d',shift_two);
            end
            fprintf(fid_vhd,') - (');
            if partial_imp(i,2)<=say_column
                fprintf(fid_vhd,'x%d',partial_imp(i,2));
            else
                fprintf(fid_vhd,'s%d',partial_imp(i,2)-say_column);
            end
            if shift_one
                fprintf(fid_vhd,'<<<%d',shift_one);
            end
            fprintf(fid_vhd,'));\n');
        end
    else
        if and(partial_imp(i,2)<=say_column,partial_imp(i,4)<=say_column)
            fprintf(fid_vhd,'(-1)*(x%d<<%d + x%d<<%d)\n',partial_imp(i,2),shift_one,partial_imp(i,4),shift_two);
        elseif and(partial_imp(i,2)>say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'(-1)*(s%d<<%d + s%d<<%d)\n',partial_imp(i,2)-say_column,shift_one,partial_imp(i,4)-say_column,shift_two);
        elseif and(partial_imp(i,2)<=say_column,partial_imp(i,4)>say_column)
            fprintf(fid_vhd,'(-1)*(x%d<<%d + s%d<<%d)\n',partial_imp(i,2),shift_one,partial_imp(i,4)-say_column,shift_two);
        else
            fprintf(fid_vhd,'(-1)*(s%d<<%d + x%d<<%d)\n',partial_imp(i,2)-say_column,shift_one,partial_imp(i,4),shift_two);
        end
        
        fprintf(fid_vhd,'\n');
        
        fprintf(fid_vhd,'assign s%d=(',i-say_column);
        if partial_imp(i,2)<=say_column
            fprintf(fid_vhd,'(x%d',partial_imp(i,2));
        else
            fprintf(fid_vhd,'(s%d',partial_imp(i,2)-say_column);
        end
        if shift_one
            fprintf(fid_vhd,'<<<%d',shift_one);
        end
        fprintf(fid_vhd,') + (');
        if partial_imp(i,4)<=say_column
            fprintf(fid_vhd,'x%d',partial_imp(i,4));
        else
            fprintf(fid_vhd,'s%d',partial_imp(i,4)-say_column);
        end
        if shift_two
            fprintf(fid_vhd,'<<<%d',shift_two);
        end
        fprintf(fid_vhd,'));\n');
    end
    fprintf(fid_vhd,'\n');
end

for i=1:say_output
    if output_indis(i,1)==-1
        if ~output_indis(i,2)
            if output_indis(i,3)>say_column
                fprintf(fid_vhd,'assign y%d = s%d;\n',i,output_indis(i,3)-say_column);
            else
                fprintf(fid_vhd,'assign y%d = x%d;\n',i,output_indis(i,3));
            end
        else
            if output_indis(i,3)>say_column
                fprintf(fid_vhd,'assign y%d = s%d<<<%d;\n',i,output_indis(i,3)-say_column,output_indis(i,2));
            else
                fprintf(fid_vhd,'assign y%d = x%d<<<%d;\n',i,output_indis(i,3),output_indis(i,2));
            end
        end
    elseif output_indis(i,1)==1
        if ~output_indis(i,2)
            if output_indis(i,3)>say_column
                fprintf(fid_vhd,'assign y%d = -s%d;\n',i,output_indis(i,3)-say_column);
            else
                fprintf(fid_vhd,'assign y%d = -x%d;\n',i,output_indis(i,3));
            end
        else
            if output_indis(i,3)>say_column
                fprintf(fid_vhd,'assign y%d = -(s%d<<<%d);\n',i,output_indis(i,3)-say_column,output_indis(i,2));
            else
                fprintf(fid_vhd,'assign y%d = -(x%d<<<%d);\n',i,output_indis(i,3),output_indis(i,2));
            end
        end
    end
end

fprintf(fid_vhd,'\n');
fprintf(fid_vhd,'endmodule\n');
fclose(fid_vhd);

function true_indis = find_true_indis(say_column,the_indis,say_partial,partial_indis)

true_indis=0;

if ~the_indis(1,1)
    true_indis=the_indis(1,2);
else
    for i=say_partial-1:-1:say_column+1
        if and(partial_indis(i,1)==the_indis(1,1),partial_indis(i,2)==the_indis(1,2))
            true_indis=i;
            return
        end
    end
end

function [is_neg,power,the_row] = make_array_odd(say_column,the_row)

is_neg=-1;

power=0;
if is_neg
    if is_neg==1
        the_row(1,:)=(-1)*the_row(1,:);
    end
    
    while 1
        divideable=1;
        for i=1:say_column
            if mod(the_row(1,i),2)
                divideable=0;
                break
            end
        end
        
        if divideable
            power=power+1;
            the_row(1,:)=the_row(1,:)/2;
        else
            break
        end
    end
end

function [is_neg,power,the_row] = make_array_posodd(say_column,the_row)

is_neg=0;
for i=1:say_column
    if the_row(1,i)
        if the_row(1,i)>0
            is_neg=-1;
        else
            is_neg=1;
        end
        
        break
    end
end

power=0;
if is_neg
    if is_neg==1
        the_row(1,:)=(-1)*the_row(1,:);
    end
    
    while 1
        divideable=1;
        for i=1:say_column
            if mod(the_row(1,i),2)
                divideable=0;
                break
            end
        end
        
        if divideable
            power=power+1;
            the_row(1,:)=the_row(1,:)/2;
        else
            break
        end
    end
end

function [value] = whereis_inside_array(the_row,say_column,say_list,row_list)

value=0;

for i=1:say_list
    is_equal=1;
    for j=1:say_column
        if row_list(i,j)~=the_row(1,j)
            is_equal=0;
            break
        end
    end
    
    if is_equal
        value=i;
        break
    end
end
