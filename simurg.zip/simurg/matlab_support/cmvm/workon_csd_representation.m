function [say_instances,count_nonzero,cell_nonzero] = workon_csd_representation(the_number)

say_instances=0;
count_nonzero=0;
cell_nonzero=[];

say_instances=1;
[count_nonzero,cell_nonzero]=find_csd_representation(the_number);
