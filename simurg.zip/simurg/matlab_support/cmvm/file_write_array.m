function [] = file_write_array(fid_file,say_column,the_exp)

fprintf(fid_file,'[');

for i=1:say_column-1
    fprintf(fid_file,'%d ',the_exp(1,i));
end

fprintf(fid_file,'%d]',the_exp(1,say_column));