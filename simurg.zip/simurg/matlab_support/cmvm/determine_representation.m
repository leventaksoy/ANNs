function [target_stats,target_repcell] = determine_representation(rep_select,say_column,say_target,target_list)

target_stats=zeros(1,say_target);
target_repcell=cell(1,say_target);

for h=1:say_target
    array_rep=[];
    array_saynonzero=0;
    posodd_row=target_list(h,:);

    for i=1:say_column
        if posodd_row(1,i)
            if not(rep_select)
                [say_ins,say_nonzero,the_rep]=workon_binary_representation(posodd_row(1,i));
            else
                [say_ins,say_nonzero,the_rep]=workon_csd_representation(posodd_row(1,i));
            end

            for j=1:say_nonzero
                array_saynonzero=array_saynonzero+1;
                array_rep(1,array_saynonzero)=the_rep(1,j);
                array_rep(2,array_saynonzero)=i;
            end
        end
    end
    
    target_stats(1,h)=array_saynonzero;
    target_repcell{1,h}=array_rep;
end