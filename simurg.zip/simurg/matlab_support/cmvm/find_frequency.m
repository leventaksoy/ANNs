function [value,divisor_index,target_index] = find_frequency(odd_divisor,say_target,count_terms,terms_cell)

value=0;
target_index=[];
divisor_index=[];
say_match_found=0;

for i=1:say_target
    the_terms=terms_cell{1,i};
    
    indis_one=odd_divisor(2,1);
    indis_two=odd_divisor(2,2);
    
    is_match_found=0;
    if indis_one==indis_two
        say_one=0;
        list_one=[];
        
        for j=1:count_terms(1,i)
            if the_terms(2,j)==indis_one
                say_one=say_one+1;
                list_one(1,say_one)=the_terms(1,j);
                list_one(2,say_one)=j;
                list_one(3,say_one)=1;
            end
        end
        
        for j=1:say_one-1
            if list_one(3,j)
                carpan=odd_divisor(1,1)/list_one(1,j);
                the_other=odd_divisor(1,2)/carpan;
                
                for k=j+1:1:say_one
                    if the_other==list_one(1,k)
                        if list_one(3,k)
                            value=value+1;
                            list_one(3,j)=0;
                            list_one(3,k)=0;
                            is_match_found=1;
                            
                            target_index(1,3*value-2)=i;
                            target_index(1,3*value-1)=list_one(2,j);
                            target_index(1,3*value)=list_one(2,k);
                            break
                        end
                    end
                end
                
            end
        end
    else
        say_one=0;
        say_two=0;
        list_one=[];
        list_two=[];
        
        for j=1:count_terms(1,i)
            if the_terms(2,j)==indis_one
                say_one=say_one+1;
                list_one(1,say_one)=the_terms(1,j);
                list_one(2,say_one)=j;
            end
            if the_terms(2,j)==indis_two
                say_two=say_two+1;
                list_two(1,say_two)=the_terms(1,j);
                list_two(2,say_two)=j;
            end
        end
        
        if and(say_one,say_two)
            for j=1:say_one
                carpan=odd_divisor(1,1)/list_one(1,j);
                the_other=odd_divisor(1,2)/carpan;
                
                for k=1:say_two
                    if the_other==list_two(1,k)
                        value=value+1;
                        is_match_found=1;
                        
                        target_index(1,3*value-2)=i;
                        target_index(1,3*value-1)=list_one(2,j);
                        target_index(1,3*value)=list_two(2,k);
                        break
                    end
                end
            end
        end    
    end
    
    if is_match_found
        say_match_found=say_match_found+1;
        divisor_index(1,say_match_found)=i;
    end
end
