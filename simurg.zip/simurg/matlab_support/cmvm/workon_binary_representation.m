function [say_instances,count_nonzero,cell_nonzero] = workon_binary_representation(the_number)

say_instances=1;
count_nonzero=0;
cell_nonzero=[];

is_neg=0;
if the_number<0
    is_neg=1;
    the_number=the_number*(-1);
end

if the_number~=0
    say_digit=0;
    while the_number~=1
        say_digit=say_digit+1;
        remainder=mod(the_number,2);
        if remainder==0
            the_number=the_number/2;
        else
            the_number=(the_number-1)/2;
            count_nonzero=count_nonzero+1;
            cell_nonzero(1,count_nonzero)=2^(say_digit-1);
        end
    end
    
    count_nonzero=count_nonzero+1;
    cell_nonzero(1,count_nonzero)=2^(say_digit);
    
    if is_neg
        cell_nonzero=cell_nonzero*(-1);
    end
else
    cell_nonzero{1,1}=0;
end
