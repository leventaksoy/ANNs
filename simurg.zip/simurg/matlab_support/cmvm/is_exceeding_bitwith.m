function [value] = is_exceeding_bitwith(say_column,the_bitwidth,the_exp)

value=0;

for i=1:say_column
    if the_exp(1,i)
        if ceil(log2(abs(the_exp(1,i))))>the_bitwidth
            value=1;
            return
        end
    end
end
