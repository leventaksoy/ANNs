function [the_cost,best_say_partial,best_partial_list,best_partial_imp] = find_implementation_cost(say_column,the_bitwidth,say_primary,primary_list,say_partial,partial_list,partial_imp,say_target,target_list,target_stats,target_repcell)

the_cost=0;
best_say_partial=0;
best_partial_list=[];
best_partial_imp=[];

for i=1:say_target
    reverse=0;
    the_rep=target_repcell{1,i};

    while target_stats(1,i)~=1
        if reverse
            reverse=0;

            the_divisor(:,1)=the_rep(:,target_stats(1,i));
            the_divisor(:,2)=the_rep(:,target_stats(1,i)-1);
            
            divisor_array=divisor2array(say_column,the_divisor,partial_list);
            [is_neg,power,posodd_divisor_array]=make_array_posodd(say_column,divisor_array);
            the_divisor(1,:)=(-1)*is_neg*the_divisor(1,:)/(2^power);
            
            say_partial=say_partial+1;
            partial_list(say_partial,:)=posodd_divisor_array;
            partial_imp(say_partial,1)=the_divisor(1,1);
            partial_imp(say_partial,2)=the_divisor(2,1);
            partial_imp(say_partial,3)=the_divisor(1,2);
            partial_imp(say_partial,4)=the_divisor(2,2);
            
            the_rep(:,target_stats(1,i))=[];
            target_stats(1,i)=target_stats(1,i)-1;
            the_rep(1,target_stats(1,i))=is_neg*(-1)*(2^power);
            the_rep(2,target_stats(1,i))=say_partial;
        else
            reverse=1;

            the_divisor(:,1)=the_rep(:,1);
            the_divisor(:,2)=the_rep(:,2);
            
            divisor_array=divisor2array(say_column,the_divisor,partial_list);
            [is_neg,power,posodd_divisor_array]=make_array_posodd(say_column,divisor_array);
            the_divisor(1,:)=(-1)*is_neg*the_divisor(1,:)/(2^power);
            
            say_partial=say_partial+1;
            partial_list(say_partial,:)=posodd_divisor_array;
            partial_imp(say_partial,1)=the_divisor(1,1);
            partial_imp(say_partial,2)=the_divisor(2,1);
            partial_imp(say_partial,3)=the_divisor(1,2);
            partial_imp(say_partial,4)=the_divisor(2,2);
            
            the_rep(:,1)=[];
            target_stats(1,i)=target_stats(1,i)-1;
            the_rep(1,1)=is_neg*(-1)*(2^power);
            the_rep(2,1)=say_partial;
        end
    end
end

the_cost=say_partial;
best_say_partial=say_partial;
best_partial_list=partial_list;
best_partial_imp=partial_imp;

int_say_partial=say_column;
int_partial_list=eye(say_column);

int_add_list=[];
int_say_add=say_column;
for i=1:say_column
    int_add_list(1,i)=i;
end

int_say_target=say_partial-say_column;
int_target_list=partial_list(say_column+1:say_partial,:);

say_deleted=0;

while 1
    say_deleted=say_deleted+1;
    
    if say_deleted>int_say_target
        break
    else
        if ~is_inside_array(int_target_list(say_deleted,:),say_column,say_primary,primary_list)
            
            say_add=int_say_add;
            add_list=int_add_list;
            say_partial=int_say_partial;
            partial_list=int_partial_list;

            say_target=int_say_target;
            target_list=int_target_list;
            say_target=say_target-1;
            target_list(say_deleted,:)=[];

            [the_say_partial,the_partial_list,the_partial_imp,the_say_target,the_target_list]=find_optimal_solution(say_column,the_bitwidth,say_partial,partial_list,partial_imp,say_add,add_list,say_target,target_list);

            if ~say_target
                the_cost=the_say_partial;
                best_say_partial=the_say_partial;
                best_partial_list=the_partial_list;
                best_partial_imp=the_partial_imp;

                int_say_target=the_say_target;
                int_target_list=the_target_list;

                say_deleted=say_deleted-1;
                
                fprintf('One subexpression is removed. Oley! \n');
            end
        end
    end
end
