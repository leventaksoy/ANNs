function [say_diff,diff_list,say_target,target_list,target_cost] = find_optimal_difference(rep_select,say_column,the_bitwidth,say_target,target_list,target_cost)

for i=1:say_column
    say_target=say_target+1;
    target_list(say_target,:)=zeros(1,say_column);
    target_list(say_target,i)=1;
    target_cost(:,say_target)=[1;1];
end

say_diff=0;
diff_list=[];

say_deleted=0;
deleted_list=[];

for i=1:1:say_target-say_column
    is_found=0;
    the_target=target_list(i,:);
    
    for j=i+1:1:say_target
        the_partial=target_list(j,:);
        
        for us=0:1:the_bitwidth
            the_exp=the_target-(2^us)*the_partial;
            
            if is_exceeding_bitwith(say_column,the_bitwidth,the_exp)
                break
            else
                [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                the_pos=whereis_inside_array(posodd_exp,say_column,say_target,target_list);
                
                if the_pos>i
                    is_found=1;
                    
                    say_diff=say_diff+1;
                    diff_list(say_diff,:)=the_target;
                    
                    say_deleted=say_deleted+1;
                    deleted_list(1,say_deleted)=i;
                    break
                end
            end
        end
        
        if ~is_found
            for us=0:1:the_bitwidth
                the_exp=the_target+(2^us)*the_partial;

                if is_exceeding_bitwith(say_column,the_bitwidth,the_exp)
                    break
                else
                    [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                    the_pos=whereis_inside_array(posodd_exp,say_column,say_target,target_list);

                    if the_pos>i
                        is_found=1;

                        say_diff=say_diff+1;
                        diff_list(say_diff,:)=the_target;

                        say_deleted=say_deleted+1;
                        deleted_list(1,say_deleted)=i;
                        break
                    end
                end
            end
        end
        
        if is_found
            break
        end
    end
end

for i=1:say_column
    say_deleted=say_deleted+1;
    deleted_list(1,say_deleted)=say_target-say_column+i;
end

for i=1:say_deleted
    say_target=say_target-1;
    target_list(deleted_list(1,i)-i+1,:)=[];
    target_cost(:,deleted_list(1,i)-i+1)=[];
end
