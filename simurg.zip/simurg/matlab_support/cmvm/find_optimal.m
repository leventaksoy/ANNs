function [say_partial,partial_list,partial_imp,say_target,target_list,target_stats,target_repcell] = find_optimal(say_column,the_bitwidth,say_partial,partial_list,partial_imp,say_add,add_list,say_target,target_list,target_stats,target_repcell)

while 1
    imp_list=[];
    new_sayadd=0;
    new_addlist=[];
    
    for j=1:say_target
        the_target=target_list(j,:);
        is_found=0;
        
        for i=1:say_add
            the_partial=partial_list(add_list(1,i),:);

            for us=0:1:the_bitwidth
                the_exp=the_target-(2^us)*the_partial;
                
                if is_exceeding_bitwith(say_column,the_bitwidth,the_exp)
                    break
                else
                    [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                    exp_pos=whereis_inside_array(posodd_exp,say_column,say_partial,partial_list);
                    
                    if exp_pos
                        is_found=1;
                        new_sayadd=new_sayadd+1;
                        new_addlist(1,new_sayadd)=j;
                        
                        imp_list(new_sayadd,1)=(-1)*is_neg*(2^the_power);
                        imp_list(new_sayadd,2)=exp_pos;
                        imp_list(new_sayadd,3)=2^(us);
                        imp_list(new_sayadd,4)=add_list(1,i);
                        
                        break
                    end
                end
            end
            
            if is_found
                break
            else
                for us=0:1:the_bitwidth
                    the_exp=the_target+(2^us)*the_partial;

                    if is_exceeding_bitwith(say_column,the_bitwidth,the_exp)
                        break
                    else
                        [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                        exp_pos=whereis_inside_array(posodd_exp,say_column,say_partial,partial_list);
                        
                        if exp_pos
                            is_found=1;
                            new_sayadd=new_sayadd+1;
                            new_addlist(1,new_sayadd)=j;

                            imp_list(new_sayadd,1)=(-1)*is_neg*(2^the_power);
                            imp_list(new_sayadd,2)=exp_pos;
                            imp_list(new_sayadd,3)=(-1)*2^(us);
                            imp_list(new_sayadd,4)=add_list(1,i);

                            break
                        end
                    end
                end
            end
            
            if is_found
                break
            end
        end
    end
    
    if ~new_sayadd
        break
    else
        add_list=[];
        say_add=new_sayadd;
        
        for i=1:new_sayadd
            say_partial=say_partial+1;
            add_list(1,i)=say_partial;
            partial_imp(say_partial,:)=imp_list(i,:);
            partial_list(say_partial,:)=target_list(new_addlist(1,i)-i+1,:);
            
            say_target=say_target-1;
            target_list(new_addlist(1,i)-i+1,:)=[];
            target_stats(:,new_addlist(1,i)-i+1)=[];
            target_repcell(:,new_addlist(1,i)-i+1)=[];
        end
    end
end
