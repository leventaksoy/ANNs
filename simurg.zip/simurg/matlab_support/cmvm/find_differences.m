function [say_cell,say_diff_array,diff_cell,say_target_array,target_cell] = find_differences(rep_select,say_column,the_bitwidth,say_output,output_list,say_diff,diff_list,say_target,target_list,target_cost)

say_cell=1;
say_diff_array(say_cell,1)=0;
diff_cell{say_cell,1}=[];
say_target_array(say_cell,1)=say_output;
target_cell{say_cell,1}=output_list;

say_cell=say_cell+1;
say_diff_array(say_cell,1)=say_diff;
diff_cell{say_cell,1}=diff_list;
say_target_array(say_cell,1)=say_target;
target_cell{say_cell,1}=target_list;

while 1
    is_one_replaced=0;
    %checked_list=zeros(say_target,1);
    
    for j=1:say_target-1
        %if ~checked_list(j,1)
            say_subexp=0;
            subexp_list=[];
            min_cost=[target_cost(1,j)-2;target_cost(2,j)];

            the_target=target_list(j,:);

            for i=j+1:say_target
                the_partial=target_list(i,:);
                partial_cost=[target_cost(1,i);target_cost(2,i)];

                for us=0:1:the_bitwidth
                    the_exp=the_target-(2^us)*the_partial;

                    if is_exceeding_bitwith(say_column,the_bitwidth,the_exp)
                        break
                    else
                        [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                        [the_cost]=compute_cost_exp(rep_select,say_column,posodd_exp);

                        if the_cost(1,1)<min_cost(1,1)
                            say_subexp=0;
                            subexp_list=[];
                            min_cost=the_cost;
                            
                            say_subexp=say_subexp+1;
                            subexp_list(say_subexp,:)=posodd_exp;
                        elseif the_cost(1,1)==min_cost(1,1)
                            if the_cost(2,1)<min_cost(2,1)
                                say_subexp=0;
                                subexp_list=[];
                                min_cost=the_cost;
                                
                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                            elseif the_cost(2,1)==min_cost(2,1)
                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                            end
                        end
                    end
                end

                for us=0:1:the_bitwidth
                    the_exp=the_target+(2^us)*the_partial;

                    if is_exceeding_bitwith(say_column,the_bitwidth,the_exp)
                        break
                    else
                        [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                        [the_cost]=compute_cost_exp(rep_select,say_column,posodd_exp);

                        if the_cost(1,1)<min_cost(1,1)
                            say_subexp=0;
                            subexp_list=[];
                            min_cost=the_cost;
                            
                            say_subexp=say_subexp+1;
                            subexp_list(say_subexp,:)=posodd_exp;
                        elseif the_cost(1,1)==min_cost(1,1)
                            if the_cost(2,1)<min_cost(2,1)
                                say_subexp=0;
                                subexp_list=[];
                                min_cost=the_cost;
                                
                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                            elseif the_cost(2,1)==min_cost(2,1)
                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                            end
                        end
                    end
                end
            end
        
            if say_subexp
                is_one_replaced=1;
                say_diff=say_diff+1;
                diff_list(say_diff,:)=target_list(j,:);
                
                target_list(j,:)=subexp_list(1,:);

                target_cost(1,j)=min_cost(1,1);
                target_cost(2,j)=min_cost(2,1);
            end
        %end
    end
    
    if is_one_replaced
%         target_list
%         pause
        
        [say_target,target_list,target_cost]=sort_exp_cost(rep_select,say_column,say_target,target_list,target_cost);
        
        say_cell=say_cell+1;
        say_diff_array(say_cell,1)=say_diff;
        diff_cell{say_cell,1}=diff_list;
        say_target_array(say_cell,1)=say_target;
        target_cell{say_cell,1}=target_list;
        
%         target_list
%         pause
    else
        break
    end
end
