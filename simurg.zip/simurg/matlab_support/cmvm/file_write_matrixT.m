clear;

file_matrix=input('Enter the filename where the matrix is: ','s');

file_name='';
count_literal=1;
for i=1:length(file_matrix)
    if file_matrix(1,count_literal)~='.'
        file_name(1,count_literal)=file_matrix(1,count_literal);
        count_literal=count_literal+1;
    else
        break
    end
end

say_row=0;
say_column=0;

count_row=0;
the_matrix=[];

fid_matrix=fopen(file_matrix,'r');
while 1
    the_line=fgetl(fid_matrix);
    
    if the_line==-1
        break
    elseif and(the_line(1,1)=='.',the_line(1,2)=='e')
        break
    elseif and(the_line(1,1)=='.',the_line(1,2)=='r')
        say_row=str2num(char(the_line(1:1,3:length(the_line))));
    elseif and(the_line(1,1)=='.',the_line(1,2)=='c')
        say_column=str2num(char(the_line(1:1,3:length(the_line))));
    else
        count_row=count_row+1;
        the_matrix(count_row,:)=str2num(char(the_line));
    end
end
fclose(fid_matrix);

tr_matrix=transpose(the_matrix);
the_product=the_matrix*tr_matrix;

file_trmatrix=[file_name,'_tr'];
fid_trmatrix=fopen(file_trmatrix,'w');

fprintf(fid_trmatrix,'.r %d\n',say_row);
fprintf(fid_trmatrix,'.c %d\n',say_column);
for i=1:say_row
    for j=1:say_column
        fprintf(fid_trmatrix,'%d ',tr_matrix(i,j));
    end
    fprintf(fid_trmatrix,'\n');
end
fprintf(fid_trmatrix,'.e\n');
fclose(fid_trmatrix);
