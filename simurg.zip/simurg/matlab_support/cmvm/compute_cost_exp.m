function the_cost = compute_cost_exp(rep_select,say_column,the_exp)

the_cost=[];
array_total=0;
array_nonzero=0;

for i=1:say_column
    if the_exp(1,i)
        if not(rep_select)
            [say_ins,say_nonzero,the_rep]=workon_binary_representation(the_exp(1,i));
        else
            [say_ins,say_nonzero,the_rep]=workon_csd_representation(the_exp(1,i));
        end
        
        array_total=array_total+abs(the_exp(1,i));
        array_nonzero=array_nonzero+say_nonzero;
    end
end

the_cost=[array_nonzero;array_total];
