function mcm_high2low (file_result, bit_width)

x_bitwidth=str2num(bit_width);

%file_mcm=input('Enter the MCM file: ','s');
%arch_type=input('Enter the type of description (0: Multiplications 1: Shift-Adds) --> ');
%unsigned_signed=input('Enter the type of input (0: Unsigned 1: Signed) --> '); 
%x_bitwidth=input('Enter the bit-width of the input: ');

% for dave=1:10
%     if dave<10
%         file_mcm=['fir0',num2str(dave),'.result'];
%     else
%         file_mcm=['fir',num2str(dave),'.result'];
%     end

%The name of the output file and module name is generated.
dot_found=0;
slash_found=0;
file_name='';
module_name='';

for i=1:length(file_result)
    if file_result(1,i)=='.'
        dot_found=i;
        break
    end
    if or(file_result(1,i)== '/', file_result(1,i)== '\')
        slash_found=i;
    end
end

if dot_found
    file_name=file_result(1:1,1:i-1);
else
    dot_found = length(file_result)+1;
    file_name=file_result;
end

if slash_found
    module_name=file_result(1:1,slash_found+1:dot_found-1);
else
    module_name=file_result(1:1,1:dot_found-1);
end

[is_checked,say_list,say_array,say_partial,say_inv,say_oper,coef_list,coef_array,partial_list,inv_list,oper_line,oper_list]=file_read_ourmcm(file_result);

%file_write_sa_signed_vhdl(x_bitwidth,file_mcm,file_name,say_list,coef_list,say_oper,oper_line,oper_list);
file_write_sa_signed_verilog(x_bitwidth,file_result,module_name,file_name,say_list,coef_list,say_oper,oper_line,oper_list);        

function [is_checked,say_list,say_array,say_partial,say_inv,say_oper,coef_list,coef_array,partial_list,inv_list,oper_line,oper_list] = file_read_ourmcm(file_solution)

fid_solution=fopen(file_solution,'r');

while 1
    tline= fgetl(fid_solution);
    if or(strcmp(tline, '*** Implementation of Coefficients ***' ),strcmp(tline, '*** Implementation of Filter Coefficients ***' ))
        break
    end
end

say_list=0;
coef_list=[];

say_array=1;
coef_array=[1];

fgetl(fid_solution);

while 1
    tline=fgetl(fid_solution);
    
    if not(isempty(tline))
        the_initial=1;
        while tline(1,the_initial)~='='
            the_initial=the_initial+1;
        end

        the_coef=str2num(char(tline(1:1,1:the_initial-1)));
        [power,posodd_coef]=make_number_posodd(the_coef);
        
        if the_coef
            if not(is_inside(posodd_coef,say_array,coef_array))
                say_array=say_array+1;
                coef_array(1,say_array)=posodd_coef;
            end
            
            is_included=0;
            for i=1:say_list
                if the_coef==coef_list(1,i)*coef_list(2,i)
                    is_included=1;
                    break;
                end
            end
            
            if ~is_included
                say_list=say_list+1;
                
                coef_list(1,say_list)=abs(the_coef);
                if the_coef<0
                    coef_list(2,say_list)=-1;
                else
                    coef_list(2,say_list)=1;
                end
                coef_list(3,say_list)=posodd_coef;
                coef_list(4,say_list)=power;
            end
        end
    else
        break
    end
end

while 1
    tline= fgetl(fid_solution);
    if strcmp( tline, '*** Implementation of Partial Terms ***' )
        break
    end
end

is_checked=1;
first_line=1;
say_partial=1;
partial_list=[1];

say_inv=0;
say_oper=0;
inv_list=[];
oper_list=[];
oper_line=cell(1,1);

while 1
    inv_requested_one=0;
    inv_requested_two=0;
    
    the_line=fgetl(fid_solution);

    if and(strcmp(the_line, '')==1,first_line==0)
        break
    elseif the_line==-1
        break
    elseif and(strcmp(the_line, '')==1,first_line==1)
        the_line=fgetl(fid_solution);
        
        if strcmp(the_line, '')==1
            break
        end
    end
    
    first_line=0;

    the_start=1;
    the_initial=1;
    
    say_oper=say_oper+1;
    oper_line{say_oper,1}=the_line;

    while the_line(1,the_start)~='>'
        the_start=the_start+1;
    end
    
    the_coef=str2num(char(the_line(1:1,the_initial:the_start-1)));
    
    say_partial=say_partial+1;
    partial_list(1,say_partial)=the_coef;
    oper_list(say_oper,1)=the_coef;
    
    the_start=the_start+2;
    the_initial=the_start;
    
    while the_line(1,the_start)~='='
        the_start=the_start+1;
    end
    
    shift_coef=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,2)=shift_coef;
    
    the_start=the_start+2;
    
    if the_line(1,the_start)=='+'
        oper_list(say_oper,3)=1;
    elseif the_line(1,the_start)=='-'
        inv_requested_one=1;
        oper_list(say_oper,3)=-1;
    end
    
    the_start=the_start+1;
    the_initial=the_start;
    
    while the_line(1,the_start)~='<'
        the_start=the_start+1;
    end
    
    first_partial=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,4)=first_partial;
    
    the_start=the_start+2;
    the_initial=the_start;
    
    while and(the_line(1,the_start)~='+',the_line(1,the_start)~='-')
        the_start=the_start+1;
    end
    
    first_shift=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,5)=first_shift;
    
    if the_line(1,the_start)=='+'
        oper_list(say_oper,6)=1;
    elseif the_line(1,the_start)=='-'
        inv_requested_two=1;
        oper_list(say_oper,6)=-1;
    end
    
    the_start=the_start+1;
    the_initial=the_start;
    while the_line(1,the_start)~='<'
        the_start=the_start+1;
    end
    
    second_partial=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,7)=second_partial;
    
    the_start=the_start+2;
    second_shift=str2num(char(the_line(1:1,the_start:length(the_line))));
    oper_list(say_oper,8)=second_shift;
    
    if inv_requested_one
        if not(is_inside(oper_list(say_oper,4),say_inv,inv_list))
            say_inv=say_inv+1;
            inv_list(1,say_inv)=oper_list(say_oper,4);
        end
    else
        if inv_requested_two
            if not(is_inside(oper_list(say_oper,7),say_inv,inv_list))
                say_inv=say_inv+1;
                inv_list(1,say_inv)=oper_list(say_oper,7);
            end
        end
    end
    
    if oper_list(say_oper,1)*(2^oper_list(say_oper,2))~=oper_list(say_oper,3)*oper_list(say_oper,4)*(2^oper_list(say_oper,5))+oper_list(say_oper,6)*oper_list(say_oper,7)*(2^oper_list(say_oper,8))
        is_checked=0;
        fpritnf(' \n');
        fprintf('Error: The %d. operation computes a wrong number. Quiting... \n', say_oper);
        fpritnf(' \n');
        break
    end
end

fclose(fid_solution);

function [power,deger] = make_number_posodd(deger)

power=0;

if deger<0
    deger=(-1)*deger;
end

while 1
    if deger~=0
        if mod(deger,2)==0
            deger=deger/2;
            power=power+1;
        else
            return
        end
    else
        return
    end
end

function [value] = is_inside(aranan,yer_say,yer)

value=0;

if yer_say~=0
    for i=yer_say:-1:1
        if yer(1,i)==aranan
            value=1;
            return
        end
    end
end

function [] = file_write_sa_signed_vhdl(x_bitwidth,file_mcm,file_name,say_list,coef_list,say_oper,oper_line,oper_list)

file_sa=[file_name,'_sa.vhd'];
fid_sa=fopen(file_sa,'w');

fprintf(fid_sa,'-- Shift-Adds Description of MCM in VHDL \n');
saat=clock;
fprintf(fid_sa,'-- Date: %s Time: %d:%d:%.0f \n',date,saat(1,4),saat(1,5),saat(1,6));
fprintf(fid_sa,'-- MCM file: %s \n',file_mcm);
fprintf(fid_sa,'\n');
fprintf(fid_sa,'library IEEE; \n');
fprintf(fid_sa,'use IEEE.STD_LOGIC_1164.ALL; \n');
fprintf(fid_sa,'use ieee.numeric_std.all;\n');
fprintf(fid_sa,'\n');
fprintf(fid_sa,'entity %s_sa is \n',file_name);
fprintf(fid_sa,'\t port (x1 : in signed(%d downto 0); \n',x_bitwidth-1);
for i=1:say_list-1
    if coef_list(2,i)>0
        fprintf(fid_sa,'\t \t p%dx : out signed(%d downto 0); \n',coef_list(1,i),x_bitwidth+floor(log2(coef_list(1,i))));
    else
        fprintf(fid_sa,'\t \t m%dx : out signed(%d downto 0); \n',coef_list(1,i),x_bitwidth+floor(log2(abs(coef_list(1,i)))));
    end
end
if coef_list(2,say_list)>0
    fprintf(fid_sa,'\t \t p%dx : out signed(%d downto 0) \n',coef_list(1,say_list),x_bitwidth+floor(log2(coef_list(1,say_list))));
else
    fprintf(fid_sa,'\t \t m%dx : out signed(%d downto 0) \n',coef_list(1,say_list),x_bitwidth+floor(log2(abs(coef_list(1,say_list)))));
end
fprintf(fid_sa,'\t \t ); \n');
fprintf(fid_sa,'end %s_sa; \n',file_name);
fprintf(fid_sa,'\n');
fprintf(fid_sa,'architecture Behavioral of %s_sa is \n',file_name);
fprintf(fid_sa,'\n');
for i=1:say_oper
    fprintf(fid_sa,'signal x%d : signed(%d downto 0); \n',oper_list(i,1),x_bitwidth+floor(log2(oper_list(i,1))));
    if oper_list(i,2)
        fprintf(fid_sa,'signal x%ds%d : signed(%d downto 0); \n',oper_list(i,1),oper_list(i,2),oper_list(i,2)+x_bitwidth+floor(log2(oper_list(i,1))));
    end
end
fprintf(fid_sa,'\n');
fprintf(fid_sa,'begin \n');
for i=1:say_oper
    fprintf(fid_sa,'\n');
    fprintf(fid_sa,'-- %s \n',oper_line{i,1});
    fprintf(fid_sa,'\n');
    
    [the_oper]=conv_regular_oper(oper_list(i,:));
    write_signed_oper_vhdl(fid_sa,x_bitwidth,the_oper);
    
    if the_oper(1,2)
        fprintf(fid_sa,'x%d <= x%ds%d(%d downto %d); \n',the_oper(1,1),the_oper(1,1),the_oper(1,2),the_oper(1,2)+x_bitwidth+floor(log2(the_oper(1,1))),the_oper(1,2));
    end
end
fprintf(fid_sa,'\n');
for i=1:say_list
    if coef_list(2,i)>0
        fprintf(fid_sa,'p%dx <= x%d',coef_list(1,i),coef_list(3,i));
    else
        fprintf(fid_sa,'m%dx <= to_signed(to_integer(x%d)*(-1),%d)',coef_list(1,i),coef_list(3,i),x_bitwidth+floor(log2(coef_list(3,i)))+1);
    end
    
    if coef_list(4,i)
       fprintf(fid_sa,' & "');
       for j=1:coef_list(4,i)
           fprintf(fid_sa,'0');
       end
       fprintf(fid_sa,'";\n');
    else
        fprintf(fid_sa,';\n');
    end
end
fprintf(fid_sa,'\n');
fprintf(fid_sa,'end Behavioral; \n');
fprintf(fid_sa,'\n');
fclose(fid_sa);

function [] = file_write_sa_signed_verilog(x_bitwidth,file_mcm,module_name, file_name,say_list,coef_list,say_oper,oper_line,oper_list)

file_sa=[file_name,'.v'];
fid_sa=fopen(file_sa,'w');

%Info
fprintf(fid_sa,'// Shift-Adds Description of MCM in VHDL \n');
saat=clock;
fprintf(fid_sa,'// Date: %s Time: %d:%d:%.0f \n',date,saat(1,4),saat(1,5),saat(1,6));
fprintf(fid_sa,'// MCM file: %s \n',file_mcm);
fprintf(fid_sa,'\n');
%Module
fprintf(fid_sa, 'module %s (x1, ',module_name);
for i=1:say_list-1
    if coef_list(2,i)>0
        fprintf(fid_sa,'p%dx, ', coef_list(1,i));
    else
        fprintf(fid_sa,'m%dx, ', coef_list(1,i));
    end
end
if coef_list(2,say_list)>0
    fprintf(fid_sa,'p%dx); \n',coef_list(1,say_list));
else
    fprintf(fid_sa,'m%dx); \n',coef_list(1,say_list));
end
fprintf(fid_sa,'\n');
%Input
fprintf(fid_sa,'input signed [%d:0] x1; \n', x_bitwidth-1);
%Outputs
for i=1:say_list
    if coef_list(2,i)>0
        fprintf(fid_sa,'output signed [%d:0] p%dx; \n', x_bitwidth+floor(log2(coef_list(1,i))), coef_list(1,i));
    else
        fprintf(fid_sa,'output signed [%d:0] m%dx; \n', x_bitwidth+floor(log2(coef_list(1,i))), coef_list(1,i));
    end
end
fprintf(fid_sa,'\n');
%Wires
for i=1:say_oper
    fprintf(fid_sa,'wire signed [%d:0] x%d; \n', x_bitwidth+floor(log2(oper_list(i,1))), oper_list(i,1));
    if oper_list(i,2)
        fprintf(fid_sa,'wire signed [%0d:0] x%ds%d; \n', oper_list(i,2)+x_bitwidth+floor(log2(oper_list(i,1))), oper_list(i,1), oper_list(i,2));
    end
end
fprintf(fid_sa,'\n');
for i=1:say_oper
    fprintf(fid_sa,'// %s \n',oper_line{i,1});
    [the_oper]=conv_regular_oper(oper_list(i,:));
    %write_signed_oper_vhdl(fid_sa,x_bitwidth,the_oper);
    write_signed_oper_verilog(fid_sa,x_bitwidth,the_oper);
    
%     if the_oper(1,2)
%         fprintf(fid_sa,'x%d <= x%ds%d(%d downto %d); \n',the_oper(1,1),the_oper(1,1),the_oper(1,2),the_oper(1,2)+x_bitwidth+ceil(log2(the_oper(1,1)))-1,the_oper(1,2));
%     end
    if the_oper(1,2)
        fprintf(fid_sa,'assign x%d = x%ds%d[%d:%d]; \n',the_oper(1,1),the_oper(1,1),the_oper(1,2),the_oper(1,2)+x_bitwidth+floor(log2(the_oper(1,1))),the_oper(1,2));
    end
    fprintf(fid_sa,'\n');
end

% for i=1:say_list
%     if coef_list(2,i)>0
%         fprintf(fid_sa,'p%dx <= x%d',coef_list(1,i),coef_list(3,i));
%     else
%         fprintf(fid_sa,'m%dx <= to_signed(to_integer(x%d)*(-1),%d)',coef_list(1,i),coef_list(3,i),x_bitwidth+ceil(log2(coef_list(3,i)))+1);
%     end
%     
%     if coef_list(4,i)
%        fprintf(fid_sa,' & "');
%        for j=1:coef_list(4,i)
%            fprintf(fid_sa,'0');
%        end
%        fprintf(fid_sa,'";\n');
%     else
%         fprintf(fid_sa,';\n');
%     end
% end

for i=1:say_list
    if coef_list(2,i)>0
        fprintf(fid_sa,'assign p%dx = (x%d',coef_list(1,i),coef_list(3,i));
    else
        fprintf(fid_sa,'assign m%dx = -(x%d',coef_list(1,i),coef_list(3,i));
    end
    
    if coef_list(4,i)
       fprintf(fid_sa,'<<<%d); \n', coef_list(4,i));
       
    else
        fprintf(fid_sa,'); \n');
    end
end
fprintf(fid_sa,'\n');
fprintf(fid_sa,'endmodule \n');
fprintf(fid_sa,'\n');
fclose(fid_sa);

function [regular_oper] = conv_regular_oper(the_oper)

regular_oper=the_oper;

if the_oper(1,3)<0
    regular_oper(1,3)=the_oper(1,6);
    regular_oper(1,4)=the_oper(1,7);
    regular_oper(1,5)=the_oper(1,8);
    regular_oper(1,6)=the_oper(1,3);
    regular_oper(1,7)=the_oper(1,4);
    regular_oper(1,8)=the_oper(1,5);
end

function [] = write_signed_oper_vhdl(fid_sa,x_bitwidth,the_oper)

if ~the_oper(1,2)
    the_line=['x',num2str(the_oper(1,1)),' <= to_signed((to_integer(x'];
else
    the_line=['x',num2str(the_oper(1,1)),'s',num2str(the_oper(1,2)),' <= to_signed((to_integer(x'];
end

if the_oper(1,5)
    the_line=[the_line,num2str(the_oper(1,4)),' & "'];
    for j=1:the_oper(1,5)
        the_line=[the_line,num2str(0)];
    end
    the_line=[the_line,'") '];
else
    the_line=[the_line,num2str(the_oper(1,4)),') '];
end

if the_oper(1,6)>0
    the_line=[the_line,'+ to_integer(x'];
else
    the_line=[the_line,'- to_integer(x'];
end

if the_oper(1,8)
    the_line=[the_line,num2str(the_oper(1,7)),' & "'];
    for j=1:the_oper(1,8)
        the_line=[the_line,num2str(0)];
    end
    the_line=[the_line,'")),'];
else
    the_line=[the_line,num2str(the_oper(1,7)),')),'];
end

the_line=[the_line,num2str(the_oper(1,2)+x_bitwidth+ceil(log2(the_oper(1,1)))),');'];
fprintf(fid_sa,'%s \n',the_line);

function [] = write_signed_oper_verilog(fid_sa,x_bitwidth,the_oper)

if ~the_oper(1,2)
    the_line=['assign x',num2str(the_oper(1,1)),' = ((x'];
else
    the_line=['assign x',num2str(the_oper(1,1)),'s',num2str(the_oper(1,2)),' = ((x'];
end

% if ~the_oper(1,2)
%     the_line=['x',num2str(the_oper(1,1)),' <= to_signed((to_integer(x'];
% else
%     the_line=['x',num2str(the_oper(1,1)),'s',num2str(the_oper(1,2)),' <= to_signed((to_integer(x'];
% end

if the_oper(1,5)
    the_line=[the_line,num2str(the_oper(1,4)),'<<<',num2str(the_oper(1,5)),') '];
else
    the_line=[the_line,num2str(the_oper(1,4)),') '];
end

% if the_oper(1,5)
%     the_line=[the_line,num2str(the_oper(1,4)),' & "'];
%     for j=1:the_oper(1,5)
%         the_line=[the_line,num2str(0)];
%     end
%     the_line=[the_line,'") '];
% else
%     the_line=[the_line,num2str(the_oper(1,4)),') '];
% end

if the_oper(1,6)>0
    the_line=[the_line,'+ (x'];
else
    the_line=[the_line,'- (x'];
end

% if the_oper(1,6)>0
%     the_line=[the_line,'+ to_integer(x'];
% else
%     the_line=[the_line,'- to_integer(x'];
% end

if the_oper(1,8)
    the_line=[the_line,num2str(the_oper(1,7)),'<<<',num2str(the_oper(1,8)),'));'];
    
else
    the_line=[the_line,num2str(the_oper(1,7)),'));'];
end

% if the_oper(1,8)
%     the_line=[the_line,num2str(the_oper(1,7)),' & "'];
%     for j=1:the_oper(1,8)
%         the_line=[the_line,num2str(0)];
%     end
%     the_line=[the_line,'")),'];
% else
%     the_line=[the_line,num2str(the_oper(1,7)),')),'];
% end

%the_line=[the_line,num2str(the_oper(1,2)+x_bitwidth+ceil(log2(the_oper(1,1)))),');'];
fprintf(fid_sa,'%s \n',the_line);
