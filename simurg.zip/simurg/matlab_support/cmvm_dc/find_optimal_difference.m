function [say_imp,imp_list,imp_partial,imp_depth,say_target,target_list,target_cost,target_depth] = find_optimal_difference(rep_select,say_column,the_bitwidth,depth_limit,say_target,target_list,target_cost,target_depth)

say_imp=say_column;
imp_list=eye(say_column);
imp_depth=zeros(say_column,1);
imp_partial=zeros(say_column,4);

is_target_imp=1;
while is_target_imp
    say_deleted=0;
    is_target_imp=0;
    deleted_list=[];
    
    for i=say_target:-1:1
        is_found=0;
        the_target=target_list(i,:);
        
        for j=1:say_imp
            the_imp=imp_list(j,:);
            
            for us=0:1:the_bitwidth
                the_exp=the_target-(2^us)*the_imp;

                if is_exceeding_bitwidth(say_column,the_bitwidth,the_exp)
                    break
                else
                    [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                    the_pos=whereis_inside_array(posodd_exp,say_column,say_imp,imp_list);

                    if the_pos
                        if max(imp_depth(the_pos,1),imp_depth(j,1))+1<=depth_limit
                            is_found=1;
                            is_target_imp=1;
                            
                            say_imp=say_imp+1;
                            imp_list(say_imp,:)=the_target;
                            imp_depth(say_imp,1)=max(imp_depth(the_pos,1),imp_depth(j,1))+1;
                            imp_partial(say_imp,1)=2^us;
                            imp_partial(say_imp,2)=j;
                            imp_partial(say_imp,3)=is_neg*(-1)*2^the_power;
                            imp_partial(say_imp,4)=the_pos;

                            say_deleted=say_deleted+1;
                            deleted_list(1,say_deleted)=i;
                            break
                        end
                    end
                end
            end

            if ~is_found
                for us=0:1:the_bitwidth
                    the_exp=the_target+(2^us)*the_imp;

                    if is_exceeding_bitwidth(say_column,the_bitwidth,the_exp)
                        break
                    else
                        [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                        the_pos=whereis_inside_array(posodd_exp,say_column,say_imp,imp_list);

                        if the_pos
                            if max(imp_depth(the_pos,1),imp_depth(j,1))+1>=depth_limit
                                is_found=1;
                                is_target_imp=1;
                                
                                say_imp=say_imp+1;
                                imp_list(say_imp,:)=the_target;
                                imp_depth(say_imp,1)=max(imp_depth(the_pos,1),imp_depth(j,1))+1;
                                imp_partial(say_imp,1)=(-1)*2^us;
                                imp_partial(say_imp,2)=j;
                                imp_partial(say_imp,3)=is_neg*(-1)*2^the_power;
                                imp_partial(say_imp,4)=the_pos;

                                say_deleted=say_deleted+1;
                                deleted_list(1,say_deleted)=i;
                                break
                            end
                        end
                    end
                end
            end
            
            if is_found
                break
            end
        end
    end
    
    for i=1:say_deleted
        say_target=say_target-1;
        target_list(deleted_list(1,i),:)=[];
        target_cost(:,deleted_list(1,i))=[];
        target_depth(:,deleted_list(1,i))=[];
    end
end
