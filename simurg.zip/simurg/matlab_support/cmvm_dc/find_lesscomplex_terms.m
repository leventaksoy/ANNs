function [the_indis,the_value] = find_lesscomplex_terms(partial_bitwidth,say_target,target_list,the_min,say_min,min_list)

the_indis=[];
the_value=[];

final_cost=inf;

if say_min>2
    for i=1:1:say_min-1
        indis_one=min_list(1,i);
        size_one=log2(abs(target_list(1,indis_one)))+partial_bitwidth(target_list(2,indis_one),1);
        for j=i+1:1:say_min
            indis_two=min_list(1,j);
            size_two=log2(abs(target_list(1,indis_two)))+partial_bitwidth(target_list(2,indis_two),1);
            
            the_cost=0;
            if and(target_list(1,indis_one)<0,target_list(1,indis_two)>0)
                the_cost=the_cost+size(size_one)+max(size_one,size_two);
            elseif and(target_list(1,indis_one)<0,target_list(1,indis_two)>0)
                the_cost=the_cost+size(size_two)+max(size_one,size_two);
            else
                the_cost=the_cost+max(size_one,size_two);
            end
            
            if the_cost<final_cost
                the_indis=[indis_one indis_two];
                the_value=[the_min the_min];
                final_cost=the_cost;
            end
        end
    end
elseif say_min==2
    the_indis=min_list;
    the_value=[the_min the_min];
elseif say_min==1
    indis_one=min_list(1,1);
    size_one=log2(abs(target_list(1,indis_one)))+partial_bitwidth(target_list(2,indis_one),1);
    
    the_indis(1,1)=indis_one;
    the_value(1,1)=the_min;
    
    new_min=inf;
    new_say_min=0;
    new_min_list=[];
    for i=1:say_target
        if i~=indis_one
            if target_list(3,i)<new_min
                new_say_min=1;
                new_min_list=[i];
                new_min=target_list(3,i);
            elseif target_list(3,i)==new_min
                new_say_min=new_say_min+1;
                new_min_list(1,new_say_min)=i;
            end
        end
    end
    
    for j=1:1:new_say_min
        indis_two=new_min_list(1,j);
        size_two=log2(abs(target_list(1,indis_two)))+partial_bitwidth(target_list(2,indis_two),1);

        the_cost=0;
        if and(target_list(1,indis_one)<0,target_list(1,indis_two)>0)
            the_cost=the_cost+size(size_one)+max(size_one,size_two);
        elseif and(target_list(1,indis_one)<0,target_list(1,indis_two)>0)
            the_cost=the_cost+size(size_two)+max(size_one,size_two);
        else
            the_cost=the_cost+max(size_one,size_two);
        end

        if the_cost<final_cost
            the_indis(1,2)=indis_two;
            the_value(1,2)=new_min;
            final_cost=the_cost;
        end
    end
end
