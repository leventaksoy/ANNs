function [max_level] = file_write_expressions(fid_result,say_column,depth_limit,say_partial,say_output,partial_imp,partial_list,output_list)

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Expressions ***\n');
fprintf(fid_result,'\n');

max_level=0;
say_subexp=0;
subexp_list=zeros(say_partial,1);
level_partials=zeros(say_partial,1);

for i=say_column+1:say_partial
    output_pos=whereis_inside_array(partial_list(i,:),say_column,say_output,output_list);
    
    if output_pos
        subexp_list(i,1)=(-1)*output_pos;
        fprintf(fid_result,'O%d: ',output_pos);
    else
        say_subexp=say_subexp+1;
        subexp_list(i,1)=say_subexp;
        fprintf(fid_result,'S%d: ',say_subexp);
    end
    
    file_write_inputterms(fid_result,say_column,partial_list(i,:))
    
    if partial_imp(i,1)<0
        fprintf(fid_result,' = -');
    else
        fprintf(fid_result,' = +');
    end
    
    if subexp_list(partial_imp(i,2),1)<0
        fprintf(fid_result,'O%d<<%d ',abs(subexp_list(partial_imp(i,2),1)),log2(abs(partial_imp(i,1))));
    elseif subexp_list(partial_imp(i,2),1)>0
        fprintf(fid_result,'S%d<<%d ',abs(subexp_list(partial_imp(i,2),1)),log2(abs(partial_imp(i,1))));
    else
        fprintf(fid_result,'X%d<<%d ',partial_imp(i,2),log2(abs(partial_imp(i,1))));
    end
    
    if partial_imp(i,3)<0
        fprintf(fid_result,'-');
    else
        fprintf(fid_result,'+');
    end
    
    if subexp_list(partial_imp(i,4),1)<0
        fprintf(fid_result,'O%d<<%d\n',abs(subexp_list(partial_imp(i,4),1)),log2(abs(partial_imp(i,3))));
    elseif subexp_list(partial_imp(i,4),1)>0
        fprintf(fid_result,'S%d<<%d\n',abs(subexp_list(partial_imp(i,4),1)),log2(abs(partial_imp(i,3))));
    else
        fprintf(fid_result,'X%d<<%d\n',partial_imp(i,4),log2(abs(partial_imp(i,3))));
    end
    
    level_partials(i,1)=max(level_partials(partial_imp(i,2),1),level_partials(partial_imp(i,4),1))+1;
    
    if level_partials(i,1)>max_level
        max_level=level_partials(i,1);
    end
end

if max_level>depth_limit
    fprintf('There is a depth error here\n');
    pause
end

for i=1:say_output
    if ~is_inside_array(output_list(i,:),say_column,say_partial,partial_list)
        fprintf('%d. output is not realized\n');
        output_list
        pause
    end
end
