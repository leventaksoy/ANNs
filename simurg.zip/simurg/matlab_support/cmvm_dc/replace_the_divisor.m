function [target_stats,target_repcell] = replace_the_divisor(say_partial,the_divisor,the_index,the_depth,target_stats,target_repcell)

for h=1:length(the_index)
    say_nonzero=target_stats(1,the_index(1,h));
    the_rep=target_repcell{1,the_index(1,h)};
    the_rep(4,:)=zeros(1,say_nonzero);

    say_added=0;
    added_list=[];
    
    for i=1:say_nonzero-1
        if not(the_rep(4,i))
            if the_divisor(2,1)==the_rep(2,i)
                konum_indis=zeros(1,2);
                konum_indis(1,1)=i;

                carpan=the_rep(1,i)/the_divisor(1,1);

                mperfect_array=the_divisor;
                mperfect_array(1,:)=carpan*the_divisor(1,:);

                is_match=0;
                for k=i+1:1:say_nonzero
                    if mperfect_array(1,2)==the_rep(1,k)
                        if mperfect_array(2,2)==the_rep(2,k)
                            is_match=1;
                            konum_indis(1,2)=k;
                            break
                        end
                    end
                end

                if is_match
                    for j=1:2
                        the_rep(4,konum_indis(1,j))=1;
                    end

                    say_added=say_added+1;
                    added_list(1,say_added)=carpan;
                end

            end
        end
    end

    new_saynonzero=0;
    new_therep=[];

    for i=1:say_nonzero
        if not(the_rep(4,i))
            new_saynonzero=new_saynonzero+1;
            new_therep(1,new_saynonzero)=the_rep(1,i);
            new_therep(2,new_saynonzero)=the_rep(2,i);
            new_therep(3,new_saynonzero)=the_rep(3,i);
        end
    end

    for i=1:say_added
        new_saynonzero=new_saynonzero+1;
        new_therep(1,new_saynonzero)=added_list(1,i);
        new_therep(2,new_saynonzero)=say_partial;
        new_therep(3,new_saynonzero)=the_depth;
    end

    target_stats(1,the_index(1,h))=new_saynonzero;
    target_repcell{1,the_index(1,h)}=new_therep;
end
