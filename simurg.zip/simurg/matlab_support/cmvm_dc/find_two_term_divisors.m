function [max_freq,say_max_freq,max_freq_cell] = find_two_term_divisors(say_column,say_target,partial_list,target_depth,target_stats,target_repcell)

say_divisors=0;
divisors_list=[];

max_freq=1;
say_max_freq=0;
max_freq_cell=cell(2,1);

for i=1:say_target
    the_depth=target_depth(2,i);
    the_terms=target_repcell{1,i};
    
    for j=1:target_stats(1,i)-1
        for k=j+1:1:target_stats(1,i)
            the_divisor(:,1)=the_terms(:,j);
            the_divisor(:,2)=the_terms(:,k);
            
            divisor_array=divisor2array(say_column,the_divisor,partial_list);
            [is_neg,power,posodd_divisor_array]=make_array_posodd(say_column,divisor_array);

            if not(is_inside_array(posodd_divisor_array,say_column,say_divisors,divisors_list))
                say_divisors=say_divisors+1;
                divisors_list(say_divisors,:)=posodd_divisor_array;

                posodd_divisor(1,:)=(-1)*is_neg*the_divisor(1,:)/(2^power);
                posodd_divisor(2,:)=the_divisor(2,:);
                posodd_divisor(3,:)=the_divisor(3,:);

                [the_freq,divisor_index,target_index]=find_frequency(posodd_divisor,say_target,target_depth,target_stats,target_repcell);

                if max_freq<the_freq
                    max_freq=the_freq;

                    say_max_freq=1;
                    max_freq_cell=cell(2,1);
                    max_freq_cell{1,1}=posodd_divisor;
                    max_freq_cell{2,1}=divisor_index;
                    max_freq_cell{3,1}=target_index;
                elseif and(max_freq==the_freq,max_freq>1)
                    say_max_freq=say_max_freq+1;
                    max_freq_cell{1,say_max_freq}=posodd_divisor;
                    max_freq_cell{2,say_max_freq}=divisor_index;
                    max_freq_cell{3,say_max_freq}=target_index;
                end
            end

        end
    end
    
end
