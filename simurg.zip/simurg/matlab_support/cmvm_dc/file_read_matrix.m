function [say_column,the_bitwidth,say_primary,primary_list,say_target,target_list,target_cost,min_depth,target_depth] = file_read_matrix(fid_result,file_matrix,rep_select)

the_bitwidth=0;

say_allo=0;
say_output=0;
output_list=[];

say_primary=0;
primary_list=[];
primary_indis=[];

min_depth=0;
target_depth=[];

fprintf(fid_result,'* Shift-Adds Implementation of Constant Coefficient Matrix Multiplications\n');
saat=clock;
fprintf(fid_result,'* Date: %s Time: %d:%d:%.0f \n',date,saat(1,4),saat(1,5),saat(1,6));
fprintf(fid_result,'* Matrix File: %s\n',file_matrix);

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Primary Expressions ***\n');
fprintf(fid_result,'\n');

fid_mat=fopen(file_matrix,'r');

while 1
    the_line=fgetl(fid_mat);
    
    if the_line==-1
        break
    elseif the_line(1,1)=='.'
        if the_line(1,2)=='e'
            break
        elseif the_line(1,2)=='r'
            say_row=str2num(char(the_line(1:1,3:length(the_line))));
        elseif the_line(1,2)=='c'
            say_column=str2num(char(the_line(1:1,3:length(the_line))));
            input_list=eye(say_column);
        end
    else
        the_row=str2num(char(the_line));
        [is_neg,power,posodd_row]=make_array_posodd(say_column,the_row);
        
        konum=whereis_inside_array(posodd_row,say_column,say_column,input_list);
        if konum
            say_allo=say_allo+1;
            fprintf(fid_result,'P%d: ',say_allo);
            file_write_inputterms(fid_result,say_column,the_row);
            if is_neg==1
                fprintf(fid_result,' = -');
            else
                fprintf(fid_result,' = +');
            end
            file_write_inputterms(fid_result,say_column,posodd_row);
            fprintf(fid_result,'<<%d = ',power);
            if is_neg==1
                fprintf(fid_result,'-X%d<<%d\n',konum,power);
            else
                fprintf(fid_result,'+X%d<<%d\n',konum,power);
            end
        else
            if is_neg
                [konum]=whereis_inside_array(posodd_row,say_column,say_primary,primary_list);
                if ~konum
                    array_total=0;
                    array_nonzero=0;

                    for i=1:say_column
                        if posodd_row(1,i)
                            if not(rep_select)
                                [say_ins,say_nonzero,the_rep]=workon_binary_representation(posodd_row(1,i));
                            else
                                [say_ins,say_nonzero,the_rep]=workon_csd_representation(posodd_row(1,i));
                            end

                            array_total=array_total+abs(posodd_row(1,i));
                            array_nonzero=array_nonzero+say_nonzero;

                            if ceil(log2(abs(posodd_row(1,i))))>the_bitwidth
                                the_bitwidth=ceil(log2(abs(posodd_row(1,i))));
                            end
                        end
                    end

                    if ceil(log2(array_nonzero))>min_depth
                        min_depth=ceil(log2(array_nonzero));
                    end

                    its_index=0;
                    say_greater=0;
                    for i=1:say_primary
                        if array_nonzero>primary_indis(1,i)
                            say_greater=say_greater+1;
                            primary_indis(3,i)=primary_indis(3,i)+1;
                        elseif array_nonzero==primary_indis(1,i)
                            if array_total>=primary_indis(2,i)
                                say_greater=say_greater+1;
                                primary_indis(3,i)=primary_indis(3,i)+1;
                            end
                        end
                    end

                    its_index=say_primary-say_greater+1;

                    say_primary=say_primary+1;
                    primary_list(say_primary,:)=posodd_row;
                    primary_indis(1,say_primary)=array_nonzero;
                    primary_indis(2,say_primary)=array_total;
                    primary_indis(3,say_primary)=its_index;

                    konum=say_primary;
                end
                
                say_allo=say_allo+1;
                fprintf(fid_result,'P%d: ',say_allo);
                file_write_inputterms(fid_result,say_column,the_row);
                if is_neg==1
                    fprintf(fid_result,' = -');
                else
                    fprintf(fid_result,' = +');
                end
                file_write_inputterms(fid_result,say_column,posodd_row);
                fprintf(fid_result,'<<%d = ',power);
                if is_neg==1
                    fprintf(fid_result,'-O%d<<%d\n',konum,power);
                else
                    fprintf(fid_result,'+O%d<<%d\n',konum,power);
                end
            end
        end
    end
end

say_target=say_primary;
target_list=zeros(say_target,say_column);
target_cost=zeros(2,say_target);

for i=1:say_primary
    target_list(primary_indis(3,i),:)=primary_list(i,:);
    target_cost(:,primary_indis(3,i))=primary_indis(1:2,i:i);
    target_depth(1,primary_indis(3,i))=ceil(log2(primary_indis(1,i)));
end

fclose(fid_mat);
