function [the_signal] = isthere_depth_violation(say_value,target_indis,depth_limit,say_terms,the_terms)

the_signal=0;

new_terms=[];
say_newterms=0;

for i=1:say_value
    the_depth=max(the_terms(3,target_indis(1,3*i-1)),the_terms(3,target_indis(1,3*i)))+1;
    
    say_newterms=say_newterms+1;
    new_terms(1,say_newterms)=the_depth;
    
    the_terms(4,target_indis(1,3*i-1))=1;
    the_terms(4,target_indis(1,3*i))=1;
end

for i=1:say_terms
    if ~the_terms(4,i)
        say_newterms=say_newterms+1;
        new_terms(1,say_newterms)=the_terms(3,i);
    end
end

if say_newterms==1
    if new_terms(1,1)>depth_limit
        the_signal=1;
        return
    end
else
    if find_mindepth(say_newterms,new_terms)>depth_limit
        the_signal=1;
        return
    end
end
