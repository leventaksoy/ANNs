function [the_min,say_min,min_list] = find_minimum_indis(say_target,target_list)

say_min=0;
min_list=[];
the_min=inf;

for i=1:say_target
    if target_list(3,i)<the_min
        say_min=1;
        min_list=[i];
        the_min=target_list(3,i);
    elseif target_list(3,i)==the_min
        say_min=say_min+1;
        min_list(1,say_min)=i;
    end
end
