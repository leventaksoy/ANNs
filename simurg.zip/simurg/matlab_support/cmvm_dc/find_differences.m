function [say_cell,say_diff_array,diff_cell,diff_depth_cell,say_target_array,target_cell,target_depth_cell] = find_differences(rep_select,say_column,the_bitwidth,depth_limit,say_output,output_list,say_target,target_list,target_cost,target_depth)

say_diff=0;
diff_list=[];
diff_depth=[];

say_cell=1;

diff_cell{say_cell,1}=diff_list;
say_diff_array(say_cell,1)=say_diff;
diff_depth_cell{say_cell,1}=diff_depth;

target_cell{say_cell,1}=target_list;
say_target_array(say_cell,1)=say_target;
target_depth_cell{say_cell,1}=target_depth;

is_one_replaced=1;
while is_one_replaced
    is_one_replaced=0;
    
    for j=1:say_target-1
        say_subexp=0;
        subexp_list=[];
        subexp_depth=[];
        subexp_pindis=[];
        min_cost=[target_cost(1,j)-2;target_cost(2,j)];

        the_target=target_list(j,:);
        mintarget_depth=target_depth(1,j);

        for i=j+1:say_target
            the_partial=target_list(i,:);
            minpartial_depth=target_depth(1,i);
            partial_cost=[target_cost(1,i);target_cost(2,i)];

            for us=0:1:the_bitwidth
                the_exp=the_target-(2^us)*the_partial;

                if is_exceeding_bitwidth(say_column,the_bitwidth,the_exp)
                    break
                else
                    [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                    [the_cost,exp_depth]=compute_cost_exp(rep_select,say_column,posodd_exp);

                    output_depth=max(exp_depth,minpartial_depth)+1;
                    if and(output_depth<=depth_limit,output_depth<=target_depth(2,j))
                        if the_cost(1,1)<min_cost(1,1)
                            say_subexp=0;
                            subexp_list=[];
                            min_cost=the_cost;

                            say_subexp=say_subexp+1;
                            subexp_list(say_subexp,:)=posodd_exp;
                            subexp_pindis(say_subexp,1)=i;
                            subexp_depth(say_subexp,1)=exp_depth;
                        elseif the_cost(1,1)==min_cost(1,1)
                            if the_cost(2,1)<min_cost(2,1)
                                say_subexp=0;
                                subexp_list=[];
                                min_cost=the_cost;

                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                                subexp_pindis(say_subexp,1)=i;
                                subexp_depth(say_subexp,1)=exp_depth;
                            elseif the_cost(2,1)==min_cost(2,1)
                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                                subexp_pindis(say_subexp,1)=i;
                                subexp_depth(say_subexp,1)=exp_depth;
                            end
                        end
                    end
                end
            end

            for us=0:1:the_bitwidth
                the_exp=the_target+(2^us)*the_partial;

                if is_exceeding_bitwidth(say_column,the_bitwidth,the_exp)
                    break
                else
                    [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                    [the_cost,exp_depth]=compute_cost_exp(rep_select,say_column,posodd_exp);
                    
                    output_depth=max(exp_depth,minpartial_depth)+1;
                    if and(output_depth<=depth_limit,output_depth<=target_depth(2,j))
                        if the_cost(1,1)<min_cost(1,1)
                            say_subexp=0;
                            subexp_list=[];
                            min_cost=the_cost;

                            say_subexp=say_subexp+1;
                            subexp_list(say_subexp,:)=posodd_exp;
                            subexp_pindis(say_subexp,1)=i;
                            subexp_depth(say_subexp,1)=exp_depth;
                        elseif the_cost(1,1)==min_cost(1,1)
                            if the_cost(2,1)<min_cost(2,1)
                                say_subexp=0;
                                subexp_list=[];
                                min_cost=the_cost;

                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                                subexp_pindis(say_subexp,1)=i;
                                subexp_depth(say_subexp,1)=exp_depth;
                            elseif the_cost(2,1)==min_cost(2,1)
                                say_subexp=say_subexp+1;
                                subexp_list(say_subexp,:)=posodd_exp;
                                subexp_pindis(say_subexp,1)=i;
                                subexp_depth(say_subexp,1)=exp_depth;
                            end
                        end
                    end
                    
                end
            end
        end

        if say_subexp
            is_one_replaced=1;
            
            say_diff=say_diff+1;
            diff_list(say_diff,:)=target_list(j,:);
            diff_depth(say_diff,1)=target_depth(2,j);

            target_list(j,:)=subexp_list(1,:);

            target_cost(1,j)=min_cost(1,1);
            target_cost(2,j)=min_cost(2,1);

            target_depth(1,j)=subexp_depth(1,1);
            target_depth(2,j)=target_depth(2,j)-1;
            
            if target_depth(2,subexp_pindis(1,1))>target_depth(2,j)
                target_depth(2,subexp_pindis(1,1))=target_depth(2,j);
            end
        end
    end
    
    if is_one_replaced
        [say_target,target_list,target_cost,target_depth]=sort_exp_cost(rep_select,say_column,say_target,target_list,target_cost,target_depth);
        
        say_cell=say_cell+1;
        
        diff_cell{say_cell,1}=diff_list;
        say_diff_array(say_cell,1)=say_diff;
        diff_depth_cell{say_cell,1}=diff_depth;
        
        target_cell{say_cell,1}=target_list;
        say_target_array(say_cell,1)=say_target;
        target_depth_cell{say_cell,1}=target_depth;
    end
end
