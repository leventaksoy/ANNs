function [say_partial,partial_list,partial_imp,partial_depth] = maxo_minc(rep_select,say_column,say_partial,partial_list,partial_imp,partial_depth,say_target,target_list,target_depth,target_stats,target_repcell)

while 1
    [max_freq,say_max_freq,max_freq_cell]=find_two_term_divisors(say_column,say_target,partial_list,target_depth,target_stats,target_repcell);
    
    if max_freq==1
        break
    else
        [chosen_divisor,the_index]=find_min_conflict_divisor(say_max_freq,max_freq_cell);
        divisor_array=divisor2array(say_column,chosen_divisor,partial_list);
        
        [konum]=whereis_inside_array(divisor_array,say_column,say_partial,partial_list);
        if ~konum
            say_partial=say_partial+1;
            partial_list(say_partial,:)=divisor_array;
            partial_imp(say_partial,1)=chosen_divisor(1,1);
            partial_imp(say_partial,2)=chosen_divisor(2,1);
            partial_imp(say_partial,3)=chosen_divisor(1,2);
            partial_imp(say_partial,4)=chosen_divisor(2,2);

            depth_one=partial_depth(chosen_divisor(2,1),1);
            depth_two=partial_depth(chosen_divisor(2,2),1);
            the_depth=max(depth_one,depth_two)+1;
            partial_depth(say_partial,1)=the_depth;
        else
            the_depth=partial_depth(konum,1);
        end
        
        [target_stats,target_repcell]=replace_the_divisor(say_partial,chosen_divisor,the_index,the_depth,target_stats,target_repcell);
    end
end

x_bitwidth=16;
partial_bitwidth(1:say_column,1:1)=x_bitwidth;
for i=say_column+1:1:say_partial
    absmag_total=0;
    for j=1:say_column
        absmag_total=absmag_total+abs(partial_list(i,j));
    end
    partial_bitwidth(i,1)=ceil(log2(absmag_total))+x_bitwidth;
end

for i=1:say_target
    the_rep=target_repcell{1,i};

    while target_stats(1,i)~=1
        if target_stats(1,i)>2
            [the_min,say_min,min_list]=find_minimum_indis(target_stats(1,i),the_rep);
            [the_indis,the_value]=find_lesscomplex_terms(partial_bitwidth,target_stats(1,i),the_rep,the_min,say_min,min_list);
        else
            the_indis=[1 2];
            the_value=[the_rep(3,1),the_rep(3,2)];
        end
        
        the_divisor(:,1)=the_rep(:,the_indis(1,1));
        the_divisor(:,2)=the_rep(:,the_indis(1,2));
        divisor_depth=max(the_value(1,1),the_value(1,2))+1;

        divisor_array=divisor2array(say_column,the_divisor,partial_list);
        [is_neg,power,posodd_divisor_array]=make_array_posodd(say_column,divisor_array);
        the_divisor(1,:)=(-1)*is_neg*the_divisor(1,:)/(2^power);

        say_partial=say_partial+1;
        partial_list(say_partial,:)=posodd_divisor_array;
        partial_imp(say_partial,1)=the_divisor(1,1);
        partial_imp(say_partial,2)=the_divisor(2,1);
        partial_imp(say_partial,3)=the_divisor(1,2);
        partial_imp(say_partial,4)=the_divisor(2,2);
        partial_depth(say_partial,1)=divisor_depth;
        
        absmag_total=0;
        for j=1:say_column
            absmag_total=absmag_total+abs(posodd_divisor_array(1,j));
        end
        partial_bitwidth(say_partial,1)=ceil(log2(absmag_total))+x_bitwidth;

        if the_indis(1,1)>the_indis(1,2)
            max_indis=the_indis(1,1);
            min_indis=the_indis(1,2);
        else
            max_indis=the_indis(1,2);
            min_indis=the_indis(1,1);
        end

        the_rep(:,max_indis)=[];
        target_stats(1,i)=target_stats(1,i)-1;
        the_rep(1,min_indis)=is_neg*(-1)*(2^power);
        the_rep(2,min_indis)=say_partial;
        the_rep(3,min_indis)=divisor_depth;
    end
end
