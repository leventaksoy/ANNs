function [min_depth] = find_mindepth(say_terms,the_terms)

min_depth=0;

while say_terms>1
    the_double=[];
    the_double(1,1)=the_terms(1,1);
    the_double(1,2)=the_terms(1,2);
    
    double_indis=[];
    double_indis=[1 2];
    
    if the_double(1,1)>the_double(1,2)
        max_indis=1;
        max_value=the_double(1,1);
    else
        max_indis=2;
        max_value=the_double(1,2);
    end
    
    for i=3:1:say_terms
        if the_terms(1,i)<max_value
            double_indis(1,max_indis)=i;
            the_double(1,max_indis)=the_terms(1,i);
            
            if the_double(1,1)>the_double(1,2)
                max_indis=1;
                max_value=the_double(1,1);
            else
                max_indis=2;
                max_value=the_double(1,2);
            end
        end
    end
    
    the_depth=max(the_double(1,1),the_double(1,2))+1;
    
    if double_indis(1,1)>double_indis(1,2)
        max_indis=double_indis(1,1);
        min_indis=double_indis(1,2);
    else
        max_indis=double_indis(1,2);
        min_indis=double_indis(1,1);
    end
    
    say_terms=say_terms-1;
    the_terms(:,max_indis)=[];
    the_terms(:,min_indis)=the_depth;
end

min_depth=the_terms(1,1);
