function [say_partial,partial_list,partial_imp,partial_depth] = find_diff_implementations(say_column,the_bitwidth,say_diff,diff_list,diff_depth,say_partial,partial_list,partial_imp,partial_depth)

for i=say_diff:-1:1
    is_found=0;
    the_diff=diff_list(i,:);
    depth_limit=diff_depth(i,1);
    
    for j=say_partial:-1:1
        the_partial=partial_list(j,:);
        depth_one=partial_depth(j,1);
        
        for us=0:1:the_bitwidth
            the_exp=the_diff-(2^us)*the_partial;
            
            if is_exceeding_bitwidth(say_column,the_bitwidth,the_exp)
                break
            else
                [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                the_pos=whereis_inside_array(posodd_exp,say_column,say_partial,partial_list);
                
                if the_pos
                    depth_two=partial_depth(the_pos,1);
                    output_depth=max(depth_one,depth_two)+1;
                    
                    if output_depth<=depth_limit
                        is_found=1;
                        
                        say_partial=say_partial+1;
                        partial_list(say_partial,:)=the_diff;
                        partial_imp(say_partial,1)=2^us;
                        partial_imp(say_partial,2)=j;
                        partial_imp(say_partial,3)=(-1)*is_neg*(2^the_power);
                        partial_imp(say_partial,4)=the_pos;
                        partial_depth(say_partial,1)=output_depth;
                        break
                    end
                end
            end
        end
        
        if ~is_found
            for us=0:1:the_bitwidth
                the_exp=the_diff+(2^us)*the_partial;

                if is_exceeding_bitwidth(say_column,the_bitwidth,the_exp)
                    break
                else
                    [is_neg,the_power,posodd_exp]=make_array_posodd(say_column,the_exp);
                    the_pos=whereis_inside_array(posodd_exp,say_column,say_partial,partial_list);

                    if the_pos
                        depth_two=partial_depth(the_pos,1);
                        output_depth=max(depth_one,depth_two)+1;
                        
                        if output_depth<=depth_limit
                            is_found=1;

                            say_partial=say_partial+1;
                            partial_list(say_partial,:)=the_diff;
                            partial_imp(say_partial,1)=(-1)*(2^us);
                            partial_imp(say_partial,2)=j;
                            partial_imp(say_partial,3)=(-1)*is_neg*(2^the_power);
                            partial_imp(say_partial,4)=the_pos;
                            partial_depth(say_partial,1)=output_depth;
                            break
                        end
                    end
                end
            end
        end
        
        if is_found
            break
        end
    end
    
    if ~is_found
        fprintf('* %d. difference is not synthesized!!! \n',i)
        diff_list
        pause
    end
end
