function cmvm_dc_algo (file_matrix, rep_select)

%file_matrix=input('Enter the filename where the matrix coefficients exist: ','s');
%rep_select=input('Choose the type of number representation (0:binary, 1:CSD): ');

initial_cpu=cputime;

bosluk=str2mat(['	']);
rep_select = str2num(rep_select);

file_name='';
count_literal=1;
for i=1:length(file_matrix)
    if file_matrix(1,count_literal)~='.'
        file_name(1,count_literal)=file_matrix(1,count_literal);
        count_literal=count_literal+1;
    else
        break
    end
end

file_result=[file_name,'.result'];
fid_result=fopen(file_result,'w');

[say_column,the_bitwidth,say_output,output_list,say_target,target_list,target_cost,min_depth,target_depth]=file_read_matrix(fid_result,file_matrix,rep_select);
depth_limit=min_depth;

%fprintf('\n');
%fprintf('The minimum number of adder-steps: %d\n',min_depth);
%depth_limit=input('Enter the delay constraint: ');

for i=1:say_target
    target_depth(2,i)=depth_limit;
end

[say_partial,partial_list,partial_imp,partial_depth,say_target,target_list,target_cost,target_depth]=find_optimal_difference(rep_select,say_column,the_bitwidth,depth_limit,say_target,target_list,target_cost,target_depth);

if say_target
    min_sol=inf;
    [say_cell,say_diff,diff_cell,diff_depth_cell,say_target,target_cell,target_depth_cell]=find_differences(rep_select,say_column,the_bitwidth,depth_limit,say_output,output_list,say_target,target_list,target_cost,target_depth);
    
    for i=1:say_cell
        if ~say_target(i,1)
            if say_diff(i,1)+say_partial-say_column<min_sol
                min_sol=say_diff(1,i)+say_partial-say_column;
                
                the_say_partial=say_partial;
                the_partial_imp=partial_imp;
                the_partial_list=partial_list;
                the_partial_depth=partial_depth;
                
                the_say_diff=say_diff(i,1);
                the_diff_list=diff_cell{i,1};
                the_diff_depth=diff_depth_cell{i,1};
            end
        else
            [target_stats,target_repcell]=determine_representation(rep_select,say_column,say_target(i,1),target_cell{i,1});
            [new_say_partial,new_partial_list,new_partial_imp,new_partial_depth]=maxo_minc(rep_select,say_column,say_partial,partial_list,partial_imp,partial_depth,say_target(i,1),target_cell{i,1},target_depth_cell{i,1},target_stats,target_repcell);

            if new_say_partial+say_diff(i,1)-say_column<min_sol
                min_sol=new_say_partial+say_diff(i,1)-say_column;
                
                the_say_partial=new_say_partial;
                the_partial_list=new_partial_list;
                the_partial_imp=new_partial_imp;
                the_partial_depth=new_partial_depth;
                
                the_say_diff=say_diff(i,1);
                the_diff_list=diff_cell{i,1};
                the_diff_depth=diff_depth_cell{i,1};
            end
        end
    end
    
    if the_say_diff
        [say_partial,partial_list,partial_imp,partial_depth]=find_diff_implementations(say_column,the_bitwidth,the_say_diff,the_diff_list,the_diff_depth,the_say_partial,the_partial_list,the_partial_imp,the_partial_depth);
    else
        say_partial=the_say_partial;
        partial_list=the_partial_list;
        partial_imp=the_partial_imp;
        partial_depth=the_partial_depth;
    end
end

[max_level]=file_write_expressions(fid_result,say_column,depth_limit,say_partial,say_output,partial_imp,partial_list,output_list);

last_cpu=cputime-initial_cpu;

fprintf(fid_result,'\n');
fprintf(fid_result,'* Number of operations: %d\n',say_partial-say_column);
fprintf(fid_result,'* Number of adder-steps: %d\n',max_level);
fprintf(fid_result,'* CPU time: %.1f\n',last_cpu);
fprintf(fid_result,'\n');

fclose(fid_result);

fprintf('[INFO] A solution with %d adders in %d adder-step is found in %1.f seconds for the %s matrix multiplication!\n',say_partial-say_column, max_level, last_cpu, file_matrix);

end