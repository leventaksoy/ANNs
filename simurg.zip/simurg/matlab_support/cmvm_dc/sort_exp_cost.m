function [say_primary,primary_list,primary_cost,primary_depth] = sort_exp_cost(rep_select,say_column,say_target,target_list,target_cost,target_depth)

the_say_target=0;
the_target_list=[];
the_target_cost=[];
the_target_depth=[];

for i=1:say_target
    if target_cost(1,i)>1
        if ~is_inside_array(target_list(i,:),say_column,the_say_target,the_target_list)
            the_say_target=the_say_target+1;
            the_target_list(the_say_target,:)=target_list(i,:);
            the_target_cost(1:2,the_say_target)=[target_cost(1,i);target_cost(2,i)];
            the_target_cost(3,the_say_target)=0;
            the_target_depth(:,the_say_target)=target_depth(:,i);
        end
    end
end

the_target_cost(3,1)=1;

for i=2:1:the_say_target
    say_greater=0;
    
    for j=1:i-1
        if the_target_cost(1,i)>the_target_cost(1,j)
            say_greater=say_greater+1;
            the_target_cost(3,j)=the_target_cost(3,j)+1;
        elseif the_target_cost(1,i)==the_target_cost(1,j)
            if the_target_cost(2,i)>=the_target_cost(2,j)
                say_greater=say_greater+1;
                the_target_cost(3,j)=the_target_cost(3,j)+1;
            end
        end
    end
    the_target_cost(3,i)=i-say_greater;
end

say_primary=0;
primary_list=[];
primary_cost=[];

for i=1:the_say_target
    say_primary=say_primary+1;
    primary_list(the_target_cost(3,i),:)=the_target_list(i,:);
    primary_cost(1:2,the_target_cost(3,i))=[the_target_cost(1,i);the_target_cost(2,i)];
    primary_depth(:,the_target_cost(3,i))=the_target_depth(:,i);
end
