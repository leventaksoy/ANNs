function [say_imp,imp_list,say_unimp,unimp_list,int_constants] = mcm_find_int_constants(max_limit,say_added,added_list,int_constants,say_imp,imp_list,say_unimp,unimp_list)

up_value=2^(max_limit+1)-1;

while 1
    for i=1:say_added
        for j=1:say_imp
            
            for us=1:max_limit+1
                the_partial=added_list(1,i)+imp_list(1,j)*2^us;
                
                if the_partial<=up_value
                    int_constants(1,(the_partial+1)/2)=1;
                else
                    break
                end
            end
            
            for us=1:max_limit+1
                the_partial=added_list(1,i)*2^us+imp_list(1,j);
                
                if the_partial<=up_value
                    int_constants(1,(the_partial+1)/2)=1;
                else
                    break
                end
            end
            
            for us=1:max_limit+1
                the_partial=-added_list(1,i)+imp_list(1,j)*2^us;
                
                if the_partial<0
                    the_partial=(-1)*the_partial;
                end
                
                if the_partial<=up_value
                    int_constants(1,(the_partial+1)/2)=1;
                else
                    break
                end
            end
            
            for us=1:max_limit+1
                the_partial=added_list(1,i)*2^us-imp_list(1,j);
                
                if the_partial<0
                    the_partial=(-1)*the_partial;
                end
                
                if the_partial<=up_value
                    int_constants(1,(the_partial+1)/2)=1;
                else
                    break
                end
            end
        end
        
        for us=1:max_limit+1
            the_partial=added_list(1,i)+added_list(1,i)*2^us;
            
            if the_partial<=up_value
                int_constants(1,(the_partial+1)/2)=1;
            else
                break
            end
        end
        
        for us=1:max_limit+1
            the_partial=-added_list(1,i)+added_list(1,i)*2^us;
            
            if the_partial<=up_value
                int_constants(1,(the_partial+1)/2)=1;
            else
                break
            end
        end
        
        say_imp=say_imp+1;
        imp_list(1,say_imp)=added_list(1,i);
    end
    
    say_newadded=0;
    newadded_list=[];
    
    say_delete=0;
    delete_list=[];
    
    for i=1:say_unimp
        if int_constants(1,(unimp_list(1,i)+1)/2)
            say_delete=say_delete+1;
            delete_list(1,say_delete)=i;
            
            say_newadded=say_newadded+1;
            newadded_list(1,say_newadded)=unimp_list(1,i);
        end
    end
    
    if not(say_newadded)
        break
    else
        say_added=say_newadded;
        added_list=newadded_list;
        
        for i=1:say_delete
            say_unimp=say_unimp-1;
            unimp_list(:,delete_list(1,i)-i+1)=[];
        end
        
        if not(say_unimp)
            for i=1:say_added
                say_imp=say_imp+1;
                imp_list(1,say_imp)=added_list(1,i);
            end
            break
        end
    end
end

for i=1:say_imp
    int_constants(1,(imp_list(1,i)+1)/2)=0;
end
