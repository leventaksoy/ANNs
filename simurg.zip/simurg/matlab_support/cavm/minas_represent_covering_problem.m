function [say_vars,say_cons,say_optvars] = minas_represent_covering_problem(say_coef,coef_list,say_partial,partial_list,say_alloper,alloper_list)

say_vars=0;
say_cons=0;
say_optvars=0;

say_gate=0;
gate_list=[];

fid_pbtab=fopen('cover_problem.pbtab','w');
obj_func='min: ';

for i=1:say_alloper
    say_vars=say_vars+1;
    say_optvars=say_optvars+1;
    alloper_list(i,10)=say_vars;
    obj_func=[obj_func,'+',num2str(alloper_list(i,9)),' x',num2str(say_vars),' '];
    fprintf(fid_pbtab,'%6d = OPT_%d_%d_%d_%d_%d_%d_%d_%d_%d \n',say_vars,alloper_list(i,1),alloper_list(i,2),alloper_list(i,3),alloper_list(i,4),alloper_list(i,5),alloper_list(i,6),alloper_list(i,7),alloper_list(i,8),alloper_list(i,9));
end

for i=2:say_partial
    or_inputs=[];
    say_or_inputs=0;

    for j=partial_list(2,i):1:partial_list(3,i)
        if alloper_list(j,4)==alloper_list(j,7)
            if is_inside(alloper_list(j,4),say_coef,coef_list)
                alloper_list(j,11)=alloper_list(j,10);

                say_or_inputs=say_or_inputs+1;
                or_inputs(1,say_or_inputs)=alloper_list(j,11);
            else
                konum=where_is_inside(alloper_list(j,4),say_partial,partial_list);

                say_vars=say_vars+1;
                alloper_list(j,11)=say_vars;
                fprintf(fid_pbtab,'%6d = AND_%d_%d_%d_%d \n',say_vars,alloper_list(j,1)*(2^alloper_list(j,2)),alloper_list(j,3)*alloper_list(j,4)*(2^alloper_list(j,5)),alloper_list(j,6)*alloper_list(j,7)*(2^alloper_list(j,8)),alloper_list(j,9));

                say_cons=say_cons+3;
                say_gate=say_gate+1;
                gate_list(say_gate,1)=1;
                gate_list(say_gate,2)=2;
                gate_list(say_gate,3)=alloper_list(j,10);
                gate_list(say_gate,4)=partial_list(4,konum);
                gate_list(say_gate,5)=say_vars;

                say_or_inputs=say_or_inputs+1;
                or_inputs(1,say_or_inputs)=say_vars;
            end
        else
            is_one_coef=is_inside(alloper_list(j,4),say_coef,coef_list);
            is_two_coef=is_inside(alloper_list(j,7),say_coef,coef_list);

            if and(is_one_coef,is_two_coef)
                alloper_list(j,11)=alloper_list(j,10);

                say_or_inputs=say_or_inputs+1;
                or_inputs(1,say_or_inputs)=alloper_list(j,11);
            elseif is_one_coef
                konum=where_is_inside(alloper_list(j,7),say_partial,partial_list);

                say_vars=say_vars+1;
                alloper_list(j,11)=say_vars;
                fprintf(fid_pbtab,'%6d = AND_%d_%d_%d_%d \n',say_vars,alloper_list(j,1)*(2^alloper_list(j,2)),alloper_list(j,3)*alloper_list(j,4)*(2^alloper_list(j,5)),alloper_list(j,6)*alloper_list(j,7)*(2^alloper_list(j,8)),alloper_list(j,9));

                say_cons=say_cons+3;
                say_gate=say_gate+1;
                gate_list(say_gate,1)=1;
                gate_list(say_gate,2)=2;
                gate_list(say_gate,3)=alloper_list(j,10);
                gate_list(say_gate,4)=partial_list(4,konum);
                gate_list(say_gate,5)=say_vars;

                say_or_inputs=say_or_inputs+1;
                or_inputs(1,say_or_inputs)=say_vars;
            elseif is_two_coef
                konum=where_is_inside(alloper_list(j,4),say_partial,partial_list);

                say_vars=say_vars+1;
                alloper_list(j,11)=say_vars;
                fprintf(fid_pbtab,'%6d = AND_%d_%d_%d_%d \n',say_vars,alloper_list(j,1)*(2^alloper_list(j,2)),alloper_list(j,3)*alloper_list(j,4)*(2^alloper_list(j,5)),alloper_list(j,6)*alloper_list(j,7)*(2^alloper_list(j,8)),alloper_list(j,9));

                say_cons=say_cons+3;
                say_gate=say_gate+1;
                gate_list(say_gate,1)=1;
                gate_list(say_gate,2)=2;
                gate_list(say_gate,3)=alloper_list(j,10);
                gate_list(say_gate,4)=partial_list(4,konum);
                gate_list(say_gate,5)=say_vars;

                say_or_inputs=say_or_inputs+1;
                or_inputs(1,say_or_inputs)=say_vars;
            else
                konum_one=where_is_inside(alloper_list(j,4),say_partial,partial_list);
                konum_two=where_is_inside(alloper_list(j,7),say_partial,partial_list);

                say_vars=say_vars+1;
                alloper_list(j,11)=say_vars;
                fprintf(fid_pbtab,'%6d = AND_%d_%d_%d_%d \n',say_vars,alloper_list(j,1)*(2^alloper_list(j,2)),alloper_list(j,3)*alloper_list(j,4)*(2^alloper_list(j,5)),alloper_list(j,6)*alloper_list(j,7)*(2^alloper_list(j,8)),alloper_list(j,9));

                say_cons=say_cons+4;
                say_gate=say_gate+1;
                gate_list(say_gate,1)=1;
                gate_list(say_gate,2)=3;
                gate_list(say_gate,3)=alloper_list(j,10);
                gate_list(say_gate,4)=partial_list(4,konum_one);
                gate_list(say_gate,5)=partial_list(4,konum_two);
                gate_list(say_gate,6)=say_vars;

                say_or_inputs=say_or_inputs+1;
                or_inputs(1,say_or_inputs)=say_vars;
            end
        end
    end
    
    if say_or_inputs>1
        if is_inside(partial_list(1,i),say_coef,coef_list)
            say_cons=say_cons+1;
            say_gate=say_gate+1;
            gate_list(say_gate,1)=3;
            gate_list(say_gate,2)=say_or_inputs;

            for j=1:say_or_inputs
                gate_list(say_gate,j+2)=or_inputs(1,j);
            end
        else
            say_vars=say_vars+1;
            partial_list(4,i)=say_vars;
            fprintf(fid_pbtab,'%6d = OR_%d \n',say_vars,partial_list(1,i));

            say_gate=say_gate+1;
            gate_list(say_gate,1)=2;
            say_cons=say_cons+say_or_inputs+1;
            gate_list(say_gate,2)=say_or_inputs;

            for j=1:say_or_inputs
                gate_list(say_gate,j+2)=or_inputs(1,j);
            end

            gate_list(say_gate,j+3)=say_vars;
        end
    else
        partial_list(4,i)=alloper_list(j,11);

        if is_inside(partial_list(1,i),say_coef,coef_list)
            say_cons=say_cons+1;
            say_gate=say_gate+1;
            gate_list(say_gate,1)=4;
            gate_list(say_gate,2)=alloper_list(j,11);
        end
    end
end

fclose(fid_pbtab);

fid_pb=fopen('cover_problem.opb','w');
fprintf(fid_pb,'* # variables: %d # constraints: %d # opt. variables: %d\n',say_vars,say_cons,say_optvars);
fprintf(fid_pb,'%s;\n',obj_func);

for i=1:say_gate
    if gate_list(i,1)==1
        and_inputs=[];
        say_and_inputs=gate_list(i,2);
        for j=1:say_and_inputs
            and_inputs(1,j)=gate_list(i,j+2);
        end
        and_output=gate_list(i,j+3);
        
        minas_and_write_pb(fid_pb,say_and_inputs,and_inputs,and_output);
    elseif gate_list(i,1)==2
        or_inputs=[];
        say_or_inputs=gate_list(i,2);
        for j=1:say_or_inputs
            or_inputs(1,j)=gate_list(i,j+2);
        end
        or_output=gate_list(i,j+3);
        
        minas_or_write_pb(fid_pb,say_or_inputs,or_inputs,or_output);
    elseif gate_list(i,1)==3
        or_inputs=[];
        say_or_inputs=gate_list(i,2);
        for j=1:say_or_inputs
            or_inputs(1,j)=gate_list(i,j+2);
        end
        
        minas_or_coefwrite_pb(fid_pb,say_or_inputs,or_inputs);
    else
        fprintf(fid_pb,'+1 x%d >= 1;\n',gate_list(i,2));
    end
end

fclose(fid_pb);
