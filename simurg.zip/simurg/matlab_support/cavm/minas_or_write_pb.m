function [ ] = minas_or_write_pb(fid_bnf,say_or_inputs,or_inputs,or_output)

or_str='';
for i=1:say_or_inputs
    or_str=[or_str,'+1 x',num2str(or_inputs(1,i)),' '];
    fprintf(fid_bnf,'-1 x%d +1 x%d >= 0;\n',or_inputs(1,i),or_output);
end

fprintf(fid_bnf,'%s-1 x%d >= 0;\n',or_str,or_output);
