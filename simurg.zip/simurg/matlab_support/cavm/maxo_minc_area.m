function [cavm_oper,cavm_step] = maxo_minc_area(x_bitwidth,file_name,say_coef,coef_list,decomposed_cell)

say_target=1;
target_stats=0;
say_column=say_coef;
target_list=coef_list';
target_repcell=cell(1,1);

say_decomposed=0;
decomposed_list=[];
for i=1:say_coef
    if coef_list(i,1)
        the_cons=0;
        the_list=decomposed_cell{i,1};
        for j=1:the_list(1,1)
            say_decomposed=say_decomposed+1;
            decomposed_list(1,say_decomposed)=the_list(1,j+1);
            decomposed_list(2,say_decomposed)=i;
            the_cons=the_cons+the_list(1,j+1);
        end
        
        if the_cons~=coef_list(i,1)
            fprintf('\n');
            fprintf('* Houston, there is a problem in the decomposition of %d !!!\n',coef_list(i,1));
            fprintf('\n');
        end
    end
end
target_stats=say_decomposed;
target_repcell{1,1}=decomposed_list;

decomposed_list
pause

say_output=say_target;
output_list=target_list;

say_partial=say_column;
partial_imp=zeros(say_column,4);
partial_list=eye(say_column);

while 1
    %The most common 2-term subexpressions with their occurences in the
    %expressions are found.
    [max_freq,say_max_freq,max_freq_cell]=find_two_term_divisors(say_column,say_target,partial_list,target_stats,target_repcell);
    
    if max_freq==1
        break
    else
        max_freq
        celldisp(max_freq_cell)
        pause
        
        %The minimum conflicting the most common 2-term subexpression is
        %found.
        [chosen_divisor,the_index]=find_min_conflict_divisor(say_max_freq,max_freq_cell);        
        divisor_array=divisor2array(say_column,chosen_divisor,partial_list);
        
        %It is chosen.
        say_partial=say_partial+1;
        partial_list(say_partial,:)=divisor_array;
        partial_imp(say_partial,1)=chosen_divisor(1,1);
        partial_imp(say_partial,2)=chosen_divisor(2,1);
        partial_imp(say_partial,3)=chosen_divisor(1,2);
        partial_imp(say_partial,4)=chosen_divisor(2,2);
        
        %It is replaced in the expressions.
        [target_stats,target_repcell]=replace_the_divisor(say_partial,chosen_divisor,the_index,target_stats,target_repcell);
    end
    
    partial_list
    celldisp(target_repcell)
    pause
end

%At this stage, there is no longer a 2-term subexpression sharing. Hence,
%the expressions in the final expressions are realized in this function.
%However, this function considers the gate-level implementation of constant
%multiplications.
[say_partial,partial_list,partial_imp]=realize_final_expresssions(x_bitwidth,say_column,say_target,say_partial,target_stats,target_repcell,partial_list,partial_imp);

%The solution is written to the result file.
[cavm_oper,cavm_step]=file_write_result(file_name,say_coef,coef_list,say_column,say_partial,say_output,partial_list,partial_imp,output_list);

