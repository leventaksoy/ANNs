function [sorted_list] = sort_ascending_order(say_term,the_list)

sorted_list=zeros(1,say_term);
greater_list=zeros(1,say_term);

for i=1:say_term-1
    for j=i+1:1:say_term
        if the_list(1,i)>the_list(1,j)
            greater_list(1,i)=greater_list(1,i)+1;
        else
            greater_list(1,j)=greater_list(1,j)+1;
        end
    end
end

for i=1:say_term
    sorted_list(1,greater_list(1,i)+1)=the_list(1,i);
end
