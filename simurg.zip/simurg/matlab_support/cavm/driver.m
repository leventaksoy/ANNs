cd /home/levent/mcodes/petra_random_delay14
petra_random
