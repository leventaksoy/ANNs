function [upper_bound,upper_list] = mcm_find_upper_bound_approx(cost_values,say_coef,say_unimp,max_limit,coef_list,unimp_list)

say_add=1;
say_imp=1;
add_list=[1];
imp_list=[1];

[say_imp,imp_list,say_unimp,unimp_list]=mcm_find_optimal(max_limit,say_imp,imp_list,say_add,add_list,say_unimp,unimp_list);

while say_unimp
    zero_cost=0;
    min_cost=inf;
    min_cost_partial=0;
    
    for i=1:2:2^(max_limit+1)-1
        if not(is_inside(i,say_imp,imp_list))
            if not(is_inside(i,say_unimp,unimp_list))
                [partial_imp_cost]=mcm_find_optimal_partial_cost(cost_values,max_limit,say_imp,imp_list,say_imp,imp_list,1,[i]);
                
                if not(partial_imp_cost)
                    
                    say_add=1;
                    add_list=[i];
                    say_imp=say_imp+1;
                    imp_list(1,say_imp)=i;
                    [partial_synthesis_cost]=mcm_find_optimal_partial_cost(cost_values,max_limit,say_imp,imp_list,say_add,add_list,say_unimp,unimp_list);
                    imp_list(:,say_imp)=[];
                    say_imp=say_imp-1;
                    
                    if partial_imp_cost+partial_synthesis_cost<min_cost
                        min_cost=partial_imp_cost+partial_synthesis_cost;
                        min_cost_partial=i;
                        
                        if partial_imp_cost+partial_synthesis_cost==0
                            zero_cost=1;
                        end
                    end
                
                end
            end
        end
         
        if zero_cost
            break;
        end
    end
    
    say_unimp=say_unimp+1;
    unimp_list(1,say_unimp)=min_cost_partial;
    unimp_list=mcm_sort_unimplemented(cost_values,say_unimp,unimp_list);
    
    [say_imp,imp_list,say_unimp,unimp_list]=mcm_find_optimal(max_limit,say_imp,imp_list,say_imp,imp_list,say_unimp,unimp_list);
end

say_deleted=0;
konum_partial=0;

while 1
    konum_partial=konum_partial+1;
    if not(is_inside(imp_list(1,konum_partial),say_coef,coef_list))
        say_add=1;
        add_list=[1];
        new_sayimp=1;
        new_implist=[1];
        
        say_unimp=say_imp;
        unimp_list=imp_list;
        say_unimp=say_unimp-1;
        unimp_list(:,konum_partial)=[];
        
        [new_sayimp,new_implist,say_unimp,unimp_list]=mcm_find_optimal(max_limit,new_sayimp,new_implist,say_add,add_list,say_unimp,unimp_list);
        
        if say_unimp==0
            say_imp=say_imp-1;
            say_deleted=say_deleted+1;
            imp_list(:,konum_partial)=[];
            konum_partial=konum_partial-1;
        end
    end
    
    if say_imp==konum_partial
        break
    end
end

upper_bound=say_imp-1;
upper_list=imp_list;
