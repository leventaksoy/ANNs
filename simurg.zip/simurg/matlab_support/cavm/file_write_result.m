function [say_step] = file_write_result(area_delay,source_file,file_name,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_imp,partial_imp,imp_label)

[say_step]=determine_adder_step(say_imp,partial_imp);

file_result=[file_name,'.result'];
fid_result=fopen(file_result,'w');

fprintf(fid_result,'* Shift-Adds Implementation of Constant Array Vector Multiplication\n');
saat=clock;
fprintf(fid_result,'* Date: %s Time: %d:%d:%.0f \n',date,saat(1,4),saat(1,5),saat(1,6));
fprintf(fid_result,'* Source MCM File: %s\n',source_file);
fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Primary Expressions ***\n');
fprintf(fid_result,'\n');
fprintf(fid_result,'O1: (');
for i=1:say_coef
    if orig_coeflist(i,1)>=0
        fprintf(fid_result,'+%d*X%d',orig_coeflist(i,1),i);
    else
        fprintf(fid_result,'%d*X%d',orig_coeflist(i,1),i);
    end
end
fprintf(fid_result,') = ');
if output_sign==1
    fprintf(fid_result,'+(');
else
    fprintf(fid_result,'-(');
end
for i=1:say_coef
    if coef_list(i,1)>=0
        fprintf(fid_result,'+%d*X%d',coef_list(i,1),i);
    else
        fprintf(fid_result,'%d*X%d',coef_list(i,1),i);
    end
end
fprintf(fid_result,')<<%d\n',output_power);
fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Expressions ***\n');
fprintf(fid_result,'\n');

for i=1:say_imp
    if i~=say_imp
        fprintf(fid_result,'S%d: (',i);
    else
        fprintf(fid_result,'O1: (');
    end
    for j=1:say_coef
        if imp_label(i,j)>0
            fprintf(fid_result,'+%d*X%d',imp_label(i,j),j);
        elseif imp_label(i,j)<0
            fprintf(fid_result,'%d*X%d',imp_label(i,j),j);
        end
    end
    fprintf(fid_result,') = ');
    [first_sign,first_power,first_cons]=make_number_posodd(partial_imp(i,1));
    [second_sign,second_power,second_cons]=make_number_posodd(partial_imp(i,4));
    if partial_imp(i,2)<0
        fprintf(fid_result,'+X%d<<%d ',abs(partial_imp(i,2)),first_power);
    else
        fprintf(fid_result,'+S%d<<%d ',partial_imp(i,2),first_power);
    end
    if partial_imp(i,3)==1
        fprintf(fid_result,'+');
    else
        fprintf(fid_result,'-');
    end
    if partial_imp(i,5)<0
        fprintf(fid_result,'X%d<<%d \n',abs(partial_imp(i,5)),second_power);
    else
        fprintf(fid_result,'S%d<<%d \n',partial_imp(i,5),second_power);
    end
end

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Summary of results \n');
fprintf(fid_result,'* Number of operations: %d\n',say_imp);
fprintf(fid_result,'* Number of adder-steps: %d\n',say_step);
fprintf(fid_result,'\n');

fclose(fid_result);
