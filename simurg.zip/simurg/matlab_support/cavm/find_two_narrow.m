function [narrow_indis] = find_two_narrow(say_list,the_list)

narrow_indis=[1 2];
two_narrow=[the_list(3,1) the_list(3,2)];

if two_narrow(1,1)>two_narrow(1,2)
    the_max=two_narrow(1,1);
    max_indis=1;
else
    the_max=two_narrow(1,2);
    max_indis=2;
end

for i=3:1:say_list
    if the_list(3,i)<the_max
        two_narrow(1,max_indis)=the_list(3,i);
        narrow_indis(1,max_indis)=i;
        
        if two_narrow(1,1)>two_narrow(1,2)
            the_max=two_narrow(1,1);
            max_indis=1;
        else
            the_max=two_narrow(1,2);
            max_indis=2;
        end
    end
end
