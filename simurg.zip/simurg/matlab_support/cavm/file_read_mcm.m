function [say_coefzero,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_oper,oper_list] = file_read_mcm(file_solution)

say_coef=0;
say_oper=0;
coef_list=[];
oper_list=[];
output_sign=-1;
say_coefzero=0;
orig_coeflist=[];
output_power=inf;

fid_solution=fopen(file_solution,'r');

while 1
    tline= fgetl(fid_solution);
    if or(strcmp(tline, '*** Implementation of Coefficients ***' ),or(strcmp(tline, '*** Implementation of Filter Coefficients ***' ),strcmp(tline, '*** Implementation of Filter Coefficients' )))
        break
    end
end

fgetl(fid_solution);

while 1
    tline=fgetl(fid_solution);
    
    if not(isempty(tline))
        the_initial=1;
        while tline(1,the_initial)~='='
            the_initial=the_initial+1;
        end

        the_coef=str2num(char(tline(1:1,1:the_initial-1)));
        say_coef=say_coef+1;
        coef_list(say_coef,1)=the_coef;
        [coef_list(say_coef,3),coef_list(say_coef,4),coef_list(say_coef,2)]=make_number_posodd(the_coef);
        
        if the_coef
            if coef_list(say_coef,3)==1
                output_sign=1;
            end

            if coef_list(say_coef,4)<output_power
                output_power=coef_list(say_coef,4);
            end
        else
            say_coefzero=say_coefzero+1;
        end
    else
        break
    end
end

orig_coeflist=coef_list(:,1);
coef_list(:,1)=(coef_list(:,1)*output_sign)/2^output_power;
coef_list(:,3)=coef_list(:,3)*output_sign;
coef_list(:,4)=coef_list(:,4)-output_power;

while 1
    tline= fgetl(fid_solution);
    if or(strcmp( tline, '*** Implementation of Partial Terms ***' ),strcmp( tline, '*** Implementation of Partial Terms' ))
        break
    end
end

is_checked=1;
first_line=1;

while 1
    the_line=fgetl(fid_solution);

    if and(strcmp(the_line, '')==1,first_line==0)
        break
    elseif the_line==-1
        break
    elseif and(strcmp(the_line, '')==1,first_line==1)
        the_line=fgetl(fid_solution);
    end
    
    first_line=0;

    the_start=1;
    the_initial=1;
    say_oper=say_oper+1;
    oper_line{say_oper,1}=the_line;

    while the_line(1,the_start)~='>'
        the_start=the_start+1;
    end

    the_coef=str2num(char(the_line(1:1,the_initial:the_start-1)));
    
    oper_list(say_oper,1)=the_coef;

    the_start=the_start+2;
    the_initial=the_start;

    while the_line(1,the_start)~='='
        the_start=the_start+1;
    end

    shift_coef=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,2)=shift_coef;

    the_start=the_start+2;

    if the_line(1,the_start)=='+'
        oper_list(say_oper,3)=1;
    elseif the_line(1,the_start)=='-'
        oper_list(say_oper,3)=-1;
    end

    the_start=the_start+1;
    the_initial=the_start;

    while the_line(1,the_start)~='<'
        the_start=the_start+1;
    end

    first_partial=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,4)=first_partial;

    the_start=the_start+2;
    the_initial=the_start;

    while and(the_line(1,the_start)~='+',the_line(1,the_start)~='-')
        the_start=the_start+1;
    end

    first_shift=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,5)=first_shift;

    if the_line(1,the_start)=='+'
        oper_list(say_oper,6)=1;
    elseif the_line(1,the_start)=='-'
        oper_list(say_oper,6)=-1;
    end

    the_start=the_start+1;
    the_initial=the_start;
    while the_line(1,the_start)~='<'
        the_start=the_start+1;
    end

    second_partial=str2num(char(the_line(1:1,the_initial:the_start-1)));
    oper_list(say_oper,7)=second_partial;

    the_start=the_start+2;
    second_shift=str2num(char(the_line(1:1,the_start:length(the_line))));
    oper_list(say_oper,8)=second_shift;

    if oper_list(say_oper,1)*(2^oper_list(say_oper,2))~=oper_list(say_oper,3)*oper_list(say_oper,4)*(2^oper_list(say_oper,5))+oper_list(say_oper,6)*oper_list(say_oper,7)*(2^oper_list(say_oper,8))
        is_checked=0;
        fpritnf(' \n');
        fprintf('Error: The %d. operation computes a wrong number. Quiting... \n', say_oper);
        fpritnf(' \n');
        break
    end
end

fclose(fid_solution);
