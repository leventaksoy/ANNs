function [the_value] = is_inside_horizontal_array(say_cons,cons_list,the_cons)

the_value=0;

for i=1:say_cons
    if cons_list(1,i)==the_cons
        the_value=1;
        return
    end
end
