function [ ] = minas_or_coefwrite_pb(fid_bnf,say_or_inputs,or_inputs)

or_str='';
for i=1:say_or_inputs
    or_str=[or_str,'+1 x',num2str(or_inputs(1,i)),' '];
end

fprintf(fid_bnf,'%s>= 1;\n',or_str);
