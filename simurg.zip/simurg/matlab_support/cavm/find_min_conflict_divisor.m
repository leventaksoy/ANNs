function [chosen_divisor,the_index] = find_min_conflict_divisor(say_max_freq,max_freq_cell)

conflict_matrix=zeros(say_max_freq,say_max_freq);

for i=1:say_max_freq-1
    target_i=max_freq_cell{3,i};
    
    for j=i+1:1:say_max_freq
        target_j=max_freq_cell{3,j};
        
        for k=1:1:length(target_i)/3
            for m=1:length(target_j)/3
                if target_i(1,3*k-2)==target_j(1,3*m-2)
                    if or(target_i(1,3*k-1)==target_j(1,3*m-1),target_i(1,3*k-1)==target_j(1,3*m))
                        conflict_matrix(i,j)=conflict_matrix(i,j)+1;
                        conflict_matrix(j,i)=conflict_matrix(j,i)+1;
                    elseif or(target_i(1,3*k)==target_j(1,3*m-1),target_i(1,3*k)==target_j(1,3*m))
                        conflict_matrix(i,j)=conflict_matrix(i,j)+1;
                        conflict_matrix(j,i)=conflict_matrix(j,i)+1;
                    end
                end
            end
        end
        
    end
    
end

max_conflict=-inf;
max_conflict_index=0;

for i=1:say_max_freq
    total_conflict=sum(conflict_matrix(i,:));
    
    if total_conflict>max_conflict
        max_conflict=total_conflict;
        max_conflict_index=i;
    end
end

chosen_divisor=max_freq_cell{1,max_conflict_index};
the_index=max_freq_cell{2,max_conflict_index};
