function [min_list,search_timeover] = mcm_depth_first_search(dfs_cpu_limit,max_limit,lowest_bound,lower_bound,upper_bound,say_unimp,unimp_list)

min_list=[];

say_imp=0;
imp_list=[];
say_added=1;
added_list=[1];
int_constants=zeros(1,2^max_limit);

[say_imp,imp_list,say_unimp,unimp_list,int_constants]=mcm_find_int_constants(max_limit,say_added,added_list,int_constants,say_imp,imp_list,say_unimp,unimp_list);

say_iter=1;
cell_iter=cell(1,4);
cell_iter{say_iter,1}=say_imp;
cell_iter{say_iter,2}=imp_list;
cell_iter{say_iter,3}=say_unimp;
cell_iter{say_iter,4}=unimp_list;

cell_int_cons=cell(1,1);
cell_int_cons{say_iter,1}=int_constants;

partial_pos=ones(upper_bound-lowest_bound,1);

say_forbidden=ones(upper_bound-lowest_bound,1);
forbidden_list=ones(upper_bound-lowest_bound,1);

min_found=0;
search_complete=0;
search_timeover=0;

all_added=ones(upper_bound-lowest_bound,1);

say_comb=0;
say_pruned=0;
dfs_time=cputime;

while not(or(or(min_found,search_complete),search_timeover))

    while 1
        partial_found=0;
        intcons_array=cell_int_cons{say_iter,1};

        for i=1:say_forbidden(say_iter,1)
            intcons_array(1,forbidden_list(say_iter,i))=0;
        end

        for i=partial_pos(say_iter+1,1)+1:2^max_limit
            if intcons_array(1,i)
                partial_found=1;

                say_iter=say_iter+1;
                partial_pos(say_iter,1)=i;

                say_comb=say_comb+1;
                break
            end
        end

        if partial_found
            break
        else
            partial_pos(say_iter+1,1)=1;
            say_forbidden(say_iter+1,1)=1;

            say_forbidden(say_iter,1)=say_forbidden(say_iter,1)+1;
            forbidden_list(say_iter,say_forbidden(say_iter,1))=partial_pos(say_iter,1);

            say_iter=say_iter-1;

            if not(say_iter)
                search_complete=1;
                break
            end
        end
    end

    if partial_found
        say_added=1;
        added_list=2*partial_pos(say_iter,1)-1;

        say_imp=cell_iter{say_iter-1,1};
        imp_list=cell_iter{say_iter-1,2};
        say_unimp=cell_iter{say_iter-1,3};
        unimp_list=cell_iter{say_iter-1,4};

        int_constants=cell_int_cons{say_iter-1,1};


        [say_imp,imp_list,say_unimp,unimp_list,int_constants]=mcm_find_int_constants(max_limit,say_added,added_list,int_constants,say_imp,imp_list,say_unimp,unimp_list);

        if say_unimp
            if lowest_bound+say_iter==upper_bound
                say_iter=say_iter-1;
            else
                cell_iter{say_iter,1}=say_imp;
                cell_iter{say_iter,2}=imp_list;
                cell_iter{say_iter,3}=say_unimp;
                cell_iter{say_iter,4}=unimp_list;

                cell_int_cons{say_iter,1}=int_constants;
            end
        else
            if lowest_bound+say_iter-1==lower_bound
                min_found=1;
                min_list=imp_list;
                break
            else
                first_check=0;
                min_list=imp_list;
                upper_bound=lowest_bound+say_iter-1;

                partial_pos(say_iter,1)=1;
                say_forbidden(say_iter,1)=1;

                say_iter=say_iter-1;
                say_iter=say_iter-1;
            end
        end
    end

    if cputime-dfs_time>dfs_cpu_limit
        search_timeover=1;
    end
end
