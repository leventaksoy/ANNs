function [say_coef,coef_list,say_target,target_list,say_oper,oper_list] = find_decomposed_form(file_mcm)

[say_coef,coef_list,say_oper,oper_list]=file_read_mcm(file_mcm);

say_target=0;
target_list=[];

for i=1:say_coef
    if coef_list(i,2)
        say_target=say_target+1;
        target_list(1,say_target)=coef_list(i,2);
        target_list(2,say_target)=i;
        
        if coef_list(i,2)==1
            coef_list(i,5)=-1;
        else
            [coef_indis]=whereis_inside_vertical(say_oper,oper_list,coef_list(i,2));
            coef_list(i,5)=coef_indis;
        end
    end
end

for i=1:say_oper
    [oper_indis]=whereis_inside_vertical(say_coef,coef_list,oper_list(i,1));
    oper_list(i,9)=oper_indis;
end
