clear;

os_choice=0;
%area_delay=1;
x_bitwidth=16;

mcm_algo=input('MCM algorithm (0: Exact GB wodc, 1: Approximate GB wdc 2: Solution of an MCM algorithm 3: MINAS 4: MINAS-DC): ');
area_delay=input('Design objective (0: area, 1: delay): ');
%os_choice=input('Operating system (0: Windows, 1: Linux): ');
if mcm_algo==2
    source_file=input('Name of file including an MCM solution: ', 's');
else
    source_file=input('Name of file including coefficients: ','s');
end

initial_time=cputime;

file_name='';
dot_indis=length(source_file);
for i=length(source_file):-1:1
    if source_file(1,i)=='.'
        dot_indis=i-1;
        break
    end
end
file_name=source_file(1:1,1:dot_indis);

%% Find the MCM solution
if ~mcm_algo
    [say_coefzero,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_cons,cons_list,max_cons]=file_read_coef(source_file);
    [max_step,say_oper,oper_list,oper_indis]=find_mcm_solution_wodc(say_cons,cons_list,max_cons);
elseif mcm_algo==1
    [say_coefzero,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_cons,cons_list,max_cons]=file_read_coef(source_file);
    [max_step,say_oper,oper_list,oper_indis]=find_mcm_solution_wdc(say_cons,cons_list,max_cons);
elseif mcm_algo==2
    [say_coefzero,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_oper,oper_list]=file_read_mcm(source_file);
    [max_step,oper_list,oper_indis]=determine_adderstep(say_oper,oper_list);
else
    if mcm_algo==3
        delay_constraint=0;
    else
        delay_constraint=1;
    end
    [say_coefzero,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_cons,cons_list,max_cons]=file_read_coef(source_file);
    [max_step,say_oper,oper_list,oper_indis]=find_mcm_solution_minas(os_choice,x_bitwidth,say_cons,cons_list,max_cons,delay_constraint);
end

%% Determine the indices of coefficients int the operation list
say_target=0;
target_list=[];

for i=1:say_coef
    if coef_list(i,2)
        if coef_list(i,2)==1
            coef_list(i,5)=-1;
        else
            [coef_indis]=whereis_inside_vertical(say_oper,oper_list,coef_list(i,2));
            coef_list(i,5)=coef_indis;
        end
        
        say_target=say_target+1;
        target_list(1,say_target)=coef_list(i,2);
        target_list(2,say_target)=coef_list(i,3)*2^coef_list(i,4);
        target_list(3,say_target)=coef_list(i,5);
        target_list(4,say_target)=i;
    end
end

%target_list
%pause

say_partial=say_coef;
partial_cell=cell(say_coef,1);

%% First, find similar constants in the target_list and factor the common
%% terms

new_saytarget=say_target;
new_targetlist=target_list;

say_add=0;
add_list=[];
say_delete=0;
delete_list=[];
checked_list=zeros(1,new_saytarget);

for i=1:new_saytarget-1
    if new_targetlist(1,i)~=1
        if ~checked_list(1,i)
            say_term=1;
            max_index=0;
            term_indis=[i];
            the_term=new_targetlist(1,i);

            for j=i+1:1:new_saytarget
                if new_targetlist(1,j)==the_term
                    say_term=say_term+1;
                    term_indis(1,say_term)=j;

                    if new_targetlist(4,j)>max_index
                        max_index=new_targetlist(4,j);
                    end
                end
            end

            if say_term>1
                the_part=zeros(1,say_term);

                for j=1:say_term
                    checked_list(1,term_indis(1,j))=1;

                    the_part(1,j)=new_targetlist(2,term_indis(1,j));
                    the_part(2,j)=new_targetlist(4,term_indis(1,j));

                    say_delete=say_delete+1;
                    delete_list(1,say_delete)=term_indis(1,j);
                end

                [the_sign,the_power,posodd_part]=conv_array_posodd(say_term,the_part);

                [partial_index]=whereis_inside_partialcell(say_coef,say_partial,partial_cell,posodd_part);
                if ~partial_index
                    say_partial=say_partial+1;
                    partial_cell{say_partial,1}=posodd_part;
                    partial_index=say_partial;
                end

                say_add=say_add+1;
                add_list(1,say_add)=the_term;
                add_list(2,say_add)=the_sign*2^the_power;
                add_list(3,say_add)=new_targetlist(3,i);
                add_list(4,say_add)=partial_index;
            end
        end
    end
end

[delete_list]=sort_ascending_order(say_delete,delete_list);

for i=say_delete:-1:1
    new_saytarget=new_saytarget-1;
    new_targetlist(:,delete_list(1,i))=[];
end

for i=1:say_add
    new_saytarget=new_saytarget+1;
    new_targetlist(:,new_saytarget)=add_list(:,i);
end

say_target=new_saytarget;
target_list=new_targetlist;
%pause

%% Second, step by step decompose the realization of constant based on the
%% MCM solution and find the common partial terms and extract them

the_step=max_step;
while the_step
    new_saytarget=0;
    new_targetlist=[];
    
    for i=1:say_target
        if target_list(1,i)~=1
            oper_index=target_list(3,i);
        
            if oper_list(oper_index,9)==the_step
                carpan=target_list(2,i);

                new_saytarget=new_saytarget+1;
                new_targetlist(1,new_saytarget)=oper_list(oper_index,4);
                new_targetlist(2,new_saytarget)=carpan*oper_list(oper_index,3)*2^oper_list(oper_index,5);
                new_targetlist(3,new_saytarget)=oper_indis(oper_index,1);
                new_targetlist(4,new_saytarget)=target_list(4,i);
                
                new_saytarget=new_saytarget+1;
                new_targetlist(1,new_saytarget)=oper_list(oper_index,7);
                new_targetlist(2,new_saytarget)=carpan*oper_list(oper_index,6)*2^oper_list(oper_index,8);
                new_targetlist(3,new_saytarget)=oper_indis(oper_index,2);
                new_targetlist(4,new_saytarget)=target_list(4,i);
            else
                new_saytarget=new_saytarget+1;
                new_targetlist(:,new_saytarget)=target_list(:,i);
            end
        else
            new_saytarget=new_saytarget+1;
            new_targetlist(:,new_saytarget)=target_list(:,i);
        end
    end
    
    %new_targetlist
    %pause
    
    say_add=0;
    add_list=[];
    say_delete=0;
    delete_list=[];
    checked_list=zeros(1,new_saytarget);
    
    for i=1:new_saytarget-1
        if new_targetlist(1,i)~=1
            if ~checked_list(1,i)
                say_term=1;
                max_index=0;
                term_indis=[i];
                the_term=new_targetlist(1,i);

                for j=i+1:1:new_saytarget
                    if new_targetlist(1,j)==the_term
                        say_term=say_term+1;
                        term_indis(1,say_term)=j;

                        if new_targetlist(4,j)>max_index
                            max_index=new_targetlist(4,j);
                        end
                    end
                end

                if say_term>1
                    the_part=zeros(1,say_term);

                    for j=1:say_term
                        checked_list(1,term_indis(1,j))=1;
                        
                        the_part(1,j)=new_targetlist(2,term_indis(1,j));
                        the_part(2,j)=new_targetlist(4,term_indis(1,j));

                        say_delete=say_delete+1;
                        delete_list(1,say_delete)=term_indis(1,j);
                    end
                    
                    [the_sign,the_power,posodd_part]=conv_array_posodd(say_term,the_part);

                    [partial_index]=whereis_inside_partialcell(say_coef,say_partial,partial_cell,posodd_part);
                    if ~partial_index
                        say_partial=say_partial+1;
                        partial_cell{say_partial,1}=posodd_part;
                        partial_index=say_partial;
                    end

                    say_add=say_add+1;
                    add_list(1,say_add)=the_term;
                    add_list(2,say_add)=the_sign*2^the_power;
                    add_list(3,say_add)=new_targetlist(3,i);
                    add_list(4,say_add)=partial_index;
                end
            end
        end
    end
    
    [delete_list]=sort_ascending_order(say_delete,delete_list);
    
    for i=say_delete:-1:1
        new_saytarget=new_saytarget-1;
        new_targetlist(:,delete_list(1,i))=[];
    end
    
    for i=1:say_add
        new_saytarget=new_saytarget+1;
        new_targetlist(:,new_saytarget)=add_list(:,i);
    end
    
    say_target=new_saytarget;
    target_list=new_targetlist;
    %pause
    
    the_step=the_step-1;
end

the_part=zeros(2,say_target);
the_part(1,:)=target_list(2,:);
the_part(2,:)=target_list(4,:);

say_partial=say_partial+1;
partial_cell{say_partial}=the_part;

%% Find the 2-term implementation of terms in partial cells based on area
%% and delay parameters

if ~area_delay
    [say_imp,partial_imp,imp_label]=determine_implementations_area(x_bitwidth,say_coef,coef_list,say_partial,partial_cell);
else
    [say_imp,partial_imp,imp_label]=determine_implementations_delay(x_bitwidth,say_coef,coef_list,say_partial,partial_cell);
end

[say_step]=file_write_result(area_delay,source_file,file_name,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_imp,partial_imp,imp_label);

if say_imp~=say_oper+say_coef-say_coefzero-1
    fprintf('\n');
    fprintf('Houston, there is a conflict with the third reviewer !!! \n');
    fprintf('P.S. petra\n');
    fprintf('\n');
    
    checkif_oneincluded_more(say_coef,say_imp,imp_label);
end

total_time=cputime-initial_time;

fprintf('\n');
fprintf('*** General Information \n');
fprintf('* Number of nonzero coefficients: %d \n',say_coef-say_coefzero);
fprintf('\n');
fprintf('*** Summary of MCM results \n');
fprintf('* Number of operations: %d\n',say_oper);
fprintf('* Number of adder-steps: %d\n',max_step);
fprintf('\n');
fprintf('*** Summary of CAVM results \n');
fprintf('* Number of operations: %d\n',say_imp);
fprintf('* Number of adder-steps: %d\n',say_step);
fprintf('* CPU time: %.2f\n',total_time);
fprintf('\n');
