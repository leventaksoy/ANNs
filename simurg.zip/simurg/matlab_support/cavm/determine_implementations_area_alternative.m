function [say_imp,partial_imp,imp_label] = determine_implementations_area(x_bitwidth,say_coef,coef_list,say_partial,partial_cell)

say_imp=0;
partial_imp=[];
imp_label=zeros(1,say_coef);

partial_index=zeros(say_partial,1);
partial_width=zeros(say_partial,1);
partial_width(1:say_coef,1)=x_bitwidth;

for i=say_coef+1:1:say_partial
    term_list=partial_cell{i,1};
    stl=size(term_list);
    say_term=stl(1,2);
    
    %% The terms are categorized according to their signs
    
    say_add=0;
    say_sub=0;
    add_list=[];
    sub_list=[];
    
    for j=1:say_term
        if term_list(1,j)>0
            say_add=say_add+1;
            add_list(1,say_add)=term_list(1,j);
            add_list(2,say_add)=term_list(2,j);
            if term_list(2,j)>say_coef
                add_list(3,say_add)=partial_width(term_list(2,j),1);
            else
                add_list(3,say_add)=x_bitwidth+log2(term_list(1,j));
            end
        else
            say_sub=say_sub+1;
            sub_list(1,say_sub)=abs(term_list(1,j));
            sub_list(2,say_sub)=term_list(2,j);
            if term_list(2,j)>say_coef
                sub_list(3,say_sub)=partial_width(term_list(2,j),1);
            else
                sub_list(3,say_sub)=x_bitwidth+log2(abs(term_list(1,j)));
            end
        end
    end
    
    %% Positive signs
    
    if say_add
        while say_add~=1
            [add_list]=order_descending_wrtrowvalue(3,say_add,add_list);
            
            the_pair=zeros(3,2);
            the_pair(:,1)=add_list(:,say_add-1);
            the_pair(:,2)=add_list(:,say_add);
            
            [pair_sign,pair_power,the_pair(1,:)]=conv_array_posodd(2,the_pair(1,:));
            
            say_imp=say_imp+1;
            
            partial_imp(say_imp,1)=the_pair(1,1);
            if the_pair(2,1)>0
                if the_pair(2,1)<=say_coef
                    partial_imp(say_imp,2)=(-1)*the_pair(2,1);
                    
                    first_label=zeros(1,say_coef);
                    first_label(1,the_pair(2,1))=the_pair(1,1);
                else
                    partial_imp(say_imp,2)=partial_index(the_pair(2,1),1);
                    
                    first_label=the_pair(1,1)*imp_label(partial_index(the_pair(2,1),1),:);
                end
            else
                partial_imp(say_imp,2)=abs(the_pair(2,1));
                
                first_label=the_pair(1,1)*imp_label(abs(the_pair(2,1)),:);
            end
            
            %% Addition
            partial_imp(say_imp,3)=1;
            
            partial_imp(say_imp,4)=the_pair(1,2);
            if the_pair(2,2)>0
                if the_pair(2,2)<=say_coef
                    partial_imp(say_imp,5)=(-1)*the_pair(2,2);
                    
                    second_label=zeros(1,say_coef);
                    second_label(1,the_pair(2,2))=the_pair(1,2);
                else
                    partial_imp(say_imp,5)=partial_index(the_pair(2,2),1);
                    
                    second_label=the_pair(1,2)*imp_label(partial_index(the_pair(2,2),1),:);
                end
            else
                partial_imp(say_imp,5)=abs(the_pair(2,2));
                
                second_label=the_pair(1,2)*imp_label(abs(the_pair(2,2)),:);
            end
            
            pair_label=first_label+second_label;
            imp_label(say_imp,:)=pair_label;
            
            [pair_bitwidth]=determine_pair_bitwidth(x_bitwidth,say_coef,pair_label);
            
            % Removing the realized
            
            add_list(:,say_add)=[];
            say_add=say_add-1;
            add_list(:,say_add)=[];
            say_add=say_add-1;
            
            % Adding the realized
            
            say_add=say_add+1;
            add_list(1,say_add)=2^pair_power;
            add_list(2,say_add)=(-1)*say_imp;
            add_list(3,say_add)=pair_bitwidth;
        end
    end
    
    %% Negative signs
    
    if say_sub
        while say_sub~=1
            [sub_list]=order_descending_wrtrowvalue(3,say_sub,sub_list);
            
            the_pair=zeros(3,2);
            the_pair(:,1)=sub_list(:,say_sub-1);
            the_pair(:,2)=sub_list(:,say_sub);
            
            [pair_sign,pair_power,the_pair(1,:)]=conv_array_posodd(2,the_pair(1,:));
            
            say_imp=say_imp+1;
            
            partial_imp(say_imp,1)=the_pair(1,1);
            if the_pair(2,1)>0
                if the_pair(2,1)<=say_coef
                    partial_imp(say_imp,2)=(-1)*the_pair(2,1);
                    
                    first_label=zeros(1,say_coef);
                    first_label(1,the_pair(2,1))=the_pair(1,1);
                else
                    partial_imp(say_imp,2)=partial_index(the_pair(2,1),1);
                    
                    first_label=the_pair(1,1)*imp_label(partial_index(the_pair(2,1),1),:);
                end
            else
                partial_imp(say_imp,2)=abs(the_pair(2,1));
                
                first_label=the_pair(1,1)*imp_label(abs(the_pair(2,1)),:);
            end
            
            %% Addition
            partial_imp(say_imp,3)=1;
            
            partial_imp(say_imp,4)=the_pair(1,2);
            if the_pair(2,2)>0
                if the_pair(2,2)<=say_coef
                    partial_imp(say_imp,5)=(-1)*the_pair(2,2);
                    
                    second_label=zeros(1,say_coef);
                    second_label(1,the_pair(2,2))=the_pair(1,2);
                else
                    partial_imp(say_imp,5)=partial_index(the_pair(2,2),1);
                    
                    second_label=the_pair(1,2)*imp_label(partial_index(the_pair(2,2),1),:);
                end
            else
                partial_imp(say_imp,5)=abs(the_pair(2,2));
                
                second_label=the_pair(1,2)*imp_label(abs(the_pair(2,2)),:);
            end
            
            pair_label=first_label+second_label;
            imp_label(say_imp,:)=pair_label;
            
            [pair_bitwidth]=determine_pair_bitwidth(x_bitwidth,say_coef,pair_label);
            
            % Removing the realized
            
            sub_list(:,say_sub)=[];
            say_sub=say_sub-1;
            sub_list(:,say_sub)=[];
            say_sub=say_sub-1;
            
            % Adding the realized
            
            say_sub=say_sub+1;
            sub_list(1,say_sub)=2^pair_power;
            sub_list(2,say_sub)=(-1)*say_imp;
            sub_list(3,say_sub)=pair_bitwidth;
        end
    end
    
    if and(say_add,say_sub)
        the_pair=zeros(3,2);
        the_pair(:,1)=add_list(:,1);
        the_pair(:,2)=sub_list(:,1);

        [a_sign,a_power,a_pair(1,:)]=conv_array_posodd(2,the_pair(1,:));
        if a_power
            fprintf('\n');
            fprintf('Houston, here is the unexpected one !!!\n');
            fprintf('P.S. determine_implementations_area\n');
            fprintf('\n');
        end

        say_imp=say_imp+1;

        partial_imp(say_imp,1)=the_pair(1,1);
        if the_pair(2,1)>0
            if the_pair(2,1)<=say_coef
                partial_imp(say_imp,2)=(-1)*the_pair(2,1);

                first_label=zeros(1,say_coef);
                first_label(1,the_pair(2,1))=the_pair(1,1);
            else
                partial_imp(say_imp,2)=partial_index(the_pair(2,1),1);

                first_label=the_pair(1,1)*imp_label(partial_index(the_pair(2,1),1),:);
            end
        else
            partial_imp(say_imp,2)=abs(the_pair(2,1));

            first_label=the_pair(1,1)*imp_label(abs(the_pair(2,1)),:);
        end

        %% Subtraction
        partial_imp(say_imp,3)=-1;

        partial_imp(say_imp,4)=the_pair(1,2);
        if the_pair(2,2)>0
            if the_pair(2,2)<=say_coef
                partial_imp(say_imp,5)=(-1)*the_pair(2,2);

                second_label=zeros(1,say_coef);
                second_label(1,the_pair(2,2))=the_pair(1,2);
            else
                partial_imp(say_imp,5)=partial_index(the_pair(2,2),1);

                second_label=the_pair(1,2)*imp_label(partial_index(the_pair(2,2),1),:);
            end
        else
            partial_imp(say_imp,5)=abs(the_pair(2,2));

            second_label=the_pair(1,2)*imp_label(abs(the_pair(2,2)),:);
        end

        pair_label=first_label-second_label;
        imp_label(say_imp,:)=pair_label;

        [partial_width(i,1)]=determine_pair_bitwidth(x_bitwidth,say_coef,pair_label);
        partial_index(i,1)=say_imp;
    elseif and(say_add,~say_sub)
        partial_width(i,1)=pair_bitwidth;
        partial_index(i,1)=say_imp;
    elseif and(~say_add,say_sub)
        fprintf('\n');
        fprintf('Houston, were you expecting someone tonight? \n')
        fprintf('P.S. determine_implementations_area \n')
        fprintf('\n');
    end
end

target_realized=1;
for i=1:say_coef
    if imp_label(say_imp,i)~=coef_list(i,1)
        target_realized=0;
        break
    end
end

% if ~target_realized
%     fprintf('\n');
%     fprintf('Houston, could not shoot from 12!!!\n');
%     fprintf('P.S. determine_implementations_area\n');
%     fprintf('\n');
% end
