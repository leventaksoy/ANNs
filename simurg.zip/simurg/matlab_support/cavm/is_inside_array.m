function [value] = is_inside_array(the_row,say_column,say_list,row_list)

value=0;

for i=1:say_list
    is_equal=1;
    for j=1:say_column
        if row_list(i,j)~=the_row(1,j)
            is_equal=0;
            break
        end
    end
    
    if is_equal
        value=1;
        break
    end
end
