function [is_neg,power,the_row] = make_array_posodd(say_column,the_row)

is_neg=0;
for i=1:say_column
    if the_row(1,i)
        if the_row(1,i)>0
            is_neg=-1;
        else
            is_neg=1;
        end
        
        break
    end
end

power=0;
if is_neg
    if is_neg==1
        the_row(1,:)=(-1)*the_row(1,:);
    end
    
    while 1
        divideable=1;
        for i=1:say_column
            if mod(the_row(1,i),2)
                divideable=0;
                break
            end
        end
        
        if divideable
            power=power+1;
            the_row(1,:)=the_row(1,:)/2;
        else
            break
        end
    end
end
