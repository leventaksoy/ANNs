function [lower_bound,lower_step] = mcm_find_lower_bound(say_coef,coef_list,nzd_cost)

lower_step=0;
lower_bound=0;

coef_list(2,1)=1;

for i=2:1:say_coef
    %[say_nonzeros,the_nonzeros]=find_csd_representation(coef_list(1,i));
    say_nonzeros=nzd_cost(coef_list(1,i),1);
    coef_list(2,i)=say_nonzeros;
    
    if ceil(log2(say_nonzeros))>lower_step
        lower_step=ceil(log2(say_nonzeros));
    end
end

%sorted_coeflist=sort_nonzeros(say_coef,coef_list);
sorted_coeflist=order_ascending_wrtrowvalue(2,say_coef,coef_list);
lower_bound=ceil(log2(sorted_coeflist(2,2)));

for i=2:say_coef-1
    if sorted_coeflist(2,i)==sorted_coeflist(2,i+1)
        lower_bound=lower_bound+1;
    else
        lower_bound=lower_bound+ceil(log2(sorted_coeflist(2,i+1)/sorted_coeflist(2,i)));
    end
end
