function oper_cost = minas_determine_cost_oper(x_bitwidth,the_oper)

gate_cost=[13 6 10 26 13];

if and(the_oper(1,3)==1,the_oper(1,6)==1)
    if the_oper(1,2)==0
        oper_cost=minas_adder_type_one(x_bitwidth,gate_cost,the_oper);
    else
        oper_cost=minas_adder_type_two(x_bitwidth,gate_cost,the_oper);
    end
else
    if or(and(the_oper(1,3)==1,the_oper(1,5)),and(the_oper(1,6)==1,the_oper(1,8)))
        oper_cost=minas_subtractor_type_one(x_bitwidth,gate_cost,the_oper);
    elseif or(and(the_oper(1,3)==-1,the_oper(1,5)),and(the_oper(1,6)==-1,the_oper(1,8)))
        oper_cost=minas_subtractor_type_two(x_bitwidth,gate_cost,the_oper);
    elseif the_oper(1,2)
        oper_cost=minas_subtractor_type_three(x_bitwidth,gate_cost,the_oper);
    end
end
