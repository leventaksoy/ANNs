function [partial_index] = whereis_inside_partiallist(say_coef,say_partial,partial_list,the_part)

partial_index=0;

spl=size(partial_list);
stp=size(the_part);

if spl(1,2)==stp(1,2)
    for i=say_coef+1:1:say_partial
        is_equal=1;
        
        for j=1:spl(1,2)
            if the_part(1,j)~=partial_list(i,j)
                is_equal=0;
                break
            end
        end
        
        if is_equal
            partial_index=i;
            return
        end
    end
end
