function [pair_bitwidth] = determine_pair_bitwidth(x_bitwidth,say_coef,pair_label)

pair_bitwidth=0;

the_sum=0;
for i=1:say_coef
    the_sum=the_sum+abs(pair_label(1,i));
end

pair_bitwidth=x_bitwidth+ceil(log2(the_sum));
