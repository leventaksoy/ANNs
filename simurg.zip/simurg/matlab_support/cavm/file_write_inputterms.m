function [] = file_write_inputterms(fid_file,say_column,the_exp)

fprintf(fid_file,'(');

for i=1:say_column-1
    if the_exp(1,i)<0
        fprintf(fid_file,'%d*X%d',the_exp(1,i),i);
    elseif the_exp(1,i)>0
        fprintf(fid_file,'+%d*X%d',the_exp(1,i),i);
    end
end

if the_exp(1,say_column)<0
    fprintf(fid_file,'%d*X%d)',the_exp(1,say_column),say_column);
elseif the_exp(1,say_column)>0
    fprintf(fid_file,'+%d*X%d)',the_exp(1,say_column),say_column);
else
    fprintf(fid_file,')');
end