function [total_area,say_imp,imp_list,say_unimp,unimp_list]=minas_synthesize_with_lowarea(x_bitwidth,max_limit,say_imp,imp_list,say_unimp,unimp_list)

total_area=0;

while 1
    say_add=0;
    add_list=[];

    for i=1:say_unimp
        is_synth=0;
        min_area=inf;
        unimp_level=unimp_list(2,i);

        for j=1:say_imp
            imp_level=imp_list(2,j);
            if imp_level<unimp_level
                
                for us=0:1:max_limit+1
                    the_partial=(2^us)*imp_list(1,j)-unimp_list(1,i);
                    [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                    [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
                    if the_pos
                        if imp_list(2,the_pos)<unimp_level
                            is_synth=1;
                            
                            if the_partial>0
                                the_oper=[unimp_list(1,i) 0 1 imp_list(1,j) us -1 posodd_partial the_power];
                            else
                                the_oper=[unimp_list(1,i) 0 1 imp_list(1,j) us 1 posodd_partial the_power];
                            end

                            oper_cost=minas_determine_cost_oper(x_bitwidth,the_oper);
                            the_level=max(imp_list(2,j),imp_list(2,the_pos))+1;

                            if oper_cost<min_area
                                min_area=oper_cost;
                            end
                        end
                    end

                    the_partial=(2^us)*imp_list(1,j)+unimp_list(1,i);
                    [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                    [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
                    if the_pos
                        if imp_list(2,the_pos)<unimp_level
                            is_synth=1;

                            the_oper=[unimp_list(1,i) 0 -1 imp_list(1,j) us 1 posodd_partial the_power];
                            oper_cost=minas_determine_cost_oper(x_bitwidth,the_oper);
                            the_level=max(imp_list(2,j),imp_list(2,the_pos))+1;

                            if oper_cost<min_area
                                min_area=oper_cost;
                            end
                        end
                    end
                end

%                 for us=1:1:max_limit+1
%                     the_partial=imp_list(1,j)-(2^us)*unimp_list(1,i);
%                     [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
% 
%                     [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
%                     if the_pos
%                         if imp_list(2,the_pos)<unimp_level
%                             is_synth=1;
% 
%                             if the_partial>0
%                                 the_oper=[unimp_list(1,i) us 1 imp_list(1,j) 0 -1 posodd_partial 0];
%                             else
%                                 the_oper=[unimp_list(1,i) us 1 imp_list(1,j) 0 1 posodd_partial 0];
%                             end
% 
%                             oper_cost=minas_determine_cost_oper(x_bitwidth,the_oper);
%                             the_level=max(imp_list(2,j),imp_list(2,the_pos))+1;
% 
%                             if oper_cost<min_area
%                                 min_area=oper_cost;
%                             end
%                         end
%                     end
% 
%                     the_partial=imp_list(1,j)+(2^us)*unimp_list(1,i);
% 
%                     [the_pos]=where_is_inside(the_partial,say_imp,imp_list);
%                     if the_pos
%                         if imp_list(2,the_pos)<unimp_level
%                             is_synth=1;
% 
%                             the_oper=[unimp_list(1,i) us -1 imp_list(1,j) 0 1 the_partial 0];
%                             oper_cost=minas_determine_cost_oper(x_bitwidth,the_oper);
%                             the_level=max(imp_list(2,j),imp_list(2,the_pos))+1;
% 
%                             if oper_cost<min_area
%                                 min_area=oper_cost;
%                             end
%                         end
%                     end
%                 end
                
            end
        end

        if is_synth
            say_add=say_add+1;
            add_list(1,say_add)=i;
            add_list(2,say_add)=the_level;
            add_list(3,say_add)=min_area;
        end
    end
    
    if say_add
        for i=1:say_add
            say_imp=say_imp+1;
            imp_list(1,say_imp)=unimp_list(1,add_list(1,i)-i+1);
            imp_list(2,say_imp)=add_list(2,i);
            
            say_unimp=say_unimp-1;
            unimp_list(:,add_list(1,i)-i+1)=[];
            
            total_area=total_area+add_list(3,i);
        end
    else
        for i=1:say_unimp
            total_area=total_area+62*(x_bitwidth+ceil(log2(unimp_list(1,i)))); %62 stands for the area of an FA.
        end
        
        break
    end
end
