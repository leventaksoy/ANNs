function [value] = sarcastic_checkif_implemented(bit_width,depth_values,ic,say_ready,ready_list)

if depth_values((ic+1)/2,1)==1
    value=1;
else
    [value]=sarcastic_find_optimal_wod(bit_width,say_ready,ready_list,1,[ic]);
end
