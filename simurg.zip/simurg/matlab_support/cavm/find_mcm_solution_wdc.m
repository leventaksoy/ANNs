function [max_step,say_oper,oper_list,oper_indis] = find_mcm_solution_wdc(say_target,target_list,max_target)

max_step=0;
say_oper=0;
oper_list=[];
oper_indis=[];

say_target=say_target-1;
target_list(:,1)=[];

if say_target
    int_saytarget=say_target;
    int_targetlist=target_list;
    bit_width=ceil(log2(max_target));

    cost_values=textread('scm_cost','%d',2^bit_width);
    depth_values=textread('min_depth','%d',2^bit_width);

    max_level=0;
    for i=1:say_target
        if depth_values((target_list(1,i)+1)/2,1)>max_level
            max_level=depth_values((target_list(1,i)+1)/2,1);
        end
    end

    %fprintf('\n');
    %fprintf('* The minimum delay of the MCM operation: %d adder-steps \n', max_level);
    %fprintf('\n');

    %user_delay=input('Enter the delay constraint: ');
    %if user_delay<max_level
    %    user_delay=max_level;
    %end
    user_delay=max_level;

    say_ready=1;
    ready_list=[1;0];

    [say_ready,ready_list,say_target,target_list]=sarcastic_find_optimal(bit_width,user_delay,depth_values,say_ready,ready_list,say_target,target_list);

    if say_target
        say_ic=0;
        ic_list=[];
        is_found=0;

        while 1
            min_cost=inf;
            min_cost_ic=0;

            for ic=3:2:2^(bit_width+1)-1
                if depth_values((ic+1)/2,1)<user_delay
                    if and(not(is_inside(ic,say_ready,ready_list)),not(is_inside(ic,say_target,target_list)))
                        if sarcastic_checkif_implemented(bit_width,depth_values,ic,say_ready,ready_list)
                            new_saytarget=int_saytarget;
                            new_targetlist=int_targetlist;

                            for i=1:say_ic
                                new_saytarget=new_saytarget+1;
                                new_targetlist(1,new_saytarget)=ic_list(1,i);
                            end

                            new_saytarget=new_saytarget+1;
                            new_targetlist(1,new_saytarget)=ic;

                            [new_sayready,new_readylist,new_saytarget,new_targetlist]=sarcastic_find_optimal(bit_width,user_delay,depth_values,1,[1;0],new_saytarget,new_targetlist);

                            if not(new_saytarget)
                                is_found=1;

                                say_ic=say_ic+1;
                                ic_list(1,say_ic)=ic;

                                say_ready=new_sayready;
                                ready_list=new_readylist;
                            else
                                cost_ic=0;
                                for i=1:new_saytarget
                                    cost_ic=cost_ic+cost_values((new_targetlist(1,i)+1)/2,1);
                                end

                                if cost_ic<min_cost
                                    min_cost=cost_ic;
                                    min_cost_ic=ic;

                                    min_sayready=new_sayready;
                                    min_readylist=new_readylist;
                                    min_saytarget=new_saytarget;
                                    min_targetlist=new_targetlist;
                                end
                            end
                        end
                    end
                end

                if is_found
                    break
                end
            end

            if is_found
                break
            else
                say_ready=min_sayready;
                ready_list=min_readylist;
                say_target=min_saytarget;
                target_list=min_targetlist;

                say_ic=say_ic+1;
                ic_list(1,say_ic)=min_cost_ic;
            end
        end

        while 1
            is_reduced=0;

            for i=1:say_ic
                say_target=int_saytarget;
                target_list=int_targetlist;

                for j=1:say_ic
                    if i~=j
                        say_target=say_target+1;
                        target_list(1,say_target)=ic_list(1,j);
                    end
                end

                [new_sayready,new_readylist,new_saytarget,new_targetlist]=sarcastic_find_optimal(bit_width,user_delay,depth_values,1,[1;0],say_target,target_list);

                if not(new_saytarget)
                    is_reduced=1;

                    say_ic=say_ic-1;
                    ic_list(:,i)=[];

                    say_ready=new_sayready;
                    ready_list=new_readylist;
                    break
                end
            end

            if not(is_reduced)
                break
            end
        end
    end

    [max_step,say_oper,oper_list,oper_indis]=sarcastic_synthesize(bit_width,user_delay,1,[1],say_ready,ready_list);
end
