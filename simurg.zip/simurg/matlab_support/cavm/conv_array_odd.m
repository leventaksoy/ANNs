function [the_power,odd_part] = conv_array_odd(say_term,the_part)

the_power=inf;
odd_part=the_part;

for i=1:say_term
    [a_sign,a_power,posodd_term]=make_number_posodd(the_part(1,i));
    
    if a_power<the_power
        the_power=a_power;
    end
    
    if ~the_power
        break
    end
end

odd_part(1,:)=odd_part(1,:)/(2^the_power);
