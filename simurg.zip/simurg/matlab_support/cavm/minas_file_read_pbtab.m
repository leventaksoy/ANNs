function [say_partial,partial_list,say_oper,oper_list] = minas_file_read_pbtab(file_pbtab,say_selected,nodes_selected)

the_cost=0;

the_end=0;
fid_pbtab=fopen(file_pbtab,'r');

say_oper=0;
oper_list=[];
say_partial=1;
partial_list=[1];

while the_end~=say_selected
    the_line=fgetl(fid_pbtab);
    
    start=1;
    while the_line(1,start)~='='
        start=start+1;
    end
    
    the_label=str2num(char(the_line(1:1,1:start-1)));
    if is_inside(the_label,say_selected,nodes_selected)==1
        start=start+2;
        
        if and(and(the_line(1,start)=='O',the_line(1,start+1)=='P'),the_line(1,start+2)=='T')
            start=start+4;
            say_oper=say_oper+1;

            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,1)=str2num(char(the_line(1:1,initial_start:start-1)));
            
            say_partial=say_partial+1;
            partial_list(1,say_partial)=oper_list(say_oper,1);
            
            start=start+1;
            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,2)=str2num(char(the_line(1:1,initial_start:start-1)));

            start=start+1;
            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,3)=str2num(char(the_line(1:1,initial_start:start-1)));
            
            start=start+1;
            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,4)=str2num(char(the_line(1:1,initial_start:start-1)));

            start=start+1;
            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,5)=str2num(char(the_line(1:1,initial_start:start-1)));
            
            start=start+1;
            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,6)=str2num(char(the_line(1:1,initial_start:start-1)));
            
            start=start+1;
            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,7)=str2num(char(the_line(1:1,initial_start:start-1)));
            
            start=start+1;
            initial_start=start;
            while the_line(1,start)~='_'
                start=start+1;
            end
            oper_list(say_oper,8)=str2num(char(the_line(1:1,initial_start:start-1)));
            
            start=start+1;
            last_start=length(the_line);
            the_cost=the_cost+str2num(char(the_line(1:1,start:last_start)));;
        end
        the_end=the_end+1;
    end
end

fclose(fid_pbtab);
