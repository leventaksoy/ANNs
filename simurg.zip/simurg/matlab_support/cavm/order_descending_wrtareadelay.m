function [ordered_list] = order_descending_wrtareadelay(say_term,the_list)

ordered_list=the_list;

if say_term>1
    lte_list=zeros(1,say_term);
    
    for i=1:say_term-1
        for j=i+1:1:say_term
            if the_list(3,i)<the_list(3,j)
                lte_list(1,i)=lte_list(1,i)+1;
            elseif the_list(3,i)==the_list(3,j)
                if the_list(4,i)<=the_list(4,j)
                    lte_list(1,i)=lte_list(1,i)+1;
                else
                    lte_list(1,j)=lte_list(1,j)+1;
                end
            else
                lte_list(1,j)=lte_list(1,j)+1;
            end
        end
    end
    
    for i=1:say_term
        ordered_list(:,lte_list(1,i)+1)=the_list(:,i);
    end
end
