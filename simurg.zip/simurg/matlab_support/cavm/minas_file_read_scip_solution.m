function [say_selected,nodes_selected] = minas_file_read_scip_solution(file_solution)

say_selected=0;
nodes_selected=[];

fid_solution=fopen(file_solution,'r');

while 1
    the_line=fgetl(fid_solution);
    
    if ~isempty(the_line)
        if strcmp(the_line,'primal solution:')
            for i=1:3
                the_line=fgetl(fid_solution);
            end
            
            while 1
                the_line=fgetl(fid_solution);
                
                if isempty(the_line)
                    return
                else
                    the_start=2;
                    the_initial=the_start;
                    
                    while the_line(1,the_start)~=' '
                        the_start=the_start+1;
                    end
                    
                    say_selected=say_selected+1;
                    nodes_selected(1,say_selected)=str2num(char(the_line(1:1,the_initial:the_start-1)));
                end
            end
        end
    end
end

fclose(fid_solution);
