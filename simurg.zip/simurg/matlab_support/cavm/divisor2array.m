function [divisor_array] = divisor2array(say_column,the_divisor,partial_list)

divisor_array=zeros(1,say_column);

for i=1:2
    divisor_array=divisor_array+the_divisor(1,i)*partial_list(the_divisor(2,i),:);
end
