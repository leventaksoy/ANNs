function [] = checkif_oneincluded_more(say_coef,say_imp,imp_label)

for i=1:say_imp-1
    for j=i+1:1:say_imp
        
        is_included=1;
        for k=1:say_coef
            if abs(imp_label(i,k))~=abs(imp_label(j,k))
                is_included=0;
                break
            end
        end
        
        if is_included
            fprintf('The %dth partial term is the same as the %dth partial term !!!\n',i,j);
        end
    end
end
