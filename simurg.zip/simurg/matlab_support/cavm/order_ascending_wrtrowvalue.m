function [ordered_list] = order_ascending_wrtrowvalue(the_row,say_term,the_list)

ordered_list=the_list;

if say_term>1
    gte_list=zeros(1,say_term);
    
    for i=1:say_term-1
        for j=i+1:1:say_term
            if the_list(the_row,i)>=the_list(the_row,j)
                gte_list(1,i)=gte_list(1,i)+1;
            else
                gte_list(1,j)=gte_list(1,j)+1;
            end
        end
    end
    
    for i=1:say_term
        ordered_list(:,gte_list(1,i)+1)=the_list(:,i);
    end
end
