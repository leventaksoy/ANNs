function [the_value] = isan_valid_array(say_column,the_array)

the_value=0;

is_zero=1;
is_input=1;
say_nonzero=0;

for i=1:say_column
    if the_array(1,i)
        is_zero=0;
        
        if abs(the_array(1,i))~=1
            is_input=0;
            say_nonzero=say_nonzero+1;
        else
            say_nonzero=say_nonzero+1;
        end
        
        if say_nonzero>1
            is_input=0;
        end
    end
    
    if and(not(is_zero),not(is_input))
        the_value=1;
        break
    end
end
