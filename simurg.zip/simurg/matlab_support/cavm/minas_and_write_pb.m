function [ ] = minas_and_write_pb(fid_bnf,say_and_inputs,and_inputs,and_output)

output_str='';
for i=1:say_and_inputs
    output_str=[output_str,'-1 x',num2str(and_inputs(1,i)),' '];
    fprintf(fid_bnf,'+1 x%d -1 x%d >= 0;\n',and_inputs(1,i),and_output);
end

fprintf(fid_bnf,'%s+1 x%d >= %d;\n',output_str,and_output,1-say_and_inputs);
