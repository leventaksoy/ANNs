function [say_imp,partial_imp,imp_label] = determine_implementations_delay(x_bitwidth,say_coef,coef_list,say_partial,partial_cell)

say_imp=0;
partial_imp=[];
imp_label=zeros(1,say_coef);

imp_width=[];
imp_depth=[];
partial_index=zeros(say_partial,1);

for i=say_coef+1:1:say_partial
    term_list=partial_cell{i,1};
    stl=size(term_list);
    say_term=stl(1,2);
    
    %% The depth values of terms are written
    
    for j=1:say_term
        if term_list(2,j)<=say_coef
            term_list(3,j)=x_bitwidth+log2(abs(term_list(1,j)));
            term_list(4,j)=0;
        else
            term_list(3,j)=imp_width(partial_index(term_list(2,j),1),1)+log2(abs(term_list(1,j)));
            term_list(4,j)=imp_depth(partial_index(term_list(2,j),1),1);
        end
    end
     
    %% The terms are realized based on their depth values
    
    while say_term~=1
        [term_list]=order_descending_wrtdelayarea(say_term,term_list);

        the_pair=zeros(4,2);
        if and(term_list(1,say_term-1)>0,term_list(1,say_term)>0)
            output_sign=1;
            the_pair(:,1)=term_list(:,say_term-1);
            the_pair(:,2)=term_list(:,say_term);
        elseif and(term_list(1,say_term-1)>0,term_list(1,say_term)<0)
            output_sign=1;
            the_pair(:,1)=term_list(:,say_term-1);
            the_pair(:,2)=term_list(:,say_term);
        elseif and(term_list(1,say_term-1)<0,term_list(1,say_term)>0)
            output_sign=1;
            the_pair(:,1)=term_list(:,say_term);
            the_pair(:,2)=term_list(:,say_term-1);
        else
            output_sign=-1;
            the_pair(:,1)=term_list(:,say_term-1);
            the_pair(:,2)=term_list(:,say_term);
            the_pair(1,1)=(-1)*the_pair(1,1);
            the_pair(1,2)=(-1)*the_pair(1,2);
        end
            
        [pair_power,the_pair(1,:)]=conv_array_odd(2,the_pair(1,:));

        say_imp=say_imp+1;

        partial_imp(say_imp,1)=the_pair(1,1);
        if the_pair(2,1)>0
            if the_pair(2,1)<=say_coef
                partial_imp(say_imp,2)=(-1)*the_pair(2,1);

                first_label=zeros(1,say_coef);
                first_label(1,the_pair(2,1))=the_pair(1,1);
            else
                partial_imp(say_imp,2)=partial_index(the_pair(2,1),1);

                first_label=the_pair(1,1)*imp_label(partial_index(the_pair(2,1),1),:);
            end
        else
            partial_imp(say_imp,2)=abs(the_pair(2,1));

            first_label=the_pair(1,1)*imp_label(abs(the_pair(2,1)),:);
        end

        if the_pair(1,2)>0
            partial_imp(say_imp,3)=1;
        else
            partial_imp(say_imp,3)=-1;
        end

        partial_imp(say_imp,4)=the_pair(1,2);
        if the_pair(2,2)>0
            if the_pair(2,2)<=say_coef
                partial_imp(say_imp,5)=(-1)*the_pair(2,2);

                second_label=zeros(1,say_coef);
                second_label(1,the_pair(2,2))=the_pair(1,2);
            else
                partial_imp(say_imp,5)=partial_index(the_pair(2,2),1);

                second_label=the_pair(1,2)*imp_label(partial_index(the_pair(2,2),1),:);
            end
        else
            partial_imp(say_imp,5)=abs(the_pair(2,2));

            second_label=the_pair(1,2)*imp_label(abs(the_pair(2,2)),:);
        end

        pair_label=first_label+second_label;
        imp_label(say_imp,:)=pair_label;
        imp_depth(say_imp,1)=max(the_pair(4,1),the_pair(4,2))+1;
        pair_bitwidth=determine_pair_bitwidth(x_bitwidth,say_coef,pair_label);
        imp_width(say_imp,1)=pair_bitwidth+pair_power;

        % Removing the realized

        term_list(:,say_term)=[];
        say_term=say_term-1;
        term_list(:,say_term)=[];
        say_term=say_term-1;

        % Adding the realized

        say_term=say_term+1;
        term_list(1,say_term)=output_sign*2^pair_power;
        term_list(2,say_term)=(-1)*say_imp;
        term_list(3,say_term)=imp_width(say_imp,1);
        term_list(4,say_term)=imp_depth(say_imp,1);
    end
    
    partial_index(i,1)=say_imp;
end

if (say_imp)
    target_realized=1;
    for i=1:say_coef
        if imp_label(say_imp,i)~=coef_list(i,1)
            target_realized=0;
            break
        end
    end
end

% if ~target_realized
%     fprintf('\n');
%     fprintf('Houston, could not shoot from 12!!!\n');
%     fprintf('P.S. determine_implementations_area\n');
%     fprintf('\n');
% end
