function [the_sign,the_power,posodd_part] = conv_array_posodd(say_term,the_part)

the_sign=0;
the_power=inf;
posodd_part=the_part;

if the_part(1,1)<0
    the_sign=-1;
else
    the_sign=1;
end

for i=1:say_term
    [a_sign,a_power,posodd_term]=make_number_posodd(the_part(1,i));
    
    if a_power<the_power
        the_power=a_power;
    end
    
    if ~the_power
        break
    end
end

posodd_part(1,:)=(posodd_part(1,:)*the_sign)/(2^the_power);
