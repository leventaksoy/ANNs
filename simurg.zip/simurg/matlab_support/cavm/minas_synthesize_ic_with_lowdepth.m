function [is_synth]=minas_synthesize_ic_with_lowdepth(max_limit,say_imp,imp_list,say_unimp,unimp_list)

is_synth=0;
unimp_level=unimp_list(2,1);

for j=1:say_imp
    imp_level=imp_list(2,j);
    if imp_level<unimp_level;

        for us=0:1:max_limit+1
            the_partial=(2^us)*imp_list(1,j)-unimp_list(1,1);
            [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

            [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
            if the_pos
                if imp_list(2,the_pos)<unimp_level
                    is_synth=1;
                    return
                end
            end

            the_partial=(2^us)*imp_list(1,j)+unimp_list(1,1);
            [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

            [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
            if the_pos
                if imp_list(2,the_pos)<unimp_level
                    is_synth=1;
                    return
                end
            end
        end

%         for us=1:1:max_limit+1
%             the_partial=imp_list(1,j)-(2^us)*unimp_list(1,1);
%             [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
% 
%             [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
%             if the_pos
%                 if imp_list(2,the_pos)<unimp_level
%                     is_synth=1;
%                     return
%                 end
%             end
%             
%             the_partial=imp_list(1,j)+(2^us)*unimp_list(1,1);
% 
%             [the_pos]=where_is_inside(the_partial,say_imp,imp_list);
%             if the_pos
%                 if imp_list(2,the_pos)<unimp_level
%                     is_synth=1;
%                     return
%                 end
%             end
%         end
        
    end
end
