function [say_imp,imp_list,say_unimp,unimp_list]=minas_synthesize_with_lowdepth(max_limit,say_imp,imp_list,say_unimp,unimp_list)

while 1
    say_add=0;
    add_list=[];

    for i=1:say_unimp
        is_synth=0;
        unimp_level=unimp_list(2,i);

        for j=1:say_imp
            imp_level=imp_list(2,j);
            if imp_level<unimp_level;
            
                for us=0:1:max_limit+1
                    the_partial=(2^us)*imp_list(1,j)-unimp_list(1,i);
                    [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
                    
                    if posodd_partial>2^(max_limit+1)
                        break;
                    end

                    [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
                    if the_pos
                        if imp_list(2,the_pos)<unimp_level
                            is_synth=1;
                            say_add=say_add+1;
                            add_list(1,say_add)=i;
                            add_list(2,say_add)=max(imp_level,imp_list(2,the_pos))+1;
                        end
                    end
                    
                    if is_synth
                        break;
                    else
                        the_partial=(2^us)*imp_list(1,j)+unimp_list(1,i);
                        [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
                        
                        if posodd_partial>2^(max_limit+1)
                            break;
                        end

                        [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
                        if the_pos
                            if imp_list(2,the_pos)<unimp_level
                                is_synth=1;
                                say_add=say_add+1;
                                add_list(1,say_add)=i;
                                add_list(2,say_add)=max(imp_level,imp_list(2,the_pos))+1;
                            end
                        end
                    end
                    
                    if is_synth
                        break
                    end
                end
                
%                 if ~is_synth
%                     for us=1:1:max_limit+1
%                         the_partial=imp_list(1,j)-(2^us)*unimp_list(1,i);
%                         [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
% 
%                         if posodd_partial>2^(max_limit+1)
%                             break
%                         end
% 
%                         [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
%                         if the_pos
%                             if imp_list(2,the_pos)<unimp_level
%                                 is_synth=1;
%                                 say_add=say_add+1;
%                                 add_list(1,say_add)=i;
%                                 add_list(2,say_add)=max(imp_level,imp_list(2,the_pos))+1;
%                             end
%                         end
% 
%                         if is_synth
%                             break;
%                         else
%                             the_partial=imp_list(1,j)+(2^us)*unimp_list(1,i);
% 
%                             if the_partial>2^(max_limit+1)
%                                 break
%                             end
% 
%                             [the_pos]=where_is_inside(the_partial,say_imp,imp_list);
%                             if the_pos
%                                 if imp_list(2,the_pos)<unimp_level
%                                     is_synth=1;
%                                     say_add=say_add+1;
%                                     add_list(1,say_add)=i;
%                                     add_list(2,say_add)=max(imp_level,imp_list(2,the_pos))+1;
%                                 end
%                             end
%                         end
% 
%                         if is_synth
%                             break
%                         end
%                     end
%                 end
                
            end
            
            if is_synth
                break
            end
        end
    end
    
    if say_add
        for i=1:say_add
            say_imp=say_imp+1;
            imp_list(1,say_imp)=unimp_list(1,add_list(1,i)-i+1);
            imp_list(2,say_imp)=add_list(2,i);
            
            say_unimp=say_unimp-1;
            unimp_list(:,add_list(1,i)-i+1)=[];
        end
    else
        break
    end
end
