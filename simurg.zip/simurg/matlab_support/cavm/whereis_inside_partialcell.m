function [partial_index] = whereis_inside_partialcell(say_coef,say_partial,partial_cell,the_part)

partial_index=0;
stp=size(the_part);

for i=say_coef+1:1:say_partial
    partial_list=partial_cell{i,1};
    spl=size(partial_list);
    
    if spl(1,2)==stp(1,2)
        say_equal=0;
        
        for j=1:spl(1,2)
            is_equal=0;
            
            for k=1:spl(1,2)
                if and(the_part(1,j)==partial_list(1,k),the_part(2,j)==partial_list(2,k))
                    is_equal=1;
                    say_equal=say_equal+1;
                    break
                end
            end
            
            if ~is_equal
                break
            end
        end

        if say_equal==spl(1,2)
            partial_index=i;
            return
        end
    end
end
