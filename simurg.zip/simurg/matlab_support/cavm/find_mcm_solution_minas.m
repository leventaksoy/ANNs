function [max_step,say_oper,oper_list,oper_indis] = find_mcm_solution_minas(os_choice,x_bitwidth,say_target,target_list,max_target,delay_constraint)

max_step=0;
say_oper=0;
oper_list=[];
oper_indis=[];

say_coef=say_target;
coef_list=target_list;

say_target=say_target-1;
target_list(:,1)=[];

the_choice=1;
if say_target
    bit_width=ceil(log2(max_target));

    cost_values=textread('scm_cost','%d',2^bit_width);
    depth_values=textread('min_depth','%d',2^bit_width);

    max_level=0;
    for i=1:say_target
        if depth_values((target_list(1,i)+1)/2,1)>max_level
            max_level=depth_values((target_list(1,i)+1)/2,1);
        end
    end

    fprintf('\n');
    fprintf('* The minimum delay of the MCM operation: %d adder-steps \n', max_level);
    fprintf('\n');

    if ~delay_constraint
        user_delay=inf;
    else
        user_delay=max_level;
    end
    
    say_ready=1;
    ready_list=[1;0];
    target_list(2:2,:)=user_delay;

    [say_ready,ready_list,say_target,target_list]=minas_synthesize_with_lowdepth(bit_width,say_ready,ready_list,say_target,target_list);

    %% An intermediate constant is added in the following iterative loop till
    %% all the constants are synthesized. The intermediate constant is chosen
    %% based on its implementation cost and on the implementation costs of
    %% not-yet-synthesized constants under the delay constraint.

    while say_target
        mcm_found=0;
        min_cost=inf;
        min_cost_ic=0;

        for ic=3:2:2^(bit_width+1)-1
            ic_level=depth_values((ic+1)/2,1);
            if ic_level<user_delay
                if and(not(is_inside(ic,say_ready,ready_list)),not(is_inside(ic,say_target,target_list)))
                    if minas_synthesize_ic_with_lowdepth(bit_width,say_ready,ready_list,[1],[ic;user_delay-1])
                        new_sayready=1;
                        new_readylist=[1;0];

                        new_saytarget=say_ready;
                        new_targetlist=ready_list;

                        new_targetlist(:,1)=[];
                        new_targetlist(1,say_ready)=ic;
                        new_targetlist(2,say_ready)=user_delay-1;

                        for i=1:say_target
                            new_saytarget=new_saytarget+1;
                            new_targetlist(:,new_saytarget)=target_list(:,i);
                        end

                        if the_choice
                            [cost_ic,new_sayready,new_readylist,new_saytarget,new_targetlist]=minas_synthesize_with_lowarea(x_bitwidth,bit_width,new_sayready,new_readylist,new_saytarget,new_targetlist);
                        else
                            [cost_ic,new_sayready,new_readylist,new_saytarget,new_targetlist]=minas_synthesize_with_lowoper(x_bitwidth,bit_width,cost_values,new_sayready,new_readylist,new_saytarget,new_targetlist);
                        end

                        if ~new_saytarget
                            mcm_found=mcm_found+1;
                        end

                        if mcm_found
                            if ~new_saytarget
                                if mcm_found==1
                                    min_cost_ic=ic;
                                    min_cost=cost_ic;
                                    min_sayready=new_sayready;
                                    min_readylist=new_readylist;
                                    min_saytarget=new_saytarget;
                                    min_targetlist=new_targetlist;
                                else
                                    if cost_ic<min_cost
                                        min_cost_ic=ic;
                                        min_cost=cost_ic;
                                        min_sayready=new_sayready;
                                        min_readylist=new_readylist;
                                        min_saytarget=new_saytarget;
                                        min_targetlist=new_targetlist;
                                    end
                                end
                            end
                        else
                            if cost_ic<min_cost
                                min_cost_ic=ic;
                                min_cost=cost_ic;
                                min_sayready=new_sayready;
                                min_readylist=new_readylist;
                                min_saytarget=new_saytarget;
                                min_targetlist=new_targetlist;
                            end
                        end

                    end
                end
            end
        end

        say_ready=min_sayready;
        ready_list=min_readylist;
        say_target=min_saytarget;
        target_list=min_targetlist;
    end

    %% A 0-1 ILP problem is formed to find a set of operations that has the
    %% optimal area based on the obtained solution. Note that the given
    %% directory of SCIP should be modified.

    [ready_list]=minas_sort_unimplemented(say_ready,ready_list);
    [say_partial,partial_list,say_oper,oper_list]=minas_find_implementations(x_bitwidth,the_choice,bit_width,say_ready,ready_list);
    [say_vars,say_cons,say_optvars]=minas_represent_covering_problem(say_coef,coef_list,say_partial,partial_list,say_oper,oper_list);
    file_solution=['cover_problem.solution'];
    if os_choice
        scip_alias=['/home/levent/scip_64b_linux/scip_20_64b -f cover_problem.opb > ',file_solution];
        [solution_ready,the_solution]=unix(scip_alias);
    else
        scip_alias=['D:\solvers\pb_solvers\scip_win64\scip2.0.2\scip_202_64b -f cover_problem.opb > ',file_solution];
        [solution_ready,the_solution]=dos(scip_alias);
    end
    [say_selected,nodes_selected]=minas_file_read_scip_solution(file_solution);
    [say_partial,partial_list,say_oper,oper_list]=minas_file_read_pbtab('cover_problem.pbtab',say_selected,nodes_selected);
    %[max_step,avg_level,gpscore]=minas_find_level_gpscore(x_bitwidth,say_partial,partial_list,say_oper,oper_list);
    [oper_list,oper_indis,max_step]=sarcastic_find_level(say_oper,oper_list);
end
