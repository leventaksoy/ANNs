function [ordered_list] = order_descending_wrtrowvalue(the_row,say_term,the_list)

ordered_list=the_list;

if say_term>1
    lte_list=zeros(1,say_term);
    
    for i=1:say_term-1
        for j=i+1:1:say_term
            if the_list(the_row,i)<=the_list(the_row,j)
                lte_list(1,i)=lte_list(1,i)+1;
            else
                lte_list(1,j)=lte_list(1,j)+1;
            end
        end
    end
    
    for i=1:say_term
        ordered_list(:,lte_list(1,i)+1)=the_list(:,i);
    end
end
