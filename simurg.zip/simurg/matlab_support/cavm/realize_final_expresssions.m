function [say_partial,partial_list,partial_imp] = realize_final_expresssions(x_bitwidth,say_column,say_target,say_partial,target_stats,target_repcell,partial_list,partial_imp)

partial_bitwidth(1:say_column,1:1)=x_bitwidth;
for i=say_column+1:1:say_partial
    absmag_total=0;
    for j=1:say_column
        absmag_total=absmag_total+abs(partial_list(i,j));
    end
    partial_bitwidth(i,1)=ceil(log2(absmag_total))+x_bitwidth;
end

for i=1:say_target
    if target_stats(1,i)~=1
        the_rep=target_repcell{1,i};
        neg_list=[];
        pos_list=[];
        say_neg=0;
        say_pos=0;

        for j=1:target_stats(1,i)
            if the_rep(1,j)<0
                say_neg=say_neg+1;
                neg_list(1,say_neg)=abs(the_rep(1,j));
                neg_list(2,say_neg)=the_rep(2,j);
                neg_list(3,say_neg)=log2(abs(the_rep(1,j)))+partial_bitwidth(the_rep(2,j),1);
            else
                say_pos=say_pos+1;
                pos_list(1,say_pos)=the_rep(1,j);
                pos_list(2,say_pos)=the_rep(2,j);
                pos_list(3,say_pos)=log2(abs(the_rep(1,j)))+partial_bitwidth(the_rep(2,j),1);
            end
        end

        if say_neg
            while say_neg~=1
                [two_narrow]=find_two_narrow(say_neg,neg_list);

                the_divisor(:,1)=neg_list(:,two_narrow(1,1));
                the_divisor(:,2)=neg_list(:,two_narrow(1,2));

                divisor_array=divisor2array(say_column,the_divisor,partial_list);
                [is_neg,power,posodd_divisor_array]=make_array_posodd(say_column,divisor_array);
                the_divisor(1,:)=(-1)*is_neg*the_divisor(1,:)/(2^power);

                absmag_total=0;
                for j=1:say_column
                    absmag_total=absmag_total+abs(posodd_divisor_array(1,j));
                end

                say_partial=say_partial+1;
                partial_list(say_partial,:)=posodd_divisor_array;
                partial_bitwidth(say_partial,1)=ceil(log2(absmag_total))+x_bitwidth;

                partial_imp(say_partial,1)=the_divisor(1,1);
                partial_imp(say_partial,2)=the_divisor(2,1);
                partial_imp(say_partial,3)=the_divisor(1,2);
                partial_imp(say_partial,4)=the_divisor(2,2);

                if two_narrow(1,1)<two_narrow(1,2)
                    delete_indis=two_narrow(1,2);
                    replace_indis=two_narrow(1,1);
                else
                    delete_indis=two_narrow(1,1);
                    replace_indis=two_narrow(1,2);
                end

                say_neg=say_neg-1;
                neg_list(:,delete_indis)=[];
                neg_list(1,replace_indis)=is_neg*(-1)*(2^power);
                neg_list(2,replace_indis)=say_partial;
                neg_list(3,replace_indis)=log2(abs(neg_list(1,replace_indis)))+partial_bitwidth(say_partial,1);
            end
        end

        if say_pos
            while say_pos~=1
                [two_narrow]=find_two_narrow(say_pos,pos_list);

                the_divisor(:,1)=pos_list(:,two_narrow(1,1));
                the_divisor(:,2)=pos_list(:,two_narrow(1,2));

                divisor_array=divisor2array(say_column,the_divisor,partial_list);
                [is_neg,power,posodd_divisor_array]=make_array_posodd(say_column,divisor_array);
                the_divisor(1,:)=(-1)*is_neg*the_divisor(1,:)/(2^power);

                absmag_total=0;
                for j=1:say_column
                    absmag_total=absmag_total+abs(posodd_divisor_array(1,j));
                end

                say_partial=say_partial+1;
                partial_list(say_partial,:)=posodd_divisor_array;
                partial_bitwidth(say_partial,1)=ceil(log2(absmag_total))+x_bitwidth;

                partial_imp(say_partial,1)=the_divisor(1,1);
                partial_imp(say_partial,2)=the_divisor(2,1);
                partial_imp(say_partial,3)=the_divisor(1,2);
                partial_imp(say_partial,4)=the_divisor(2,2);

                if two_narrow(1,1)<two_narrow(1,2)
                    delete_indis=two_narrow(1,2);
                    replace_indis=two_narrow(1,1);
                else
                    delete_indis=two_narrow(1,1);
                    replace_indis=two_narrow(1,2);
                end

                say_pos=say_pos-1;
                pos_list(:,delete_indis)=[];
                pos_list(1,replace_indis)=is_neg*(-1)*(2^power);
                pos_list(2,replace_indis)=say_partial;
                pos_list(3,replace_indis)=log2(abs(pos_list(1,replace_indis)))+partial_bitwidth(say_partial,1);
            end
        end

        if and(say_neg,say_pos)
            neg_list(1,1)=-1*neg_list(1,1);
            the_divisor(:,1)=pos_list(:,1);
            the_divisor(:,2)=neg_list(:,1);

            divisor_array=divisor2array(say_column,the_divisor,partial_list);
            [is_neg,power,posodd_divisor_array]=make_array_posodd(say_column,divisor_array);
            the_divisor(1,:)=(-1)*is_neg*the_divisor(1,:)/(2^power);

            absmag_total=0;
            for j=1:say_column
                absmag_total=absmag_total+abs(posodd_divisor_array(1,j));
            end

            say_partial=say_partial+1;
            partial_list(say_partial,:)=posodd_divisor_array;
            partial_bitwidth(say_partial,1)=ceil(log2(absmag_total))+x_bitwidth;

            partial_imp(say_partial,1)=the_divisor(1,1);
            partial_imp(say_partial,2)=the_divisor(2,1);
            partial_imp(say_partial,3)=the_divisor(1,2);
            partial_imp(say_partial,4)=the_divisor(2,2);

            neg_list=[];
            pos_list=[];
            say_neg=say_neg-1;
            say_pos=say_pos-1;
        end

    end
end
