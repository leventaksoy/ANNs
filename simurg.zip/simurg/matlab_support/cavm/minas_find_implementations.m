function [say_partial,partial_list,say_alloper,alloper_list] = minas_find_implementations(x_bitwidth,the_choice,max_limit,say_partial,partial_list)

say_imp=1;
imp_list=[1;0];

say_alloper=0;
alloper_list=[];

for i=2:say_partial
    is_synth=0;
    say_oper=0;
    oper_list=[];
    partial_level=partial_list(2,i);

    for j=1:say_imp
        if imp_list(2,j)<partial_level
            
            for us=0:1:max_limit+1
                the_partial=(2^us)*imp_list(1,j)-partial_list(1,i);
                [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
                
                the_pos=where_is_inside(posodd_partial,say_imp,imp_list);
                
                if the_pos
                    if imp_list(2,the_pos)<partial_level
                        is_synth=1;
                        say_oper=say_oper+1;
                        oper_list(say_oper,1)=partial_list(1,i);
                        oper_list(say_oper,2)=0;
                        oper_list(say_oper,3)=1;
                        oper_list(say_oper,4)=imp_list(1,j);
                        oper_list(say_oper,5)=us;
                        if the_partial<0
                            oper_list(say_oper,6)=1;
                        else
                            oper_list(say_oper,6)=-1;
                        end
                        oper_list(say_oper,7)=posodd_partial;
                        oper_list(say_oper,8)=the_power;
                        
                        if the_choice
                            area_cost=minas_determine_cost_oper(x_bitwidth,oper_list(say_oper,1:8));
                        else
                            area_cost=1;
                        end
                        
                        oper_list(say_oper,9)=area_cost;
                        oper_list(say_oper,10)=1;
                    end
                end

                the_partial=(2^us)*imp_list(1,j)+partial_list(1,i);
                [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
                
                the_pos=where_is_inside(posodd_partial,say_imp,imp_list);
                
                if the_pos
                    if imp_list(2,the_pos)<partial_level
                        is_synth=1;
                        say_oper=say_oper+1;
                        oper_list(say_oper,1)=partial_list(1,i);
                        oper_list(say_oper,2)=0;
                        oper_list(say_oper,3)=1;
                        oper_list(say_oper,4)=posodd_partial;
                        oper_list(say_oper,5)=the_power;
                        oper_list(say_oper,6)=-1;
                        oper_list(say_oper,7)=imp_list(1,j);
                        oper_list(say_oper,8)=us;
                        
                        if the_choice
                            area_cost=minas_determine_cost_oper(x_bitwidth,oper_list(say_oper,1:8));
                        else
                            area_cost=1;
                        end

                        oper_list(say_oper,9)=area_cost;
                        oper_list(say_oper,10)=1;
                    end
                end
            end

%             for us=1:1:max_limit+1
%                 the_partial=imp_list(1,j)-(2^us)*partial_list(1,i);
%                 [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
%                 
%                 the_pos=where_is_inside(posodd_partial,say_imp,imp_list);
%                 
%                 if the_pos
%                     if imp_list(2,the_pos)<partial_level
%                         is_synth=1;
%                         say_oper=say_oper+1;
%                         oper_list(say_oper,1)=partial_list(1,i);
%                         oper_list(say_oper,2)=us;
%                         oper_list(say_oper,3)=1;
%                         oper_list(say_oper,4)=imp_list(1,j);
%                         oper_list(say_oper,5)=0;
%                         if the_partial<0
%                             oper_list(say_oper,6)=1;
%                         else
%                             oper_list(say_oper,6)=-1;
%                         end
%                         oper_list(say_oper,7)=posodd_partial;
%                         oper_list(say_oper,8)=0;
%                         
%                         if the_choice
%                             area_cost=determine_cost_oper(x_bitwidth,oper_list(say_oper,1:8));
%                         else
%                             area_cost=1;
%                         end
% 
%                         oper_list(say_oper,9)=area_cost;
%                         oper_list(say_oper,10)=1;
%                     end
%                 end
% 
%                 the_partial=imp_list(1,j)+(2^us)*partial_list(1,i);
%                 [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
% 
%                 the_pos=where_is_inside(posodd_partial,say_imp,imp_list);
%                 
%                 if the_pos
%                     if imp_list(2,the_pos)<partial_level
%                         is_synth=1;
%                         say_oper=say_oper+1;
%                         oper_list(say_oper,1)=partial_list(1,i);
%                         oper_list(say_oper,2)=us;
%                         oper_list(say_oper,3)=-1;
%                         oper_list(say_oper,4)=imp_list(1,j);
%                         oper_list(say_oper,5)=0;
%                         oper_list(say_oper,6)=1;
%                         oper_list(say_oper,7)=posodd_partial;
%                         oper_list(say_oper,8)=0;
%                         
%                         if the_choice
%                             area_cost=determine_cost_oper(x_bitwidth,oper_list(say_oper,1:8));
%                         else
%                             area_cost=1;
%                         end
% 
%                         oper_list(say_oper,9)=area_cost;
%                         oper_list(say_oper,10)=1;
%                     end
%                 end
%             end
            
        end
    end
    
    if is_synth==0
        fprintf('%d is not synthesized \n',partial_list(1,i))
        pause
    end

    say_imp=say_imp+1;
    imp_list(1,say_imp)=partial_list(1,i);
    imp_list(2,say_imp)=partial_list(2,i);

    partial_list(2,i)=say_alloper+1;

    for j=1:say_oper-1
        if oper_list(j,10)
            for k=j+1:say_oper
                if oper_list(k,10)
                    if oper_list(j,9)==oper_list(k,9)
                        if and(oper_list(j,4)==oper_list(k,7),oper_list(j,7)==oper_list(k,4))
                            oper_list(k,10)=0;
                        end
                    end
                end
            end

            say_alloper=say_alloper+1;
            alloper_list(say_alloper,:)=oper_list(j,:);
        end
    end

    partial_list(3,i)=say_alloper;
end
