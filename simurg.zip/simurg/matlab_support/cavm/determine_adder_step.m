function [say_step] = determine_adder_step(say_imp,partial_imp)

say_step=0;

say_checked=0;
partial_step=zeros(say_imp,1);

while say_checked~=say_imp
    for i=1:say_imp
        first_step=0;
        
        if partial_imp(i,2)<0
            first_step=1;
        else
            first_step=partial_step(partial_imp(i,2),1);
        end
        
        if first_step
            second_step=0;
            
            if partial_imp(i,5)<0
                second_step=1;
            else
                second_step=partial_step(partial_imp(i,5),1);
            end
            
            if second_step
                say_checked=say_checked+1;
                partial_step(i,1)=max(first_step,second_step)+1;
                
                if partial_step(i,1)>say_step
                    say_step=partial_step(i,1);
                end
            end
        end
    end
end

say_step=say_step-1;
