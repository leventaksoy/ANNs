function [max_level,avg_level,total_gps] = minas_find_level_gpscore(x_bitwidth,say_partial,partial_list,say_oper,oper_list)

max_level=0;
avg_level=0;

all_found=1;
total_level=0;
partial_list(2,1)=1;

while all_found~=say_partial
    for i=2:say_partial
        if not(partial_list(2,i))
            konum_first_partial=where_is_inside(oper_list(i-1,4),say_partial,partial_list);
            konum_second_partial=where_is_inside(oper_list(i-1,7),say_partial,partial_list);

            if and(partial_list(2,konum_first_partial),partial_list(2,konum_second_partial))
                all_found=all_found+1;
                partial_list(2,i)=max(partial_list(2,konum_first_partial),partial_list(2,konum_second_partial))+1;
                
                if partial_list(2,i)-1>max_level
                    max_level=partial_list(2,i)-1;
                end
                
                total_level=total_level+partial_list(2,i)-1;
            end
        end
    end
end

avg_level=total_level/(all_found-1);

for i=2:say_partial
    oper_list(i-1,9)=partial_list(2,i)-1;
end

total_gps=0;
partial_list(3,1)=1;

say_synth=0;
the_level=0;
while say_synth~=say_oper
    the_level=the_level+1;

    for i=1:say_oper
        if oper_list(i,9)==the_level

            input_one=where_is_inside(oper_list(i,4),say_partial,partial_list);
            input_two=where_is_inside(oper_list(i,7),say_partial,partial_list);
            n=ceil(log2(oper_list(i,1)))+x_bitwidth;
            e=max(oper_list(i,5),oper_list(i,8));
            say_synth=say_synth+1;

            if and(oper_list(i,3)==1,oper_list(i,6)==1)
                if oper_list(i,2)==0
                    r=n-e;
                else
                    r=n-oper_list(i,2);
                end
            else
                if oper_list(i,2)==0
                    if or(oper_list(i,5)>ceil(log2(oper_list(i,7)))+x_bitwidth,oper_list(i,8)>ceil(log2(oper_list(i,4)))+x_bitwidth)
                        r=n-e+1+e/2;
                    else
                        r=n;
                    end
                else
                    r=n-oper_list(i,2);
                end
            end

            gps_one=partial_list(3,input_one);
            gps_two=partial_list(3,input_two);

            partial_list(3,i+1)=ceil(r*(oper_list(i,9)^0.55)+0.67*(partial_list(3,input_one)+partial_list(3,input_two)));

            total_gps=total_gps+partial_list(3,i+1);
        end
    end
end
