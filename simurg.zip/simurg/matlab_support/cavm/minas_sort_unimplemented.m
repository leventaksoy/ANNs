function [unimp_list] = minas_sort_unimplemented(say_unimp,unimp_list)

the_last=1;
sorted_list=unimp_list;
sorted_list(3,1)=the_last;

for i=2:say_unimp
    backtrack_required=1;
    
    if sorted_list(2,i)>sorted_list(2,the_last)
        backtrack_required=0;
        sorted_list(3,i)=i;
        the_last=i;
    elseif sorted_list(2,i)==sorted_list(2,the_last)
        if sorted_list(1,i)>sorted_list(1,the_last)
            backtrack_required=0;
            sorted_list(3,i)=i;
            the_last=i;
        end
    end
    
    if backtrack_required
        the_pos=inf;
        
        for j=i-1:-1:1
            if sorted_list(2,j)>sorted_list(2,i)
                if sorted_list(3,j)<the_pos
                    the_pos=sorted_list(3,j);
                end
                
                sorted_list(3,j)=sorted_list(3,j)+1;
            elseif sorted_list(2,j)==sorted_list(2,i)
                if sorted_list(1,j)>sorted_list(1,i)
                    if sorted_list(3,j)<the_pos
                        the_pos=sorted_list(3,j);
                    end
                    
                    sorted_list(3,j)=sorted_list(3,j)+1;
                end
            end
        end
        
        sorted_list(3,i)=the_pos;
    end
end

for i=1:say_unimp
    unimp_list(1,sorted_list(3,i))=sorted_list(1,i);
    unimp_list(2,sorted_list(3,i))=sorted_list(2,i);
end
