function [oper_list,oper_indis,max_step] = mcm_find_level(say_oper,oper_list)

max_step=0;
say_found=0;
oper_indis=zeros(say_oper,2);
oper_list(:,9)=zeros(say_oper,1);

for i=1:say_oper
    if oper_list(i,4)~=1
        [first_indis]=whereis_inside_vertical(say_oper,oper_list,oper_list(i,4));
    else
        first_indis=-1;
    end
    
    if oper_list(i,7)~=1
        [second_indis]=whereis_inside_vertical(say_oper,oper_list,oper_list(i,7));
    else
        second_indis=-1;
    end
    
    oper_indis(i,1)=first_indis;
    oper_indis(i,2)=second_indis;
    
    if and(first_indis==-1,second_indis==-1)
        say_found=say_found+1;
        oper_list(i,9)=1;
        max_step=1;
    end
end

while say_found~=say_oper
    for i=1:say_oper
        if ~oper_list(i,9)
            if oper_list(i,4)~=1
                first_step=oper_list(oper_indis(i,1),9);
            else
                first_step=-1;
            end
            
            if first_step
                if oper_list(i,7)~=1
                    second_step=oper_list(oper_indis(i,2),9);
                else
                    second_step=-1;
                end
                
                if second_step
                    say_found=say_found+1;
                    oper_list(i,9)=max(first_step,second_step)+1;
                    
                    if oper_list(i,9)>max_step
                        max_step=oper_list(i,9);
                    end
                end
            end
        end
    end
end
