function [say_oper,oper_list,oper_indis,max_level] = mcm_synthesize(max_limit,say_imp,imp_list,say_unimp,unimp_list)

say_oper=0;
max_level=0;
oper_list=[];
oper_indis=[];

while 1
    new_sayadd=0;
    new_addlist=[];
    
    for i=1:say_unimp
        is_synth=0;
        
        for j=1:say_imp
            for us=0:1:max_limit+1
                the_partial=(2^us)*imp_list(1,j)-unimp_list(1,i);
                [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
                
                if is_inside(posodd_partial,say_imp,imp_list)
                    is_synth=1;
                    new_sayadd=new_sayadd+1;
                    new_addlist(1,new_sayadd)=i;
                    
                    say_oper=say_oper+1;
                    
                    if the_partial>0
                        %fprintf(fid_result,'%6d>>0 = +%d<<%d -%d<<%d\n',unimp_list(1,i),imp_list(1,j),us,posodd_partial,the_power);
                        
                        oper_list(say_oper,1)=unimp_list(1,i);
                        oper_list(say_oper,2)=0;
                        oper_list(say_oper,3)=1;
                        oper_list(say_oper,4)=imp_list(1,j);
                        oper_list(say_oper,5)=us;
                        oper_list(say_oper,6)=-1;
                        oper_list(say_oper,7)=posodd_partial;
                        oper_list(say_oper,8)=the_power;
                    else
                        %fprintf(fid_result,'%6d>>0 = +%d<<%d +%d<<%d\n',unimp_list(1,i),imp_list(1,j),us,posodd_partial,the_power);
                        oper_list(say_oper,1)=unimp_list(1,i);
                        oper_list(say_oper,2)=0;
                        oper_list(say_oper,3)=1;
                        oper_list(say_oper,4)=imp_list(1,j);
                        oper_list(say_oper,5)=us;
                        oper_list(say_oper,6)=1;
                        oper_list(say_oper,7)=posodd_partial;
                        oper_list(say_oper,8)=the_power;
                    end
                end
                
                if not(is_synth)
                    the_partial=(2^us)*imp_list(1,j)+unimp_list(1,i);
                    [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                    if is_inside(posodd_partial,say_imp,imp_list)
                        is_synth=1;
                        new_sayadd=new_sayadd+1;
                        new_addlist(1,new_sayadd)=i;

                        say_oper=say_oper+1;
                        
                        %fprintf(fid_result,'%6d>>0 = +%d<<%d -%d<<%d\n',unimp_list(1,i),posodd_partial,the_power,imp_list(1,j),us,);
                        oper_list(say_oper,1)=unimp_list(1,i);
                        oper_list(say_oper,2)=0;
                        oper_list(say_oper,3)=1;
                        oper_list(say_oper,4)=posodd_partial;
                        oper_list(say_oper,5)=the_power;
                        oper_list(say_oper,6)=-1;
                        oper_list(say_oper,7)=imp_list(1,j);
                        oper_list(say_oper,8)=us;
                    end
                end
                
                if is_synth
                    break
                end
            end
            
            if is_synth
                break
            end
        end
    end
    
    if new_sayadd
        for i=1:new_sayadd
            say_imp=say_imp+1;
            imp_list(1,say_imp)=unimp_list(1,new_addlist(1,i)-i+1);
            
            say_unimp=say_unimp-1;
            unimp_list(:,new_addlist(1,i)-i+1)=[];
        end
    end
    
    if say_unimp==0
        break
    end
end

[oper_list,oper_indis,max_level]=mcm_find_level(say_oper,oper_list);
