function [say_imp,imp_list,say_unimp,unimp_list] = mcm_find_optimal(max_limit,say_imp,imp_list,say_add,add_list,say_unimp,unimp_list)

while 1
    new_sayadd=0;
    new_addlist=[];
    
    for i=1:say_unimp
        is_synth=0;
        
        for j=1:say_add
            for us=0:1:max_limit+1
                the_partial=(2^us)*add_list(1,j)-unimp_list(1,i);
                [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);
                
                if posodd_partial>2^(max_limit+1)
                    break
                else
                    if is_inside(posodd_partial,say_imp,imp_list)
                        is_synth=1;
                        new_sayadd=new_sayadd+1;
                        new_addlist(1,new_sayadd)=i;
                    end
                end
                
                if not(is_synth)
                    the_partial=(2^us)*add_list(1,j)+unimp_list(1,i);
                    [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                    if is_inside(posodd_partial,say_imp,imp_list)
                        is_synth=1;
                        new_sayadd=new_sayadd+1;
                        new_addlist(1,new_sayadd)=i;
                    end
                end
                
                if is_synth
                    break
                end
            end
            
%             if not(is_synth)
%                 for us=1:1:max_limit+1
%                     the_partial=add_list(1,j)-(2^us)*unimp_list(1,i);
%                     [the_power,posodd_partial]=make_number_posodd(the_partial);
%                     
%                     if posodd_partial>2^(max_limit+1)
%                         break
%                     else
%                         if is_inside(posodd_partial,say_imp,imp_list)
%                             is_synth=1;
%                             new_sayadd=new_sayadd+1;
%                             new_addlist(1,new_sayadd)=i;
%                         end
%                     end
%                     
%                     if not(is_synth)
%                         the_partial=add_list(1,j)+(2^us)*unimp_list(1,i);
%                         [the_power,posodd_partial]=make_number_posodd(the_partial);
%                         
%                         if is_inside(posodd_partial,say_imp,imp_list)
%                             is_synth=1;
%                             new_sayadd=new_sayadd+1;
%                             new_addlist(1,new_sayadd)=i;
%                         end
%                     end
%                     
%                     if is_synth
%                         break
%                     end
%                 end
%             end
            
            if is_synth
                break
            end
        end
    end
    
    if new_sayadd
        say_add=new_sayadd;
        add_list=new_addlist;
        
        for i=1:new_sayadd
            say_imp=say_imp+1;
            add_list(1,i)=unimp_list(1,new_addlist(1,i)-i+1);
            imp_list(1,say_imp)=unimp_list(1,new_addlist(1,i)-i+1);
            
            say_unimp=say_unimp-1;
            unimp_list(:,new_addlist(1,i)-i+1)=[];
        end
    else
        break
    end
end
